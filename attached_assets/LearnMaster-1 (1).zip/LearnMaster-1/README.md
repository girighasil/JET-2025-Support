
# Maths Magic Town - Educational Platform

An adaptive educational technology platform for mathematics coaching, delivering personalized and interactive learning experiences for competitive exam preparation.

## Features

- 🎓 Comprehensive Online Courses
  - Interactive video lessons
  - Structured learning paths
  - Progress tracking
  - Course completion certificates

- 📝 Test Series Management
  - Auto-grading system
  - Detailed performance analytics
  - Mock tests for various exams
  - Personalized feedback

- 💡 Interactive Learning
  - Live doubt resolution sessions
  - One-on-one mentoring
  - Interactive practice problems
  - Real-time progress tracking

- 👨‍🏫 Admin Features
  - Course management
  - Student progress monitoring
  - Test creation and evaluation
  - Analytics dashboard

## Tech Stack

- **Frontend**: React with TypeScript, Tailwind CSS, shadcn/ui
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with SQLite fallback
- **ORM**: Drizzle
- **Authentication**: Passport.js with session-based auth
- **API**: RESTful endpoints

## Getting Started

1. Clone and install dependencies:
   ```bash
   npm install
   ```

2. Set up environment variables:
   - Copy `.env.example` to `.env`
   - Configure your database settings

3. Start development server:
   ```bash
   npm run dev
   ```

The application will be available at `http://0.0.0.0:5000`

## Project Structure

```
├── client/               # Frontend React application
│   ├── src/
│   │   ├── components/  # Reusable UI components
│   │   ├── hooks/      # Custom React hooks
│   │   ├── pages/      # Page components
│   │   └── lib/        # Utilities and helpers
├── server/              # Backend Express application
│   ├── routes.ts       # API routes
│   ├── db.ts           # Database configuration
│   └── auth.ts         # Authentication logic
└── shared/             # Shared types and schemas
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm run check` - Type checking
- `npm run db:push` - Update database schema

## Default Admin Access

- Username: `admin`
- Password: `admin123`

**Note**: Change these credentials after first login for security.

## License

MIT License - feel free to use this project for your own educational platforms.
