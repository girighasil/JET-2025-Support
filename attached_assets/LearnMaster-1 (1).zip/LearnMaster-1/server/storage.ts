import { 
  users, courses, lessons, enrollments, tests, questions, testAttempts, sessions,
  type User, type InsertUser, type Course, type InsertCourse, type Lesson, type InsertLesson,
  type Enrollment, type InsertEnrollment, type Test, type InsertTest, type Question, type InsertQuestion,
  type TestAttempt, type InsertTestAttempt, type Session, type InsertSession
} from "@shared/schema";
import { db, pool } from "./db";
import { eq, and, isNull, desc, sql, or } from "drizzle-orm";
import createMemoryStore from "memorystore";
import session from "express-session";
import connectPg from "connect-pg-simple";

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

// Interface for all storage operations
export interface IStorage {
  // Session store
  sessionStore: session.SessionStore;

  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  getUserCount(): Promise<number>;
  
  // Course management
  getCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: number, course: InsertCourse): Promise<Course | undefined>;
  deleteCourse(id: number): Promise<boolean>;
  getCourseCount(): Promise<number>;
  
  // Lesson management
  getLesson(id: number): Promise<Lesson | undefined>;
  getLessonsByCourse(courseId: number): Promise<Lesson[]>;
  createLesson(lesson: InsertLesson): Promise<Lesson>;
  updateLesson(id: number, lesson: InsertLesson): Promise<Lesson | undefined>;
  deleteLesson(id: number): Promise<boolean>;
  
  // Enrollment management
  getEnrollment(id: number): Promise<Enrollment | undefined>;
  getEnrollmentsByUser(userId: number): Promise<Enrollment[]>;
  getEnrollmentsByCourse(courseId: number): Promise<Enrollment[]>;
  getEnrollmentsByTest(testId: number): Promise<Enrollment[]>;
  getPendingEnrollments(): Promise<Enrollment[]>;
  getAllEnrollments(): Promise<Enrollment[]>;
  createEnrollment(enrollment: InsertEnrollment): Promise<Enrollment>;
  approveEnrollment(id: number, adminId: number): Promise<Enrollment | undefined>;
  rejectEnrollment(id: number, adminId: number): Promise<Enrollment | undefined>;
  updateEnrollmentProgress(id: number, progress: number): Promise<Enrollment | undefined>;
  
  // Test management
  getTests(): Promise<Test[]>;
  getTest(id: number): Promise<Test | undefined>;
  getTestsByCourse(courseId: number): Promise<Test[]>;
  createTest(test: InsertTest): Promise<Test>;
  updateTest(id: number, test: InsertTest): Promise<Test | undefined>;
  deleteTest(id: number): Promise<boolean>;
  getTestCount(): Promise<number>;
  
  // Question management
  getQuestion(id: number): Promise<Question | undefined>;
  getQuestionsByTest(testId: number): Promise<Question[]>;
  createQuestion(question: InsertQuestion): Promise<Question>;
  updateQuestion(id: number, question: InsertQuestion): Promise<Question | undefined>;
  deleteQuestion(id: number): Promise<boolean>;
  
  // Test attempt management
  getTestAttempt(id: number): Promise<TestAttempt | undefined>;
  getTestAttemptsByUser(userId: number): Promise<TestAttempt[]>;
  getTestAttemptsByTest(testId: number): Promise<TestAttempt[]>;
  getAllTestAttempts(): Promise<TestAttempt[]>;
  createTestAttempt(testAttempt: InsertTestAttempt): Promise<TestAttempt>;
  submitTestAttempt(id: number, data: Partial<TestAttempt>): Promise<TestAttempt | undefined>;
  
  // Session management
  getSession(id: number): Promise<Session | undefined>;
  getSessionsByUser(userId: number): Promise<Session[]>;
  getAllSessions(): Promise<Session[]>;
  createSession(session: InsertSession): Promise<Session>;
  updateSession(id: number, sessionData: InsertSession): Promise<Session | undefined>;
  deleteSession(id: number): Promise<boolean>;
  getSessionCount(): Promise<number>;
  
  // Analytics
  getAverageTestScores(): Promise<{courseId: number, courseName: string, averageScore: number}[]>;
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;

  constructor() {
    this.sessionStore = pool 
      ? new PostgresSessionStore({ 
          pool, 
          createTableIfMissing: true,
          tableName: 'session' 
        }) 
      : new MemoryStore({
          checkPeriod: 86400000 // prune expired entries every 24h
        });
  }

  // User management
  async getUser(id: number): Promise<User | undefined> {
    if (!db) return undefined;
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    if (!db) return undefined;
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    if (!db) return undefined;
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getUsers(): Promise<User[]> {
    if (!db) return [];
    return await db.select().from(users).orderBy(users.name);
  }

  async createUser(user: InsertUser): Promise<User> {
    if (!db) throw new Error("Database not initialized");
    const [created] = await db.insert(users).values(user).returning();
    return created;
  }

  async getUserCount(): Promise<number> {
    if (!db) return 0;
    const [result] = await db.select({ count: sql`count(*)` }).from(users);
    return Number(result.count);
  }

  // Course management
  async getCourses(): Promise<Course[]> {
    if (!db) return [];
    return await db.select().from(courses).orderBy(courses.title);
  }

  async getCourse(id: number): Promise<Course | undefined> {
    if (!db) return undefined;
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    if (!db) throw new Error("Database not initialized");
    const [created] = await db.insert(courses).values(course).returning();
    return created;
  }

  async updateCourse(id: number, course: InsertCourse): Promise<Course | undefined> {
    if (!db) return undefined;
    const [updated] = await db.update(courses)
      .set({ ...course, updatedAt: new Date() })
      .where(eq(courses.id, id))
      .returning();
    return updated;
  }

  async deleteCourse(id: number): Promise<boolean> {
    if (!db) return false;
    const [deleted] = await db.delete(courses).where(eq(courses.id, id)).returning();
    return !!deleted;
  }

  async getCourseCount(): Promise<number> {
    if (!db) return 0;
    const [result] = await db.select({ count: sql`count(*)` }).from(courses);
    return Number(result.count);
  }

  // Lesson management
  async getLesson(id: number): Promise<Lesson | undefined> {
    if (!db) return undefined;
    const [lesson] = await db.select().from(lessons).where(eq(lessons.id, id));
    return lesson;
  }

  async getLessonsByCourse(courseId: number): Promise<Lesson[]> {
    if (!db) return [];
    return await db.select()
      .from(lessons)
      .where(eq(lessons.courseId, courseId))
      .orderBy(lessons.order);
  }

  async createLesson(lesson: InsertLesson): Promise<Lesson> {
    if (!db) throw new Error("Database not initialized");
    const [created] = await db.insert(lessons).values(lesson).returning();
    return created;
  }

  async updateLesson(id: number, lesson: InsertLesson): Promise<Lesson | undefined> {
    if (!db) return undefined;
    const [updated] = await db.update(lessons)
      .set({ ...lesson, updatedAt: new Date() })
      .where(eq(lessons.id, id))
      .returning();
    return updated;
  }

  async deleteLesson(id: number): Promise<boolean> {
    if (!db) return false;
    const [deleted] = await db.delete(lessons).where(eq(lessons.id, id)).returning();
    return !!deleted;
  }

  // Enrollment management
  async getEnrollment(id: number): Promise<Enrollment | undefined> {
    if (!db) return undefined;
    const [enrollment] = await db.select().from(enrollments).where(eq(enrollments.id, id));
    return enrollment;
  }

  async getEnrollmentsByUser(userId: number): Promise<Enrollment[]> {
    if (!db) return [];
    return await db.select()
      .from(enrollments)
      .where(eq(enrollments.userId, userId));
  }

  async getEnrollmentsByCourse(courseId: number): Promise<Enrollment[]> {
    if (!db) return [];
    return await db.select()
      .from(enrollments)
      .where(eq(enrollments.courseId, courseId));
  }
  
  async getEnrollmentsByTest(testId: number): Promise<Enrollment[]> {
    if (!db) return [];
    return await db.select()
      .from(enrollments)
      .where(eq(enrollments.testId, testId));
  }
  
  async getPendingEnrollments(): Promise<Enrollment[]> {
    if (!db) return [];
    return await db.select()
      .from(enrollments)
      .where(eq(enrollments.status, "pending"))
      .orderBy(desc(enrollments.enrolledAt));
  }

  async getAllEnrollments(): Promise<Enrollment[]> {
    if (!db) return [];
    return await db.select().from(enrollments).orderBy(desc(enrollments.enrolledAt));
  }

  async createEnrollment(enrollment: InsertEnrollment): Promise<Enrollment> {
    if (!db) throw new Error("Database not initialized");
    
    // Set default values for new fields if not provided
    const enrollmentData = {
      ...enrollment,
      enrollmentType: enrollment.enrollmentType || (enrollment.testId ? "test" : "course"),
      status: enrollment.status || "pending"
    };
    
    const [created] = await db.insert(enrollments).values(enrollmentData).returning();
    return created;
  }
  
  async approveEnrollment(id: number, adminId: number): Promise<Enrollment | undefined> {
    if (!db) return undefined;
    
    const [updated] = await db.update(enrollments)
      .set({
        status: "approved",
        approvedAt: new Date(),
        approvedBy: adminId
      })
      .where(eq(enrollments.id, id))
      .returning();
    
    return updated;
  }
  
  async rejectEnrollment(id: number, adminId: number): Promise<Enrollment | undefined> {
    if (!db) return undefined;
    
    const [updated] = await db.update(enrollments)
      .set({
        status: "rejected",
        rejectedAt: new Date(),
        approvedBy: adminId
      })
      .where(eq(enrollments.id, id))
      .returning();
    
    return updated;
  }

  async updateEnrollmentProgress(id: number, progress: number): Promise<Enrollment | undefined> {
    if (!db) return undefined;
    
    const data: Partial<Enrollment> = { progress };
    
    // If progress is 100%, mark as completed
    if (progress === 100) {
      data.completedAt = new Date();
      data.status = "completed";
    }
    
    const [updated] = await db.update(enrollments)
      .set(data)
      .where(eq(enrollments.id, id))
      .returning();
    
    return updated;
  }

  // Test management
  async getTests(): Promise<Test[]> {
    if (!db) return [];
    return await db.select().from(tests).orderBy(tests.title);
  }

  async getTest(id: number): Promise<Test | undefined> {
    if (!db) return undefined;
    const [test] = await db.select().from(tests).where(eq(tests.id, id));
    return test;
  }

  async getTestsByCourse(courseId: number): Promise<Test[]> {
    if (!db) return [];
    return await db.select()
      .from(tests)
      .where(eq(tests.courseId, courseId))
      .orderBy(tests.title);
  }

  async createTest(test: InsertTest): Promise<Test> {
    if (!db) throw new Error("Database not initialized");
    const [created] = await db.insert(tests).values(test).returning();
    return created;
  }

  async updateTest(id: number, test: InsertTest): Promise<Test | undefined> {
    if (!db) return undefined;
    const [updated] = await db.update(tests)
      .set({ ...test, updatedAt: new Date() })
      .where(eq(tests.id, id))
      .returning();
    return updated;
  }

  async deleteTest(id: number): Promise<boolean> {
    if (!db) return false;
    const [deleted] = await db.delete(tests).where(eq(tests.id, id)).returning();
    return !!deleted;
  }

  async getTestCount(): Promise<number> {
    if (!db) return 0;
    const [result] = await db.select({ count: sql`count(*)` }).from(tests);
    return Number(result.count);
  }

  // Question management
  async getQuestion(id: number): Promise<Question | undefined> {
    if (!db) return undefined;
    const [question] = await db.select().from(questions).where(eq(questions.id, id));
    return question;
  }

  async getQuestionsByTest(testId: number): Promise<Question[]> {
    if (!db) return [];
    return await db.select()
      .from(questions)
      .where(eq(questions.testId, testId))
      .orderBy(questions.order);
  }

  async createQuestion(question: InsertQuestion): Promise<Question> {
    if (!db) throw new Error("Database not initialized");
    const [created] = await db.insert(questions).values(question).returning();
    return created;
  }

  async updateQuestion(id: number, question: InsertQuestion): Promise<Question | undefined> {
    if (!db) return undefined;
    const [updated] = await db.update(questions)
      .set(question)
      .where(eq(questions.id, id))
      .returning();
    return updated;
  }

  async deleteQuestion(id: number): Promise<boolean> {
    if (!db) return false;
    const [deleted] = await db.delete(questions).where(eq(questions.id, id)).returning();
    return !!deleted;
  }

  // Test attempt management
  async getTestAttempt(id: number): Promise<TestAttempt | undefined> {
    if (!db) return undefined;
    const [attempt] = await db.select().from(testAttempts).where(eq(testAttempts.id, id));
    return attempt;
  }

  async getTestAttemptsByUser(userId: number): Promise<TestAttempt[]> {
    if (!db) return [];
    return await db.select()
      .from(testAttempts)
      .where(eq(testAttempts.userId, userId))
      .orderBy(desc(testAttempts.startedAt));
  }

  async getTestAttemptsByTest(testId: number): Promise<TestAttempt[]> {
    if (!db) return [];
    return await db.select()
      .from(testAttempts)
      .where(eq(testAttempts.testId, testId))
      .orderBy(desc(testAttempts.startedAt));
  }

  async getAllTestAttempts(): Promise<TestAttempt[]> {
    if (!db) return [];
    return await db.select().from(testAttempts).orderBy(desc(testAttempts.startedAt));
  }

  async createTestAttempt(testAttempt: InsertTestAttempt): Promise<TestAttempt> {
    if (!db) throw new Error("Database not initialized");
    const [created] = await db.insert(testAttempts).values(testAttempt).returning();
    return created;
  }

  async submitTestAttempt(id: number, data: Partial<TestAttempt>): Promise<TestAttempt | undefined> {
    if (!db) return undefined;
    const [updated] = await db.update(testAttempts)
      .set(data)
      .where(eq(testAttempts.id, id))
      .returning();
    return updated;
  }

  // Session management
  async getSession(id: number): Promise<Session | undefined> {
    if (!db) return undefined;
    const [session] = await db.select().from(sessions).where(eq(sessions.id, id));
    return session;
  }

  async getSessionsByUser(userId: number): Promise<Session[]> {
    if (!db) return [];
    return await db.select()
      .from(sessions)
      .where(
        or(
          eq(sessions.userId, userId),
          isNull(sessions.userId)
        )
      )
      .orderBy(sessions.sessionDate);
  }

  async getAllSessions(): Promise<Session[]> {
    if (!db) return [];
    return await db.select().from(sessions).orderBy(sessions.sessionDate);
  }

  async createSession(sessionData: InsertSession): Promise<Session> {
    if (!db) throw new Error("Database not initialized");
    const [created] = await db.insert(sessions).values(sessionData).returning();
    return created;
  }

  async updateSession(id: number, sessionData: InsertSession): Promise<Session | undefined> {
    if (!db) return undefined;
    const [updated] = await db.update(sessions)
      .set(sessionData)
      .where(eq(sessions.id, id))
      .returning();
    return updated;
  }

  async deleteSession(id: number): Promise<boolean> {
    if (!db) return false;
    const [deleted] = await db.delete(sessions).where(eq(sessions.id, id)).returning();
    return !!deleted;
  }

  async getSessionCount(): Promise<number> {
    if (!db) return 0;
    const [result] = await db.select({ count: sql`count(*)` }).from(sessions);
    return Number(result.count);
  }

  // Analytics
  async getAverageTestScores(): Promise<{courseId: number, courseName: string, averageScore: number}[]> {
    if (!db) return [];
    
    const result = await db.execute(sql`
      SELECT c.id AS "courseId", c.title AS "courseName", AVG(ta.percentage) AS "averageScore"
      FROM ${testAttempts} ta
      JOIN ${tests} t ON ta.test_id = t.id
      JOIN ${courses} c ON t.course_id = c.id
      WHERE ta.status = 'completed'
      GROUP BY c.id, c.title
      ORDER BY c.title
    `);
    
    return result.rows.map(row => ({
      courseId: Number(row.courseId),
      courseName: String(row.courseName),
      averageScore: Number(row.averageScore)
    }));
  }
}

// Memory storage implementation
export class MemStorage implements IStorage {
  private userMap: Map<number, User>;
  private courseMap: Map<number, Course>;
  private lessonMap: Map<number, Lesson>;
  private enrollmentMap: Map<number, Enrollment>;
  private testMap: Map<number, Test>;
  private questionMap: Map<number, Question>;
  private testAttemptMap: Map<number, TestAttempt>;
  private sessionMap: Map<number, Session>;
  sessionStore: session.SessionStore;
  private currentId: {
    user: number;
    course: number;
    lesson: number;
    enrollment: number;
    test: number;
    question: number;
    testAttempt: number;
    session: number;
  };

  constructor() {
    this.userMap = new Map();
    this.courseMap = new Map();
    this.lessonMap = new Map();
    this.enrollmentMap = new Map();
    this.testMap = new Map();
    this.questionMap = new Map();
    this.testAttemptMap = new Map();
    this.sessionMap = new Map();
    this.currentId = {
      user: 1,
      course: 1,
      lesson: 1,
      enrollment: 1,
      test: 1,
      question: 1,
      testAttempt: 1,
      session: 1,
    };
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
  }

  // User management
  async getUser(id: number): Promise<User | undefined> {
    return this.userMap.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.userMap.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.userMap.values()).find(
      (user) => user.email === email,
    );
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.userMap.values()).sort((a, b) => a.fullName.localeCompare(b.fullName));
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.currentId.user++;
    const now = new Date();
    const newUser: User = { 
      ...user, 
      id, 
      createdAt: now
    };
    this.userMap.set(id, newUser);
    return newUser;
  }

  async getUserCount(): Promise<number> {
    return this.userMap.size;
  }

  // Course management
  async getCourses(): Promise<Course[]> {
    return Array.from(this.courseMap.values()).sort((a, b) => a.title.localeCompare(b.title));
  }

  async getCourse(id: number): Promise<Course | undefined> {
    return this.courseMap.get(id);
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    const id = this.currentId.course++;
    const now = new Date();
    const newCourse: Course = { 
      ...course, 
      id, 
      createdAt: now, 
      updatedAt: now 
    };
    this.courseMap.set(id, newCourse);
    return newCourse;
  }

  async updateCourse(id: number, course: InsertCourse): Promise<Course | undefined> {
    const existing = this.courseMap.get(id);
    if (!existing) return undefined;
    
    const updated: Course = { 
      ...existing, 
      ...course, 
      id, 
      updatedAt: new Date()
    };
    this.courseMap.set(id, updated);
    return updated;
  }

  async deleteCourse(id: number): Promise<boolean> {
    return this.courseMap.delete(id);
  }

  async getCourseCount(): Promise<number> {
    return this.courseMap.size;
  }

  // Lesson management
  async getLesson(id: number): Promise<Lesson | undefined> {
    return this.lessonMap.get(id);
  }

  async getLessonsByCourse(courseId: number): Promise<Lesson[]> {
    return Array.from(this.lessonMap.values())
      .filter(lesson => lesson.courseId === courseId)
      .sort((a, b) => a.order - b.order);
  }

  async createLesson(lesson: InsertLesson): Promise<Lesson> {
    const id = this.currentId.lesson++;
    const now = new Date();
    const newLesson: Lesson = { 
      ...lesson, 
      id, 
      createdAt: now, 
      updatedAt: now 
    };
    this.lessonMap.set(id, newLesson);
    return newLesson;
  }

  async updateLesson(id: number, lesson: InsertLesson): Promise<Lesson | undefined> {
    const existing = this.lessonMap.get(id);
    if (!existing) return undefined;
    
    const updated: Lesson = { 
      ...existing, 
      ...lesson, 
      id, 
      updatedAt: new Date()
    };
    this.lessonMap.set(id, updated);
    return updated;
  }

  async deleteLesson(id: number): Promise<boolean> {
    return this.lessonMap.delete(id);
  }

  // Enrollment management
  async getEnrollment(id: number): Promise<Enrollment | undefined> {
    return this.enrollmentMap.get(id);
  }

  async getEnrollmentsByUser(userId: number): Promise<Enrollment[]> {
    return Array.from(this.enrollmentMap.values())
      .filter(enrollment => enrollment.userId === userId);
  }

  async getEnrollmentsByCourse(courseId: number): Promise<Enrollment[]> {
    return Array.from(this.enrollmentMap.values())
      .filter(enrollment => enrollment.courseId === courseId);
  }
  
  async getEnrollmentsByTest(testId: number): Promise<Enrollment[]> {
    return Array.from(this.enrollmentMap.values())
      .filter(enrollment => enrollment.testId === testId);
  }
  
  async getPendingEnrollments(): Promise<Enrollment[]> {
    return Array.from(this.enrollmentMap.values())
      .filter(enrollment => enrollment.status === "pending")
      .sort((a, b) => b.enrolledAt.getTime() - a.enrolledAt.getTime());
  }

  async getAllEnrollments(): Promise<Enrollment[]> {
    return Array.from(this.enrollmentMap.values())
      .sort((a, b) => b.enrolledAt.getTime() - a.enrolledAt.getTime());
  }

  async createEnrollment(enrollment: InsertEnrollment): Promise<Enrollment> {
    const id = this.currentId.enrollment++;
    const now = new Date();
    
    // Set default values for new fields if not provided
    const enrollmentData = {
      ...enrollment,
      enrollmentType: enrollment.enrollmentType || (enrollment.testId ? "test" : "course"),
      status: enrollment.status || "pending"
    };
    
    const newEnrollment: Enrollment = { 
      ...enrollmentData, 
      id, 
      enrolledAt: now,
      completedAt: undefined,
      approvedAt: undefined,
      approvedBy: undefined
    };
    
    this.enrollmentMap.set(id, newEnrollment);
    return newEnrollment;
  }
  
  async approveEnrollment(id: number, adminId: number): Promise<Enrollment | undefined> {
    const existing = this.enrollmentMap.get(id);
    if (!existing) return undefined;
    
    const now = new Date();
    const updated: Enrollment = { 
      ...existing, 
      status: "approved",
      approvedAt: now,
      approvedBy: adminId
    };
    
    this.enrollmentMap.set(id, updated);
    return updated;
  }
  
  async rejectEnrollment(id: number, adminId: number): Promise<Enrollment | undefined> {
    const existing = this.enrollmentMap.get(id);
    if (!existing) return undefined;
    
    const now = new Date();
    const updated: Enrollment = { 
      ...existing, 
      status: "rejected",
      rejectedAt: now,
      approvedBy: adminId
    };
    
    this.enrollmentMap.set(id, updated);
    return updated;
  }

  async updateEnrollmentProgress(id: number, progress: number): Promise<Enrollment | undefined> {
    const existing = this.enrollmentMap.get(id);
    if (!existing) return undefined;
    
    let completedAt = existing.completedAt;
    let status = existing.status;
    
    if (progress === 100 && !completedAt) {
      completedAt = new Date();
      status = "completed";
    }
    
    const updated: Enrollment = { 
      ...existing, 
      progress,
      completedAt,
      status
    };
    
    this.enrollmentMap.set(id, updated);
    return updated;
  }

  // Test management
  async getTests(): Promise<Test[]> {
    return Array.from(this.testMap.values()).sort((a, b) => a.title.localeCompare(b.title));
  }

  async getTest(id: number): Promise<Test | undefined> {
    return this.testMap.get(id);
  }

  async getTestsByCourse(courseId: number): Promise<Test[]> {
    return Array.from(this.testMap.values())
      .filter(test => test.courseId === courseId)
      .sort((a, b) => a.title.localeCompare(b.title));
  }

  async createTest(test: InsertTest): Promise<Test> {
    const id = this.currentId.test++;
    const now = new Date();
    const newTest: Test = { 
      ...test, 
      id, 
      createdAt: now, 
      updatedAt: now 
    };
    this.testMap.set(id, newTest);
    return newTest;
  }

  async updateTest(id: number, test: InsertTest): Promise<Test | undefined> {
    const existing = this.testMap.get(id);
    if (!existing) return undefined;
    
    const updated: Test = { 
      ...existing, 
      ...test, 
      id, 
      updatedAt: new Date()
    };
    this.testMap.set(id, updated);
    return updated;
  }

  async deleteTest(id: number): Promise<boolean> {
    return this.testMap.delete(id);
  }

  async getTestCount(): Promise<number> {
    return this.testMap.size;
  }

  // Question management
  async getQuestion(id: number): Promise<Question | undefined> {
    return this.questionMap.get(id);
  }

  async getQuestionsByTest(testId: number): Promise<Question[]> {
    return Array.from(this.questionMap.values())
      .filter(question => question.testId === testId)
      .sort((a, b) => a.order - b.order);
  }

  async createQuestion(question: InsertQuestion): Promise<Question> {
    const id = this.currentId.question++;
    const newQuestion: Question = { 
      ...question, 
      id 
    };
    this.questionMap.set(id, newQuestion);
    return newQuestion;
  }

  async updateQuestion(id: number, question: InsertQuestion): Promise<Question | undefined> {
    const existing = this.questionMap.get(id);
    if (!existing) return undefined;
    
    const updated: Question = { 
      ...existing, 
      ...question, 
      id 
    };
    this.questionMap.set(id, updated);
    return updated;
  }

  async deleteQuestion(id: number): Promise<boolean> {
    return this.questionMap.delete(id);
  }

  // Test attempt management
  async getTestAttempt(id: number): Promise<TestAttempt | undefined> {
    return this.testAttemptMap.get(id);
  }

  async getTestAttemptsByUser(userId: number): Promise<TestAttempt[]> {
    return Array.from(this.testAttemptMap.values())
      .filter(attempt => attempt.userId === userId)
      .sort((a, b) => b.startedAt.getTime() - a.startedAt.getTime());
  }

  async getTestAttemptsByTest(testId: number): Promise<TestAttempt[]> {
    return Array.from(this.testAttemptMap.values())
      .filter(attempt => attempt.testId === testId)
      .sort((a, b) => b.startedAt.getTime() - a.startedAt.getTime());
  }

  async getAllTestAttempts(): Promise<TestAttempt[]> {
    return Array.from(this.testAttemptMap.values())
      .sort((a, b) => b.startedAt.getTime() - a.startedAt.getTime());
  }

  async createTestAttempt(testAttempt: InsertTestAttempt): Promise<TestAttempt> {
    const id = this.currentId.testAttempt++;
    const now = new Date();
    const newAttempt: TestAttempt = { 
      ...testAttempt, 
      id,
      startedAt: now,
      completedAt: undefined
    };
    this.testAttemptMap.set(id, newAttempt);
    return newAttempt;
  }

  async submitTestAttempt(id: number, data: Partial<TestAttempt>): Promise<TestAttempt | undefined> {
    const existing = this.testAttemptMap.get(id);
    if (!existing) return undefined;
    
    const updated: TestAttempt = { 
      ...existing, 
      ...data
    };
    this.testAttemptMap.set(id, updated);
    return updated;
  }

  // Session management
  async getSession(id: number): Promise<Session | undefined> {
    return this.sessionMap.get(id);
  }

  async getSessionsByUser(userId: number): Promise<Session[]> {
    return Array.from(this.sessionMap.values())
      .filter(session => session.userId === userId || session.userId === undefined)
      .sort((a, b) => a.sessionDate.getTime() - b.sessionDate.getTime());
  }

  async getAllSessions(): Promise<Session[]> {
    return Array.from(this.sessionMap.values())
      .sort((a, b) => a.sessionDate.getTime() - b.sessionDate.getTime());
  }

  async createSession(sessionData: InsertSession): Promise<Session> {
    const id = this.currentId.session++;
    const now = new Date();
    const newSession: Session = { 
      ...sessionData, 
      id,
      createdAt: now
    };
    this.sessionMap.set(id, newSession);
    return newSession;
  }

  async updateSession(id: number, sessionData: InsertSession): Promise<Session | undefined> {
    const existing = this.sessionMap.get(id);
    if (!existing) return undefined;
    
    const updated: Session = { 
      ...existing, 
      ...sessionData,
      id
    };
    this.sessionMap.set(id, updated);
    return updated;
  }

  async deleteSession(id: number): Promise<boolean> {
    return this.sessionMap.delete(id);
  }

  async getSessionCount(): Promise<number> {
    return this.sessionMap.size;
  }

  // Analytics
  async getAverageTestScores(): Promise<{courseId: number, courseName: string, averageScore: number}[]> {
    // Create a map to track scores by course
    const courseScores: Record<number, {sum: number, count: number}> = {};
    
    // Get all completed test attempts
    const attempts = Array.from(this.testAttemptMap.values())
      .filter(attempt => attempt.status === 'completed');
    
    // Group attempts by course
    for (const attempt of attempts) {
      const test = this.testMap.get(attempt.testId);
      if (test?.courseId) {
        if (!courseScores[test.courseId]) {
          courseScores[test.courseId] = { sum: 0, count: 0 };
        }
        courseScores[test.courseId].sum += attempt.percentage || 0;
        courseScores[test.courseId].count += 1;
      }
    }
    
    // Calculate averages
    const result: {courseId: number, courseName: string, averageScore: number}[] = [];
    for (const [courseIdStr, data] of Object.entries(courseScores)) {
      const courseId = parseInt(courseIdStr);
      const course = this.courseMap.get(courseId);
      if (course && data.count > 0) {
        result.push({
          courseId,
          courseName: course.title,
          averageScore: data.sum / data.count
        });
      }
    }
    
    return result.sort((a, b) => a.courseName.localeCompare(b.courseName));
  }
}

// Export the appropriate storage implementation
// Temporarily using MemStorage due to database schema issues
export const storage = new MemStorage();
