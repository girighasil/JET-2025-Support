import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { insertCourseSchema, insertLessonSchema, insertTestSchema, 
  insertQuestionSchema, insertSessionSchema, insertTestAttemptSchema, insertEnrollmentSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);

  // User-related routes
  app.get("/api/users", async (req, res, next) => {
    try {
      if (!req.isAuthenticated() || req.user.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      const users = await storage.getUsers();
      res.json(users);
    } catch (err) {
      next(err);
    }
  });

  app.get("/api/users/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const userId = parseInt(req.params.id);
      if (req.user.id !== userId && req.user.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (err) {
      next(err);
    }
  });

  // Courses
  app.get("/api/courses", async (req, res, next) => {
    try {
      const courses = await storage.getCourses();
      res.json(courses);
    } catch (err) {
      next(err);
    }
  });

  app.get("/api/courses/:id", async (req, res, next) => {
    try {
      const courseId = parseInt(req.params.id);
      const course = await storage.getCourse(courseId);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      res.json(course);
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/admin/courses", async (req, res, next) => {
    try {
      try {
        const validatedData = insertCourseSchema.parse(req.body);
        req.body = validatedData;
      } catch (error: any) {
        return res.status(400).json({ errors: fromZodError(error) });
      }
      
      const course = await storage.createCourse(req.body);
      res.status(201).json(course);
    } catch (err) {
      next(err);
    }
  });

  app.put("/api/admin/courses/:id", async (req, res, next) => {
    try {
      const courseId = parseInt(req.params.id);
      try {
        const validatedData = insertCourseSchema.parse(req.body);
        req.body = validatedData;
      } catch (error: any) {
        return res.status(400).json({ errors: fromZodError(error) });
      }
      
      const updated = await storage.updateCourse(courseId, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      res.json(updated);
    } catch (err) {
      next(err);
    }
  });

  app.delete("/api/admin/courses/:id", async (req, res, next) => {
    try {
      const courseId = parseInt(req.params.id);
      const deleted = await storage.deleteCourse(courseId);
      if (!deleted) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      res.status(204).end();
    } catch (err) {
      next(err);
    }
  });

  // Lessons
  app.get("/api/courses/:courseId/lessons", async (req, res, next) => {
    try {
      const courseId = parseInt(req.params.courseId);
      const lessons = await storage.getLessonsByCourse(courseId);
      res.json(lessons);
    } catch (err) {
      next(err);
    }
  });

  app.get("/api/lessons/:id", async (req, res, next) => {
    try {
      const lessonId = parseInt(req.params.id);
      const lesson = await storage.getLesson(lessonId);
      if (!lesson) {
        return res.status(404).json({ message: "Lesson not found" });
      }
      res.json(lesson);
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/admin/lessons", async (req, res, next) => {
    try {
      try {
        const validatedData = insertLessonSchema.parse(req.body);
        req.body = validatedData;
      } catch (error: any) {
        return res.status(400).json({ errors: fromZodError(error) });
      }
      
      const lesson = await storage.createLesson(req.body);
      res.status(201).json(lesson);
    } catch (err) {
      next(err);
    }
  });

  app.put("/api/admin/lessons/:id", async (req, res, next) => {
    try {
      const lessonId = parseInt(req.params.id);
      try {
        const validatedData = insertLessonSchema.parse(req.body);
        req.body = validatedData;
      } catch (error: any) {
        return res.status(400).json({ errors: fromZodError(error) });
      }
      
      const updated = await storage.updateLesson(lessonId, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Lesson not found" });
      }
      
      res.json(updated);
    } catch (err) {
      next(err);
    }
  });

  app.delete("/api/admin/lessons/:id", async (req, res, next) => {
    try {
      const lessonId = parseInt(req.params.id);
      const deleted = await storage.deleteLesson(lessonId);
      if (!deleted) {
        return res.status(404).json({ message: "Lesson not found" });
      }
      
      res.status(204).end();
    } catch (err) {
      next(err);
    }
  });

  // Enrollments
  app.get("/api/enrollments", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      let enrollments;
      if (req.user.role === "admin" || req.user.role === "teacher") {
        enrollments = await storage.getAllEnrollments();
      } else {
        enrollments = await storage.getEnrollmentsByUser(req.user.id);
      }
      
      res.json(enrollments);
    } catch (err) {
      next(err);
    }
  });

  // Get pending enrollments for admin approval
  app.get("/api/admin/enrollments/pending", async (req, res, next) => {
    try {
      if (!req.isAuthenticated() || (req.user.role !== "admin" && req.user.role !== "teacher")) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const pendingEnrollments = await storage.getPendingEnrollments();
      res.json(pendingEnrollments);
    } catch (err) {
      next(err);
    }
  });
  
  // Get all enrollments for admin view
  app.get("/api/enrollments/all", async (req, res, next) => {
    try {
      if (!req.isAuthenticated() || (req.user.role !== "admin" && req.user.role !== "teacher")) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const enrollments = await storage.getAllEnrollments();
      res.json(enrollments);
    } catch (err) {
      next(err);
    }
  });

  // Get enrollments for a specific test
  app.get("/api/tests/:testId/enrollments", async (req, res, next) => {
    try {
      if (!req.isAuthenticated() || (req.user.role !== "admin" && req.user.role !== "teacher")) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const testId = parseInt(req.params.testId);
      const enrollments = await storage.getEnrollmentsByTest(testId);
      res.json(enrollments);
    } catch (err) {
      next(err);
    }
  });

  // Create a new enrollment (course or test)
  app.post("/api/enrollments", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      try {
        const validatedData = insertEnrollmentSchema.parse(req.body);
        req.body = validatedData;
      } catch (error: any) {
        return res.status(400).json({ errors: fromZodError(error) });
      }
      
      // Regular users can only enroll themselves
      if (req.user.role !== "admin" && req.body.userId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      // Check if the test/course exists
      if (req.body.testId) {
        const test = await storage.getTest(req.body.testId);
        if (!test) {
          return res.status(404).json({ message: "Test not found" });
        }
        
        // For students, verify that the test is active
        if (req.user.role === "student" && !test.isActive) {
          return res.status(403).json({ message: "Test is not available for enrollment" });
        }
      } else if (req.body.courseId) {
        const course = await storage.getCourse(req.body.courseId);
        if (!course) {
          return res.status(404).json({ message: "Course not found" });
        }
      } else {
        return res.status(400).json({ message: "Either courseId or testId must be provided" });
      }
      
      // Set status based on user role
      // If admin/teacher requests enrollment, auto-approve it
      if (req.user.role === "admin" || req.user.role === "teacher") {
        req.body.status = "approved";
        req.body.approvedBy = req.user.id;
        req.body.approvedAt = new Date();
      } else {
        req.body.status = "pending";
      }
      
      const enrollment = await storage.createEnrollment(req.body);
      res.status(201).json(enrollment);
    } catch (err) {
      next(err);
    }
  });

  // Approve an enrollment request
  app.put("/api/admin/enrollments/:id/approve", async (req, res, next) => {
    try {
      if (!req.isAuthenticated() || (req.user.role !== "admin" && req.user.role !== "teacher")) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const enrollmentId = parseInt(req.params.id);
      const enrollment = await storage.getEnrollment(enrollmentId);
      
      if (!enrollment) {
        return res.status(404).json({ message: "Enrollment not found" });
      }
      
      if (enrollment.status !== "pending") {
        return res.status(400).json({ message: "Only pending enrollments can be approved" });
      }
      
      const updated = await storage.approveEnrollment(enrollmentId, req.user.id);
      res.json(updated);
    } catch (err) {
      next(err);
    }
  });
  
  // Reject an enrollment request
  app.put("/api/admin/enrollments/:id/reject", async (req, res, next) => {
    try {
      if (!req.isAuthenticated() || (req.user.role !== "admin" && req.user.role !== "teacher")) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const enrollmentId = parseInt(req.params.id);
      const enrollment = await storage.getEnrollment(enrollmentId);
      
      if (!enrollment) {
        return res.status(404).json({ message: "Enrollment not found" });
      }
      
      if (enrollment.status !== "pending") {
        return res.status(400).json({ message: "Only pending enrollments can be rejected" });
      }
      
      const updated = await storage.rejectEnrollment(enrollmentId, req.user.id);
      res.json(updated);
    } catch (err) {
      next(err);
    }
  });

  // Update enrollment progress
  app.put("/api/enrollments/:id/progress", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const enrollmentId = parseInt(req.params.id);
      const { progress } = req.body;
      
      if (typeof progress !== "number" || progress < 0 || progress > 100) {
        return res.status(400).json({ message: "Progress must be a number between 0 and 100" });
      }
      
      const enrollment = await storage.getEnrollment(enrollmentId);
      if (!enrollment) {
        return res.status(404).json({ message: "Enrollment not found" });
      }
      
      // Verify enrollment is approved
      if (enrollment.status !== "approved" && enrollment.status !== "completed") {
        return res.status(400).json({ message: "Cannot update progress for unapproved enrollments" });
      }
      
      // Users can only update their own progress unless they're an admin
      if (req.user.role !== "admin" && enrollment.userId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const updated = await storage.updateEnrollmentProgress(enrollmentId, progress);
      res.json(updated);
    } catch (err) {
      next(err);
    }
  });

  // Tests
  app.get("/api/tests", async (req, res, next) => {
    try {
      let tests = await storage.getTests();
      
      // If the user is not an admin or teacher, only show active tests
      if (req.isAuthenticated() && req.user.role === "student") {
        tests = tests.filter(test => test.isActive);
      } else if (!req.isAuthenticated()) {
        // For unauthenticated users, only show active tests
        tests = tests.filter(test => test.isActive);
      }
      
      res.json(tests);
    } catch (err) {
      next(err);
    }
  });

  app.get("/api/courses/:courseId/tests", async (req, res, next) => {
    try {
      const courseId = parseInt(req.params.courseId);
      let tests = await storage.getTestsByCourse(courseId);
      
      // If the user is not an admin or teacher, only show active tests
      if (req.isAuthenticated() && req.user.role === "student") {
        tests = tests.filter(test => test.isActive);
      } else if (!req.isAuthenticated()) {
        // For unauthenticated users, only show active tests
        tests = tests.filter(test => test.isActive);
      }
      
      res.json(tests);
    } catch (err) {
      next(err);
    }
  });

  app.get("/api/tests/:id", async (req, res, next) => {
    try {
      const testId = parseInt(req.params.id);
      const test = await storage.getTest(testId);
      
      if (!test) {
        return res.status(404).json({ message: "Test not found" });
      }
      
      // If the user is not an admin or teacher, only allow access to active tests
      if (req.isAuthenticated() && req.user.role === "student" && !test.isActive) {
        return res.status(403).json({ message: "Test is not available" });
      } else if (!req.isAuthenticated() && !test.isActive) {
        return res.status(403).json({ message: "Test is not available" });
      }
      
      res.json(test);
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/admin/tests", async (req, res, next) => {
    try {
      try {
        const validatedData = insertTestSchema.parse(req.body);
        req.body = validatedData;
      } catch (error: any) {
        return res.status(400).json({ errors: fromZodError(error) });
      }
      
      const test = await storage.createTest(req.body);
      res.status(201).json(test);
    } catch (err) {
      next(err);
    }
  });

  app.put("/api/admin/tests/:id", async (req, res, next) => {
    try {
      const testId = parseInt(req.params.id);
      try {
        const validatedData = insertTestSchema.parse(req.body);
        req.body = validatedData;
      } catch (error: any) {
        return res.status(400).json({ errors: fromZodError(error) });
      }
      
      const updated = await storage.updateTest(testId, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Test not found" });
      }
      
      res.json(updated);
    } catch (err) {
      next(err);
    }
  });

  app.delete("/api/admin/tests/:id", async (req, res, next) => {
    try {
      const testId = parseInt(req.params.id);
      const deleted = await storage.deleteTest(testId);
      if (!deleted) {
        return res.status(404).json({ message: "Test not found" });
      }
      
      res.status(204).end();
    } catch (err) {
      next(err);
    }
  });

  // Questions
  app.get("/api/tests/:testId/questions", async (req, res, next) => {
    try {
      const testId = parseInt(req.params.testId);
      const questions = await storage.getQuestionsByTest(testId);
      res.json(questions);
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/admin/questions", async (req, res, next) => {
    try {
      try {
        const validatedData = insertQuestionSchema.parse(req.body);
        req.body = validatedData;
      } catch (error: any) {
        return res.status(400).json({ errors: fromZodError(error) });
      }
      
      const question = await storage.createQuestion(req.body);
      res.status(201).json(question);
    } catch (err) {
      next(err);
    }
  });

  app.put("/api/admin/questions/:id", async (req, res, next) => {
    try {
      const questionId = parseInt(req.params.id);
      try {
        const validatedData = insertQuestionSchema.parse(req.body);
        req.body = validatedData;
      } catch (error: any) {
        return res.status(400).json({ errors: fromZodError(error) });
      }
      
      const updated = await storage.updateQuestion(questionId, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Question not found" });
      }
      
      res.json(updated);
    } catch (err) {
      next(err);
    }
  });

  app.delete("/api/admin/questions/:id", async (req, res, next) => {
    try {
      const questionId = parseInt(req.params.id);
      const deleted = await storage.deleteQuestion(questionId);
      if (!deleted) {
        return res.status(404).json({ message: "Question not found" });
      }
      
      res.status(204).end();
    } catch (err) {
      next(err);
    }
  });

  // Test Attempts
  app.get("/api/test-attempts", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      let attempts;
      if (req.user.role === "admin") {
        attempts = await storage.getAllTestAttempts();
      } else {
        attempts = await storage.getTestAttemptsByUser(req.user.id);
      }
      
      res.json(attempts);
    } catch (err) {
      next(err);
    }
  });

  app.get("/api/test-attempts/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const attemptId = parseInt(req.params.id);
      const attempt = await storage.getTestAttempt(attemptId);
      
      if (!attempt) {
        return res.status(404).json({ message: "Test attempt not found" });
      }
      
      // Users can only view their own attempts unless they're admins
      if (req.user.role !== "admin" && attempt.userId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      res.json(attempt);
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/test-attempts", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      try {
        const validatedData = insertTestAttemptSchema.parse(req.body);
        req.body = validatedData;
      } catch (error: any) {
        return res.status(400).json({ errors: fromZodError(error) });
      }
      
      // Users can only create attempts for themselves
      if (req.body.userId !== req.user.id && req.user.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const attempt = await storage.createTestAttempt(req.body);
      res.status(201).json(attempt);
    } catch (err) {
      next(err);
    }
  });

  app.put("/api/test-attempts/:id/submit", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const attemptId = parseInt(req.params.id);
      const attempt = await storage.getTestAttempt(attemptId);
      
      if (!attempt) {
        return res.status(404).json({ message: "Test attempt not found" });
      }
      
      // Users can only submit their own attempts
      if (attempt.userId !== req.user.id && req.user.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const { answers } = req.body;
      if (!answers || typeof answers !== "object") {
        return res.status(400).json({ message: "Invalid answers format" });
      }
      
      // Auto-grade the test
      const questions = await storage.getQuestionsByTest(attempt.testId);
      let score = 0;
      let maxScore = 0;
      
      questions.forEach(question => {
        maxScore += question.marks;
        const userAnswer = answers[question.id];
        if (userAnswer === question.correctOption) {
          score += question.marks;
        }
      });
      
      const percentage = (score / maxScore) * 100;
      
      const updated = await storage.submitTestAttempt(attemptId, {
        answers,
        score,
        maxScore,
        percentage,
        status: "completed",
        completedAt: new Date(),
      });
      
      res.json(updated);
    } catch (err) {
      next(err);
    }
  });

  // Sessions
  app.get("/api/sessions", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      let sessions;
      if (req.user.role === "admin") {
        sessions = await storage.getAllSessions();
      } else {
        // For students, get sessions where they are the user or sessions without a specific user (group sessions)
        sessions = await storage.getSessionsByUser(req.user.id);
      }
      
      res.json(sessions);
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/sessions", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      try {
        const validatedData = insertSessionSchema.parse(req.body);
        req.body = validatedData;
      } catch (error: any) {
        return res.status(400).json({ errors: fromZodError(error) });
      }
      
      // Students can only schedule sessions for themselves
      if (req.user.role !== "admin" && req.body.userId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const session = await storage.createSession(req.body);
      res.status(201).json(session);
    } catch (err) {
      next(err);
    }
  });

  app.put("/api/admin/sessions/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated() || req.user.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const sessionId = parseInt(req.params.id);
      try {
        const validatedData = insertSessionSchema.parse(req.body);
        req.body = validatedData;
      } catch (error: any) {
        return res.status(400).json({ errors: fromZodError(error) });
      }
      
      const updated = await storage.updateSession(sessionId, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Session not found" });
      }
      
      res.json(updated);
    } catch (err) {
      next(err);
    }
  });

  app.delete("/api/admin/sessions/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated() || req.user.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const sessionId = parseInt(req.params.id);
      const deleted = await storage.deleteSession(sessionId);
      if (!deleted) {
        return res.status(404).json({ message: "Session not found" });
      }
      
      res.status(204).end();
    } catch (err) {
      next(err);
    }
  });
  
  // Analytics
  app.get("/api/analytics/test-scores", async (req, res, next) => {
    try {
      if (!req.isAuthenticated() || req.user.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const averageScores = await storage.getAverageTestScores();
      res.json(averageScores);
    } catch (err) {
      next(err);
    }
  });

  // Advanced Analytics Dashboard Endpoints
  app.get("/api/admin/analytics", async (req, res, next) => {
    try {
      if (!req.isAuthenticated() || req.user.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      // Get counts from storage
      const userCount = await storage.getUserCount();
      const courseCount = await storage.getCourseCount();
      const testCount = await storage.getTestCount();
      const sessionCount = await storage.getSessionCount();
      
      // Get the latest test attempts for performance metrics
      const testAttempts = await storage.getAllTestAttempts();
      
      // Calculate average test score
      let totalScore = 0;
      let totalAttempts = 0;
      
      const testScoresByType = {
        mcq: { total: 0, count: 0 },
        truefalse: { total: 0, count: 0 },
        fillblank: { total: 0, count: 0 },
        subjective: { total: 0, count: 0 }
      };
      
      // Student performance over time
      const performanceByMonth: Record<string, { total: number, count: number }> = {};
      
      testAttempts.forEach(attempt => {
        if (attempt.status === 'completed' && attempt.percentage !== null) {
          totalScore += attempt.percentage;
          totalAttempts++;
          
          // Store test performance by month
          if (attempt.completedAt) {
            const date = new Date(attempt.completedAt);
            const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
            
            if (!performanceByMonth[monthKey]) {
              performanceByMonth[monthKey] = { total: 0, count: 0 };
            }
            
            performanceByMonth[monthKey].total += attempt.percentage;
            performanceByMonth[monthKey].count++;
          }
        }
      });
      
      // Convert performance by month to array with averages
      const performanceOverTime = Object.entries(performanceByMonth).map(([month, data]) => ({
        month,
        averageScore: data.count > 0 ? data.total / data.count : 0,
        attemptCount: data.count
      })).sort((a, b) => a.month.localeCompare(b.month));
      
      // Get enrolled users by course
      const enrollments = await storage.getAllEnrollments();
      const enrollmentsByCourse: Record<number, number> = {};
      
      enrollments.forEach(enrollment => {
        if (!enrollmentsByCourse[enrollment.courseId]) {
          enrollmentsByCourse[enrollment.courseId] = 0;
        }
        enrollmentsByCourse[enrollment.courseId]++;
      });
      
      // Format the enrollment data
      const courses = await storage.getCourses();
      const courseEnrollmentData = courses.map(course => ({
        courseId: course.id,
        courseName: course.title,
        enrollmentCount: enrollmentsByCourse[course.id] || 0
      }));
      
      // Response data
      const analyticsData = {
        counts: {
          users: userCount,
          courses: courseCount,
          tests: testCount,
          sessions: sessionCount,
          testAttempts: testAttempts.length
        },
        testPerformance: {
          averageScore: totalAttempts > 0 ? totalScore / totalAttempts : 0,
          totalAttempts,
          scoresByType: Object.entries(testScoresByType).map(([type, data]) => ({
            type,
            averageScore: data.count > 0 ? data.total / data.count : 0,
            attemptCount: data.count
          }))
        },
        enrollmentData: courseEnrollmentData,
        performanceOverTime
      };
      
      res.json(analyticsData);
    } catch (err) {
      next(err);
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}