import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest } from "@/lib/queryClient";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

const registerSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(6, "Please confirm your password"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const [activeTab, setActiveTab] = useState<string>("login");
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user, loginMutation, registerMutation } = useAuth();
  const [isPendingLogin, setIsPendingLogin] = useState(false);
  const [isPendingRegister, setIsPendingRegister] = useState(false);
  
  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      if (user.role === "admin" || user.role === "teacher") {
        navigate("/admin/dashboard");
      } else {
        navigate("/student/dashboard");
      }
    }
  }, [user, navigate]);

  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      name: "",
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
  });

  const onLoginSubmit = async (values: LoginFormValues) => {
    // If we have access to the auth context, use it
    if (loginMutation) {
      loginMutation.mutate(values);
    } else {
      // Fallback to direct API call
      try {
        setIsPendingLogin(true);
        const res = await apiRequest("POST", "/api/login", values);
        const user = await res.json();
        
        toast({
          title: "Login successful",
          description: `Welcome back, ${user.name}!`,
        });
        
        // Redirect to the appropriate dashboard
        if (user.role === "admin" || user.role === "teacher") {
          navigate("/admin/dashboard");
        } else {
          navigate("/student/dashboard");
        }
      } catch (error: any) {
        toast({
          title: "Login failed",
          description: error.message || "An error occurred during login",
          variant: "destructive",
        });
      } finally {
        setIsPendingLogin(false);
      }
    }
  };

  const onRegisterSubmit = async (values: RegisterFormValues) => {
    const { confirmPassword, ...data } = values;
    const userData = {
      ...data,
      role: "student", // Default role for new registrations
    };

    // If we have access to the auth context, use it
    if (registerMutation) {
      registerMutation.mutate(userData);
    } else {
      // Fallback to direct API call
      try {
        setIsPendingRegister(true);
        
        const res = await apiRequest("POST", "/api/register", userData);
        const user = await res.json();
        
        toast({
          title: "Registration successful",
          description: `Welcome to Maths Magic Town, ${user.name}!`,
        });
        
        // Redirect to the student dashboard
        navigate("/student/dashboard");
      } catch (error: any) {
        toast({
          title: "Registration failed",
          description: error.message || "An error occurred during registration",
          variant: "destructive",
        });
      } finally {
        setIsPendingRegister(false);
      }
    }
  };

  const loginDemoAccount = async (type: 'admin' | 'student' | 'teacher') => {
    const credentials = 
      type === 'admin' ? { username: 'admin', password: 'admin123' } :
      type === 'teacher' ? { username: 'teacher', password: 'teacher123' } :
      { username: 'student', password: 'student123' };

    // If we have access to the auth context, use it
    if (loginMutation) {
      loginMutation.mutate(credentials);
    } else {
      // Fallback to direct API call
      try {
        setIsPendingLogin(true);
        
        const res = await apiRequest("POST", "/api/login", credentials);
        const user = await res.json();
        
        toast({
          title: "Login successful",
          description: `Welcome back, ${user.name}!`,
        });
        
        // Redirect to the appropriate dashboard
        if (user.role === "admin" || user.role === "teacher") {
          navigate("/admin/dashboard");
        } else {
          navigate("/student/dashboard");
        }
      } catch (error: any) {
        toast({
          title: "Login failed",
          description: error.message || "An error occurred during login",
          variant: "destructive",
        });
      } finally {
        setIsPendingLogin(false);
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-600 to-secondary-600 px-4">
      <div className="grid md:grid-cols-2 w-full max-w-6xl bg-white rounded-lg shadow-xl overflow-hidden">
        {/* Form Section */}
        <div className="p-6 md:p-10">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-800">Maths Magic Town</h1>
            <p className="text-gray-600 mt-2">Personalized learning for competitive exam preparation</p>
          </div>

          <Tabs defaultValue="login" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-2 w-full mb-8">
              <TabsTrigger value="login">Sign In</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <Form {...loginForm}>
                <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-6">
                  <FormField
                    control={loginForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your username" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={loginForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="••••••••" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={isPendingLogin}
                  >
                    {isPendingLogin ? (
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    ) : null}
                    Sign In
                  </Button>
                </form>
              </Form>

              <div className="mt-6">
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-gray-300"></div>
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-2 bg-white text-gray-500">Demo accounts</span>
                  </div>
                </div>
                
                <div className="mt-6 grid grid-cols-3 gap-3">
                  <Button 
                    variant="outline" 
                    onClick={() => loginDemoAccount('admin')}
                    disabled={isPendingLogin}
                  >
                    Admin Login
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => loginDemoAccount('teacher')}
                    disabled={isPendingLogin}
                  >
                    Teacher Login
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => loginDemoAccount('student')}
                    disabled={isPendingLogin}
                  >
                    Student Login
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="register">
              <Form {...registerForm}>
                <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                  <FormField
                    control={registerForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name</FormLabel>
                        <FormControl>
                          <Input placeholder="John Smith" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={registerForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input placeholder="johnsmith" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={registerForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="john@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={registerForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="••••••••" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={registerForm.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Confirm Password</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="••••••••" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={isPendingRegister}
                  >
                    {isPendingRegister ? (
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    ) : null}
                    Create Account
                  </Button>
                </form>
              </Form>
            </TabsContent>
          </Tabs>

          <p className="text-center text-sm text-gray-600 mt-6">
            {activeTab === "login" ? (
              <>
                Don't have an account?{" "}
                <Button variant="link" className="p-0 h-auto" onClick={() => setActiveTab("register")}>
                  Register now
                </Button>
              </>
            ) : (
              <>
                Already have an account?{" "}
                <Button variant="link" className="p-0 h-auto" onClick={() => setActiveTab("login")}>
                  Sign in
                </Button>
              </>
            )}
          </p>
        </div>

        {/* Hero Section */}
        <div className="hidden md:block bg-gradient-to-br from-primary-600 to-primary-800 text-white p-10 flex items-center">
          <div>
            <h2 className="text-3xl font-bold mb-6">Adaptive Learning Platform</h2>
            <ul className="space-y-4">
              <li className="flex items-start">
                <svg className="h-6 w-6 mr-2 text-accent-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Comprehensive online courses for competitive exams</span>
              </li>
              <li className="flex items-start">
                <svg className="h-6 w-6 mr-2 text-accent-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Interactive video lessons with expert instructors</span>
              </li>
              <li className="flex items-start">
                <svg className="h-6 w-6 mr-2 text-accent-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Practice tests with auto-grading and detailed solutions</span>
              </li>
              <li className="flex items-start">
                <svg className="h-6 w-6 mr-2 text-accent-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Track your progress and identify areas for improvement</span>
              </li>
              <li className="flex items-start">
                <svg className="h-6 w-6 mr-2 text-accent-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>One-on-one doubt resolution sessions with teachers</span>
              </li>
            </ul>

            <div className="mt-8 p-4 bg-white/10 rounded-lg border border-white/20">
              <p className="text-sm italic">
                "Maths Magic Town's platform was crucial for my JEE preparation. The personalized approach and interactive content helped me secure a top rank!"
                <br />
                <span className="font-semibold mt-2 block">— Rahul Sharma, IIT Delhi</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}