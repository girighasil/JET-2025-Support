import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

export default function HomePage() {
  const [, navigate] = useLocation();
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // Temporary solution: Just redirect to auth page
    const timer = setTimeout(() => {
      setIsLoading(false);
      navigate("/auth");
    }, 500); // Brief delay to show loading
    
    return () => clearTimeout(timer);
  }, [navigate]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gradient-to-br from-primary-600 to-primary-800">
        <Loader2 className="h-8 w-8 animate-spin text-white" />
      </div>
    );
  }
  
  return (
    <div className="flex items-center justify-center h-screen bg-gradient-to-br from-primary-600 to-primary-800 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-center">Maths Magic Town</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <p className="text-center text-muted-foreground">
            Welcome to the Maths Magic Town educational platform.
          </p>
          <Button 
            className="w-full" 
            onClick={() => navigate("/auth")}
          >
            Login or Register
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
