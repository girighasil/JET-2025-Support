import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { DataTable } from "@/components/ui/data-table";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { CalendarClock, Clock, Users, User } from "lucide-react";
import AdminLayout from "@/layouts/admin-layout";

const sessionSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(5, "Description must be at least 5 characters"),
  date: z.date(),
  startTime: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "Please enter a valid time in 24-hour format (HH:MM)"),
  duration: z.number().min(15, "Session must be at least 15 minutes").max(180, "Session must not exceed 3 hours"),
  type: z.enum(["one-on-one", "group"]),
  maxStudents: z.number().min(1).optional(),
  userId: z.number().optional(),
});

type Session = {
  id: number;
  title: string;
  description: string;
  date: string;
  startTime: string;
  duration: number;
  type: "one-on-one" | "group";
  maxStudents: number | null;
  userId: number | null;
  createdAt: string;
  status: "scheduled" | "completed" | "cancelled";
};

const columns = [
  {
    accessorKey: "title",
    header: "Title",
  },
  {
    accessorKey: "date",
    header: "Date",
    cell: ({ row }) => {
      return format(new Date(row.original.date), "PPP");
    },
  },
  {
    accessorKey: "startTime",
    header: "Time",
  },
  {
    accessorKey: "duration",
    header: "Duration (mins)",
  },
  {
    accessorKey: "type",
    header: "Type",
    cell: ({ row }) => {
      return (
        <div className="flex items-center">
          {row.original.type === "one-on-one" ? (
            <User className="mr-2 h-4 w-4" />
          ) : (
            <Users className="mr-2 h-4 w-4" />
          )}
          {row.original.type === "one-on-one" ? "One-on-One" : "Group"}
        </div>
      );
    },
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const status = row.original.status;
      return (
        <div className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
          status === "scheduled" ? "bg-blue-100 text-blue-800" :
          status === "completed" ? "bg-green-100 text-green-800" :
          "bg-red-100 text-red-800"
        }`}>
          {status.charAt(0).toUpperCase() + status.slice(1)}
        </div>
      );
    },
  },
  {
    id: "actions",
    cell: ({ row }) => {
      return (
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" className="h-8 w-8 p-0">
            <span className="sr-only">Edit</span>
            <i className="fas fa-edit"></i>
          </Button>
          <Button variant="outline" size="sm" className="h-8 w-8 p-0">
            <span className="sr-only">Cancel</span>
            <i className="fas fa-times"></i>
          </Button>
        </div>
      );
    },
  },
];

export default function SessionSchedule() {
  const { toast } = useToast();
  const [date, setDate] = useState<Date | undefined>(new Date());
  
  const form = useForm<z.infer<typeof sessionSchema>>({
    resolver: zodResolver(sessionSchema),
    defaultValues: {
      title: "",
      description: "",
      date: new Date(),
      startTime: "09:00",
      duration: 60,
      type: "one-on-one",
      maxStudents: 1,
    },
  });
  
  // Get all sessions
  const { data: sessions = [], isLoading, isError } = useQuery<Session[]>({
    queryKey: ["/api/sessions"],
    refetchOnWindowFocus: false,
  });
  
  // Create session mutation
  const createSessionMutation = useMutation({
    mutationFn: async (formData: z.infer<typeof sessionSchema>) => {
      // Transform the data to match what the server expects
      const combineDateAndTime = (date: Date, timeStr: string) => {
        const [hours, minutes] = timeStr.split(':').map(Number);
        const newDate = new Date(date);
        newDate.setHours(hours, minutes, 0, 0);
        return newDate;
      };
      
      // Construct the session date by combining date and time
      const sessionDate = combineDateAndTime(formData.date, formData.startTime);
      
      // Construct payload to match the server schema
      const serverData = {
        title: formData.title,
        description: formData.description,
        sessionDate: sessionDate.toISOString(), // Format as ISO string for the API
        duration: formData.duration,
        status: "scheduled",
        // Set instructor as current user (assuming admin/teacher is scheduling)
        instructorId: form.getValues("userId") || 1, // Default to admin if not specified
        // Optional fields
        userId: formData.type === "one-on-one" ? formData.userId : undefined,
        meetingUrl: "https://meet.google.com/placeholder-link" // Placeholder for now
      };
      
      console.log("Sending session data to server:", serverData);
      
      const response = await apiRequest("POST", "/api/sessions", serverData);
      if (!response.ok) {
        const error = await response.json();
        console.error("Session creation error:", error);
        throw new Error(error.message || JSON.stringify(error) || "Failed to create session");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      toast({
        title: "Session Scheduled",
        description: "The session has been scheduled successfully.",
      });
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: z.infer<typeof sessionSchema>) => {
    createSessionMutation.mutate(data);
  };
  
  // Watch the type field to conditionally show/hide maxStudents
  const sessionType = form.watch("type");
  
  useEffect(() => {
    if (sessionType === "one-on-one") {
      form.setValue("maxStudents", 1);
    } else if (sessionType === "group" && form.getValues("maxStudents") === 1) {
      form.setValue("maxStudents", 5);
    }
  }, [sessionType, form]);
  
  return (
    <AdminLayout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Session Schedule</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Schedule New Session</CardTitle>
                <CardDescription>Create a new doubt resolution or tutorial session.</CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Session Title</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="e.g., Calculus Doubt Resolution" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              {...field} 
                              placeholder="Brief description of what will be covered" 
                              rows={3}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="date"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Date</FormLabel>
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={(date) => {
                                field.onChange(date);
                                setDate(date);
                              }}
                              disabled={(date) => {
                                // Disable dates in the past
                                return date < new Date(new Date().setHours(0, 0, 0, 0));
                              }}
                              className="border rounded-md"
                            />
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="startTime"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Start Time</FormLabel>
                            <FormControl>
                              <Input {...field} type="time" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="duration"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Duration (minutes)</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                type="number" 
                                onChange={(e) => field.onChange(parseInt(e.target.value))} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Session Type</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select session type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="one-on-one">One-on-One</SelectItem>
                              <SelectItem value="group">Group Session</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    {sessionType === "group" && (
                      <FormField
                        control={form.control}
                        name="maxStudents"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Maximum Students</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                type="number" 
                                onChange={(e) => field.onChange(parseInt(e.target.value))} 
                              />
                            </FormControl>
                            <FormDescription>
                              Maximum number of students that can join this session.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                    
                    <Button 
                      type="submit" 
                      className="w-full"
                      disabled={createSessionMutation.isPending}
                    >
                      {createSessionMutation.isPending ? "Scheduling..." : "Schedule Session"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
          
          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Upcoming Sessions</CardTitle>
                <CardDescription>View and manage all scheduled sessions.</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <p>Loading sessions...</p>
                ) : isError ? (
                  <p className="text-red-500">Error loading sessions</p>
                ) : sessions.length === 0 ? (
                  <div className="text-center py-8">
                    <CalendarClock className="h-12 w-12 mx-auto text-gray-400" />
                    <h3 className="mt-2 text-sm font-semibold">No sessions scheduled</h3>
                    <p className="mt-1 text-sm text-gray-500">Create your first session to get started.</p>
                  </div>
                ) : (
                  <DataTable columns={columns} data={sessions} />
                )}
              </CardContent>
              <CardFooter className="flex justify-between border-t px-6 py-4">
                <div className="flex items-center text-sm text-gray-500">
                  <Clock className="mr-2 h-4 w-4" />
                  <span>Showing all sessions</span>
                </div>
                <Button variant="outline" size="sm" onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/sessions"] })}>
                  Refresh
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}