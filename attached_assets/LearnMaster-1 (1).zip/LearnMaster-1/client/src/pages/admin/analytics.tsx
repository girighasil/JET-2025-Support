import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";
import AdminLayout from "@/layouts/admin-layout";
import { BookOpen, Users, Award, GraduationCap } from "lucide-react";

// Type definitions
type CourseEnrollment = {
  courseId: number;
  courseName: string;
  enrollmentCount: number;
};

type TestScore = {
  courseId: number;
  courseName: string;
  averageScore: number;
};

type StudentProgress = {
  userId: number;
  username: string;
  averageProgress: number;
  coursesEnrolled: number;
};

type OverviewStat = {
  title: string;
  value: number;
  change: number;
  icon: React.ReactNode;
};

// Mock Colors
const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8", "#82CA9D", "#FF6B6B", "#6B7FFF"];

export default function Analytics() {
  const [period, setPeriod] = useState<"week" | "month" | "year">("month");
  
  // Overview Statistics
  const { data: overviewStats, isLoading: isLoadingOverview } = useQuery<OverviewStat[]>({
    queryKey: ["/api/analytics/overview", period],
    refetchOnWindowFocus: false,
    enabled: false, // This would be enabled in a real implementation
    placeholderData: [
      {
        title: "Total Students",
        value: 142,
        change: 12,
        icon: <Users className="h-4 w-4" />,
      },
      {
        title: "Active Courses",
        value: 8,
        change: 2,
        icon: <BookOpen className="h-4 w-4" />,
      },
      {
        title: "Tests Conducted",
        value: 37,
        change: 4,
        icon: <Award className="h-4 w-4" />,
      },
      {
        title: "Average Score",
        value: 72,
        change: -3,
        icon: <GraduationCap className="h-4 w-4" />,
      },
    ],
  });
  
  // Course enrollments
  const { data: courseEnrollments, isLoading: isLoadingEnrollments } = useQuery<CourseEnrollment[]>({
    queryKey: ["/api/analytics/enrollments"],
    refetchOnWindowFocus: false,
  });
  
  // Test scores
  const { data: testScores, isLoading: isLoadingScores } = useQuery<TestScore[]>({
    queryKey: ["/api/analytics/test-scores"],
    refetchOnWindowFocus: false,
  });
  
  // Student progress
  const { data: studentProgress, isLoading: isLoadingProgress } = useQuery<StudentProgress[]>({
    queryKey: ["/api/analytics/student-progress"],
    refetchOnWindowFocus: false,
    enabled: false, // This would be enabled in a real implementation
  });
  
  // Helper function to format numbers
  const formatNumber = (num: number) => {
    return new Intl.NumberFormat().format(num);
  };
  
  return (
    <AdminLayout>
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Analytics Dashboard</h1>
          <Tabs value={period} onValueChange={(value) => setPeriod(value as "week" | "month" | "year")}>
            <TabsList>
              <TabsTrigger value="week">This Week</TabsTrigger>
              <TabsTrigger value="month">This Month</TabsTrigger>
              <TabsTrigger value="year">This Year</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
        
        {/* Overview Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {isLoadingOverview
            ? Array(4)
                .fill(0)
                .map((_, i) => (
                  <Card key={i}>
                    <CardHeader className="pb-2">
                      <Skeleton className="h-4 w-24" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-8 w-20 mb-1" />
                      <Skeleton className="h-4 w-16" />
                    </CardContent>
                  </Card>
                ))
            : overviewStats?.map((stat, i) => (
                <Card key={i}>
                  <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
                    <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                    {stat.icon}
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{formatNumber(stat.value)}</div>
                    <p className={`text-xs ${stat.change > 0 ? "text-green-500" : "text-red-500"}`}>
                      {stat.change > 0 ? "+" : ""}
                      {stat.change}% from last {period}
                    </p>
                  </CardContent>
                </Card>
              ))}
        </div>
        
        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Course Enrollments */}
          <Card>
            <CardHeader>
              <CardTitle>Course Enrollments</CardTitle>
              <CardDescription>Distribution of students across courses</CardDescription>
            </CardHeader>
            <CardContent className="h-[350px]">
              {isLoadingEnrollments ? (
                <div className="flex items-center justify-center h-full">
                  <Skeleton className="h-[300px] w-full" />
                </div>
              ) : courseEnrollments && courseEnrollments.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={courseEnrollments}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="courseName" tick={{ fontSize: 12 }} />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="enrollmentCount" name="Students Enrolled" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-full">
                  <p className="text-gray-500">No enrollment data available</p>
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Test Performance */}
          <Card>
            <CardHeader>
              <CardTitle>Test Performance</CardTitle>
              <CardDescription>Average scores by course</CardDescription>
            </CardHeader>
            <CardContent className="h-[350px]">
              {isLoadingScores ? (
                <div className="flex items-center justify-center h-full">
                  <Skeleton className="h-[300px] w-full" />
                </div>
              ) : testScores && testScores.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={testScores}
                      cx="50%"
                      cy="50%"
                      labelLine={true}
                      label={({ courseName, averageScore }) => `${courseName}: ${averageScore}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="averageScore"
                      nameKey="courseName"
                    >
                      {testScores.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `${value}%`} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-full">
                  <p className="text-gray-500">No test score data available</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        {/* Student Progress */}
        <Card>
          <CardHeader>
            <CardTitle>Student Progress Tracking</CardTitle>
            <CardDescription>Average completion percentage across enrolled courses</CardDescription>
          </CardHeader>
          <CardContent className="h-[400px]">
            {isLoadingProgress ? (
              <div className="flex items-center justify-center h-full">
                <Skeleton className="h-[350px] w-full" />
              </div>
            ) : studentProgress && studentProgress.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={studentProgress}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="username" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="averageProgress" name="Average Progress (%)" fill="#82ca9d" />
                  <Bar dataKey="coursesEnrolled" name="Courses Enrolled" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-full">
                <p className="text-gray-500">No student progress data available</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}