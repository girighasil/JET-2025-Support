import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { Check, MoreHorizontal, X, Filter, Search } from "lucide-react";
import AdminLayout from "@/layouts/admin-layout";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Course, Enrollment, Test, User } from "@shared/schema";

export default function ManageEnrollments() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState("");
  const [activeTab, setActiveTab] = useState("all");

  // Format date helper function
  const formatDate = (date?: Date | null) => {
    if (!date) return "N/A";
    return format(new Date(date), "MMM d, yyyy");
  };

  // Fetch all enrollments
  const { data: enrollments = [], isLoading: isLoadingEnrollments } = useQuery({
    queryKey: ["/api/enrollments/all"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/enrollments/all");
      return await res.json();
    },
    onError: (error: Error) => {
      toast({
        title: "Error fetching enrollments",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Fetch users for displaying names
  const { data: users = [] } = useQuery({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/users");
      return await res.json();
    },
    onError: (error: Error) => {
      toast({
        title: "Error fetching users",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Fetch tests for displaying test details
  const { data: tests = [] } = useQuery({
    queryKey: ["/api/tests"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/tests");
      return await res.json();
    },
    onError: (error: Error) => {
      toast({
        title: "Error fetching tests",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Fetch courses for displaying course details
  const { data: courses = [] } = useQuery({
    queryKey: ["/api/courses"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/courses");
      return await res.json();
    },
    onError: (error: Error) => {
      toast({
        title: "Error fetching courses",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle approve enrollment
  const approveMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("PUT", `/api/admin/enrollments/${id}/approve`);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/enrollments/all"] });
      toast({
        title: "Enrollment approved",
        description: "The enrollment request has been approved successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error approving enrollment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle reject enrollment
  const rejectMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("PUT", `/api/admin/enrollments/${id}/reject`);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/enrollments/all"] });
      toast({
        title: "Enrollment rejected",
        description: "The enrollment request has been rejected.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error rejecting enrollment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Filter enrollments based on search and tab
  const filteredEnrollments = enrollments.filter((enrollment: Enrollment) => {
    // Get user name for filtering
    const userName = users.find((u: User) => u.id === enrollment.userId)?.fullName || "";
    
    // Get test/course name for filtering
    let itemName = "";
    if (enrollment.testId) {
      itemName = tests.find((t: Test) => t.id === enrollment.testId)?.title || "";
    } else if (enrollment.courseId) {
      itemName = courses.find((c: Course) => c.id === enrollment.courseId)?.title || "";
    }
    
    // Filter by search term
    const matchesFilter = 
      userName.toLowerCase().includes(filter.toLowerCase()) || 
      itemName.toLowerCase().includes(filter.toLowerCase());
    
    // Filter by tab
    if (activeTab === "all") {
      return matchesFilter;
    } else if (activeTab === "pending") {
      return matchesFilter && enrollment.status === "pending";
    } else if (activeTab === "approved") {
      return matchesFilter && enrollment.status === "approved";
    } else if (activeTab === "rejected") {
      return matchesFilter && enrollment.status === "rejected";
    }
    
    return matchesFilter;
  });

  return (
    <AdminLayout>
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold">Manage Enrollments</h1>
        <div className="flex items-center space-x-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search enrollments..."
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="pl-8 w-[250px]"
            />
          </div>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle>Enrollment Requests</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all" className="w-full" onValueChange={setActiveTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="approved">Approved</TabsTrigger>
              <TabsTrigger value="rejected">Rejected</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all">
              <EnrollmentTable
                enrollments={filteredEnrollments}
                users={users}
                tests={tests}
                courses={courses}
                formatDate={formatDate}
                onApprove={(id) => approveMutation.mutate(id)}
                onReject={(id) => rejectMutation.mutate(id)}
                showActions={true}
              />
            </TabsContent>
            
            <TabsContent value="pending">
              <EnrollmentTable
                enrollments={filteredEnrollments}
                users={users}
                tests={tests}
                courses={courses}
                formatDate={formatDate}
                onApprove={(id) => approveMutation.mutate(id)}
                onReject={(id) => rejectMutation.mutate(id)}
                showActions={true}
              />
            </TabsContent>
            
            <TabsContent value="approved">
              <EnrollmentTable
                enrollments={filteredEnrollments}
                users={users}
                tests={tests}
                courses={courses}
                formatDate={formatDate}
                showActions={false}
              />
            </TabsContent>
            
            <TabsContent value="rejected">
              <EnrollmentTable
                enrollments={filteredEnrollments}
                users={users}
                tests={tests}
                courses={courses}
                formatDate={formatDate}
                showActions={false}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </AdminLayout>
  );
}

interface EnrollmentTableProps {
  enrollments: Enrollment[];
  users: User[];
  tests: Test[];
  courses: Course[];
  formatDate: (date?: Date | null) => string;
  onApprove?: (id: number) => void;
  onReject?: (id: number) => void;
  showActions: boolean;
}

function EnrollmentTable({
  enrollments,
  users,
  tests,
  courses,
  formatDate,
  onApprove,
  onReject,
  showActions,
}: EnrollmentTableProps) {
  // Helper function to get enrollment status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">Pending</Badge>;
      case "approved":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Approved</Badge>;
      case "rejected":
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  // Helper function to get student name
  const getStudentName = (userId: number) => {
    const user = users.find((u) => u.id === userId);
    return user ? user.fullName : "Unknown";
  };

  // Helper function to get content title (test or course)
  const getContentTitle = (enrollment: Enrollment) => {
    if (enrollment.testId) {
      const test = tests.find((t) => t.id === enrollment.testId);
      return test ? `Test: ${test.title}` : "Unknown Test";
    } else if (enrollment.courseId) {
      const course = courses.find((c) => c.id === enrollment.courseId);
      return course ? `Course: ${course.title}` : "Unknown Course";
    }
    return "Unknown Content";
  };

  // Helper function to get approver name
  const getApproverName = (approverId: number | null) => {
    if (!approverId) return "N/A";
    const approver = users.find((u) => u.id === approverId);
    return approver ? approver.fullName : "Unknown";
  };

  if (enrollments.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">No enrollments found</p>
      </div>
    );
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Student</TableHead>
            <TableHead>Content</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Requested On</TableHead>
            <TableHead>Progress</TableHead>
            <TableHead>Approved/Rejected By</TableHead>
            <TableHead>Action Date</TableHead>
            {showActions && <TableHead className="text-right">Actions</TableHead>}
          </TableRow>
        </TableHeader>
        <TableBody>
          {enrollments.map((enrollment) => (
            <TableRow key={enrollment.id}>
              <TableCell className="font-medium">{getStudentName(enrollment.userId)}</TableCell>
              <TableCell>{getContentTitle(enrollment)}</TableCell>
              <TableCell>{getStatusBadge(enrollment.status)}</TableCell>
              <TableCell>{formatDate(enrollment.enrolledAt)}</TableCell>
              <TableCell>
                {enrollment.progress !== null ? (
                  <div className="w-32 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary" 
                      style={{ width: `${enrollment.progress}%` }}>
                    </div>
                  </div>
                ) : (
                  "N/A"
                )}
              </TableCell>
              <TableCell>{getApproverName(enrollment.approvedBy)}</TableCell>
              <TableCell>
                {enrollment.status === "approved" 
                  ? formatDate(enrollment.approvedAt) 
                  : enrollment.status === "rejected" 
                    ? formatDate(enrollment.rejectedAt) 
                    : "N/A"}
              </TableCell>
              {showActions && (
                <TableCell className="text-right">
                  {enrollment.status === "pending" && (
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onApprove && onApprove(enrollment.id)}
                        title="Approve"
                      >
                        <Check className="h-4 w-4 text-green-600" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onReject && onReject(enrollment.id)}
                        title="Reject"
                      >
                        <X className="h-4 w-4 text-red-600" />
                      </Button>
                    </div>
                  )}
                </TableCell>
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}