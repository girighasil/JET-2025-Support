import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import SidebarLayout from "@/layouts/sidebar-layout";
import { useMobile } from "@/hooks/use-mobile";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { 
  ColumnDef, 
  ColumnFiltersState, 
  SortingState,
  VisibilityState,
} from "@tanstack/react-table";
import { 
  Edit, 
  Plus, 
  Trash2, 
  Eye, 
  Calendar, 
  BookOpen, 
  Clock, 
  Search
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Course, Lesson, insertCourseSchema, insertLessonSchema, InsertCourse, InsertLesson } from "@shared/schema";

const courseFormSchema = insertCourseSchema.extend({
  thumbnail: z.string().optional(),
});

type CourseFormValues = z.infer<typeof courseFormSchema>;

const lessonFormSchema = insertLessonSchema;

type LessonFormValues = z.infer<typeof lessonFormSchema>;

export default function ManageCourses() {
  const isMobile = useMobile();
  const { toast } = useToast();
  const [isAddingCourse, setIsAddingCourse] = useState(false);
  const [isAddingLesson, setIsAddingLesson] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentCourse, setCurrentCourse] = useState<Course | null>(null);
  const [currentLesson, setCurrentLesson] = useState<Lesson | null>(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [deletingType, setDeletingType] = useState<'course' | 'lesson'>('course');
  
  // Table states
  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [columnVisibility, setColumnVisibility] = useState<VisibilityState>({});
  const [searchQuery, setSearchQuery] = useState("");
  
  // Fetch courses
  const { data: courses = [], isLoading: coursesLoading } = useQuery<Course[]>({
    queryKey: ['/api/courses'],
  });
  
  // Fetch lessons for currently selected course
  const { data: lessons = [], isLoading: lessonsLoading } = useQuery<Lesson[]>({
    queryKey: ['/api/courses', currentCourse?.id, 'lessons'],
    enabled: !!currentCourse,
  });
  
  // Course form
  const courseForm = useForm<CourseFormValues>({
    resolver: zodResolver(courseFormSchema),
    defaultValues: {
      title: "",
      description: "",
      duration: 12,
      thumbnail: "",
    },
  });
  
  // Lesson form
  const lessonForm = useForm<LessonFormValues>({
    resolver: zodResolver(lessonFormSchema),
    defaultValues: {
      courseId: currentCourse?.id || 0,
      title: "",
      description: "",
      videoUrl: "",
      content: "",
      duration: 30,
      order: 1,
    },
  });
  
  // Create course mutation
  const createCourseMutation = useMutation({
    mutationFn: async (data: CourseFormValues) => {
      const res = await apiRequest("POST", "/api/admin/courses", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Course created",
        description: "The course has been created successfully.",
      });
      courseForm.reset();
      setIsAddingCourse(false);
      queryClient.invalidateQueries({ queryKey: ['/api/courses'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to create course",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update course mutation
  const updateCourseMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: CourseFormValues }) => {
      const res = await apiRequest("PUT", `/api/admin/courses/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Course updated",
        description: "The course has been updated successfully.",
      });
      courseForm.reset();
      setIsEditing(false);
      queryClient.invalidateQueries({ queryKey: ['/api/courses'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update course",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Delete course mutation
  const deleteCourseMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/courses/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Course deleted",
        description: "The course has been deleted successfully.",
      });
      setCurrentCourse(null);
      queryClient.invalidateQueries({ queryKey: ['/api/courses'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to delete course",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Create lesson mutation
  const createLessonMutation = useMutation({
    mutationFn: async (data: LessonFormValues) => {
      const res = await apiRequest("POST", "/api/admin/lessons", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Lesson created",
        description: "The lesson has been created successfully.",
      });
      lessonForm.reset();
      setIsAddingLesson(false);
      if (currentCourse) {
        queryClient.invalidateQueries({ queryKey: ['/api/courses', currentCourse.id, 'lessons'] });
      }
    },
    onError: (error) => {
      toast({
        title: "Failed to create lesson",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update lesson mutation
  const updateLessonMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: LessonFormValues }) => {
      const res = await apiRequest("PUT", `/api/admin/lessons/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Lesson updated",
        description: "The lesson has been updated successfully.",
      });
      lessonForm.reset();
      setIsEditing(false);
      if (currentCourse) {
        queryClient.invalidateQueries({ queryKey: ['/api/courses', currentCourse.id, 'lessons'] });
      }
    },
    onError: (error) => {
      toast({
        title: "Failed to update lesson",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Delete lesson mutation
  const deleteLessonMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/lessons/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Lesson deleted",
        description: "The lesson has been deleted successfully.",
      });
      if (currentCourse) {
        queryClient.invalidateQueries({ queryKey: ['/api/courses', currentCourse.id, 'lessons'] });
      }
    },
    onError: (error) => {
      toast({
        title: "Failed to delete lesson",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle course form submission
  const onSubmitCourse = (data: CourseFormValues) => {
    if (isEditing && currentCourse) {
      updateCourseMutation.mutate({ id: currentCourse.id, data });
    } else {
      createCourseMutation.mutate(data);
    }
  };
  
  // Handle lesson form submission
  const onSubmitLesson = (data: LessonFormValues) => {
    if (isEditing && currentLesson) {
      updateLessonMutation.mutate({ id: currentLesson.id, data });
    } else {
      createLessonMutation.mutate(data);
    }
  };
  
  // Setup course editing
  const editCourse = (course: Course) => {
    setCurrentCourse(course);
    courseForm.reset({
      title: course.title,
      description: course.description,
      duration: course.duration,
      thumbnail: course.thumbnail || "",
    });
    setIsEditing(true);
    setIsAddingCourse(true);
  };
  
  // Setup lesson editing
  const editLesson = (lesson: Lesson) => {
    setCurrentLesson(lesson);
    lessonForm.reset({
      courseId: lesson.courseId,
      title: lesson.title,
      description: lesson.description,
      videoUrl: lesson.videoUrl || "",
      content: lesson.content,
      duration: lesson.duration || 30,
      order: lesson.order,
    });
    setIsEditing(true);
    setIsAddingLesson(true);
  };
  
  // Setup lesson addition
  const addLesson = () => {
    if (!currentCourse) return;
    
    // Set default values for new lesson
    lessonForm.reset({
      courseId: currentCourse.id,
      title: "",
      description: "",
      videoUrl: "",
      content: "",
      duration: 30,
      order: lessons.length + 1,
    });
    
    setCurrentLesson(null);
    setIsEditing(false);
    setIsAddingLesson(true);
  };
  
  // View course details
  const viewCourseDetails = (course: Course) => {
    setCurrentCourse(course);
  };
  
  // Handle deleting an item
  const confirmDelete = (id: number, type: 'course' | 'lesson') => {
    setDeletingId(id);
    setDeletingType(type);
    setDeleteConfirmOpen(true);
  };
  
  const handleDelete = () => {
    if (!deletingId) return;
    
    if (deletingType === 'course') {
      deleteCourseMutation.mutate(deletingId);
    } else {
      deleteLessonMutation.mutate(deletingId);
    }
    
    setDeleteConfirmOpen(false);
  };
  
  // Define course columns
  const courseColumns: ColumnDef<Course>[] = [
    {
      accessorKey: "title",
      header: "Title",
      cell: ({ row }) => (
        <div className="font-medium">{row.getValue("title")}</div>
      ),
    },
    {
      accessorKey: "description",
      header: "Description",
      cell: ({ row }) => (
        <div className="max-w-[500px] truncate text-sm text-gray-500">
          {row.getValue("description")}
        </div>
      ),
    },
    {
      accessorKey: "duration",
      header: "Duration (weeks)",
      cell: ({ row }) => row.getValue("duration"),
    },
    {
      accessorKey: "createdAt",
      header: "Created",
      cell: ({ row }) => (
        <div className="text-sm text-gray-500">
          {new Date(row.original.createdAt || "").toLocaleDateString()}
        </div>
      ),
    },
    {
      id: "actions",
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => viewCourseDetails(row.original)}
          >
            <Eye className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => editCourse(row.original)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => confirmDelete(row.original.id, 'course')}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ];
  
  // Define lesson columns
  const lessonColumns: ColumnDef<Lesson>[] = [
    {
      accessorKey: "order",
      header: "#",
      cell: ({ row }) => (
        <div className="font-medium">{row.getValue("order")}</div>
      ),
    },
    {
      accessorKey: "title",
      header: "Title",
      cell: ({ row }) => (
        <div className="font-medium">{row.getValue("title")}</div>
      ),
    },
    {
      accessorKey: "description",
      header: "Description",
      cell: ({ row }) => (
        <div className="max-w-[300px] truncate text-sm text-gray-500">
          {row.getValue("description")}
        </div>
      ),
    },
    {
      accessorKey: "duration",
      header: "Duration (min)",
      cell: ({ row }) => row.getValue("duration") || "N/A",
    },
    {
      accessorKey: "videoUrl",
      header: "Video",
      cell: ({ row }) => (
        row.original.videoUrl ? (
          <div className="text-sm text-green-500">Available</div>
        ) : (
          <div className="text-sm text-gray-400">None</div>
        )
      ),
    },
    {
      id: "actions",
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => editLesson(row.original)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => confirmDelete(row.original.id, 'lesson')}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ];
  
  // Filter courses based on search query
  const filteredCourses = courses.filter(course => 
    course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    course.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <SidebarLayout>
      <div className={isMobile ? "mt-16 mb-16" : ""}>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Manage Courses</h1>
            <p className="mt-1 text-sm text-gray-500">
              Create, edit and organize courses and their lessons
            </p>
          </div>
          <div className="mt-4 md:mt-0">
            <Dialog open={isAddingCourse} onOpenChange={setIsAddingCourse}>
              <DialogTrigger asChild>
                <Button className="flex items-center gap-2">
                  <Plus className="h-4 w-4" />
                  Add New Course
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>{isEditing ? "Edit Course" : "Add New Course"}</DialogTitle>
                  <DialogDescription>
                    {isEditing 
                      ? "Update the course details using the form below." 
                      : "Create a new course by filling out the form below."}
                  </DialogDescription>
                </DialogHeader>
                
                <Form {...courseForm}>
                  <form onSubmit={courseForm.handleSubmit(onSubmitCourse)} className="space-y-4">
                    <FormField
                      control={courseForm.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Course Title</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Advanced Calculus" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={courseForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Describe the course content and objectives"
                              className="min-h-[100px]"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={courseForm.control}
                        name="duration"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Duration (weeks)</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                min={1}
                                max={52}
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={courseForm.control}
                        name="thumbnail"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Thumbnail URL (optional)</FormLabel>
                            <FormControl>
                              <Input placeholder="https://example.com/image.jpg" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <DialogFooter>
                      <Button 
                        type="submit" 
                        disabled={
                          courseForm.formState.isSubmitting || 
                          createCourseMutation.isPending ||
                          updateCourseMutation.isPending
                        }
                      >
                        {isEditing ? "Update Course" : "Create Course"}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
        
        {/* Search box */}
        <div className="mb-6 relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search courses..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        
        {/* Main content area */}
        <Tabs defaultValue="list" className="space-y-6">
          <TabsList>
            <TabsTrigger value="list">Course List</TabsTrigger>
            {currentCourse && <TabsTrigger value="details">Course Details</TabsTrigger>}
          </TabsList>
          
          {/* Course List */}
          <TabsContent value="list" className="space-y-4">
            <DataTable
              columns={courseColumns}
              data={filteredCourses}
              searchColumn="title"
            />
          </TabsContent>
          
          {/* Course Details */}
          <TabsContent value="details" className="space-y-6">
            {currentCourse && (
              <>
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{currentCourse.title}</CardTitle>
                        <CardDescription>
                          Created on {new Date(currentCourse.createdAt || "").toLocaleDateString()}
                        </CardDescription>
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => editCourse(currentCourse)}
                        >
                          <Edit className="h-4 w-4 mr-2" />
                          Edit Course
                        </Button>
                        <Button 
                          variant="destructive" 
                          size="sm" 
                          onClick={() => confirmDelete(currentCourse.id, 'course')}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="flex items-center p-4 bg-gray-50 rounded-md">
                        <BookOpen className="h-5 w-5 text-primary-600 mr-2" />
                        <div>
                          <div className="text-sm font-medium">Course Duration</div>
                          <div className="text-2xl font-bold">{currentCourse.duration} weeks</div>
                        </div>
                      </div>
                      
                      <div className="flex items-center p-4 bg-gray-50 rounded-md">
                        <Calendar className="h-5 w-5 text-primary-600 mr-2" />
                        <div>
                          <div className="text-sm font-medium">Last Updated</div>
                          <div className="text-lg font-bold">
                            {new Date(currentCourse.updatedAt || "").toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center p-4 bg-gray-50 rounded-md">
                        <Clock className="h-5 w-5 text-primary-600 mr-2" />
                        <div>
                          <div className="text-sm font-medium">Lessons</div>
                          <div className="text-2xl font-bold">{lessons.length}</div>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium mb-2">Description</h3>
                      <p className="text-gray-600">{currentCourse.description}</p>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Lessons section */}
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold">Lessons</h2>
                  <Dialog open={isAddingLesson} onOpenChange={setIsAddingLesson}>
                    <DialogTrigger asChild>
                      <Button onClick={addLesson}>
                        <Plus className="h-4 w-4 mr-2" />
                        Add Lesson
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[600px]">
                      <DialogHeader>
                        <DialogTitle>{isEditing ? "Edit Lesson" : "Add New Lesson"}</DialogTitle>
                        <DialogDescription>
                          {isEditing 
                            ? "Update the lesson details using the form below." 
                            : "Add a new lesson to this course."}
                        </DialogDescription>
                      </DialogHeader>
                      
                      <Form {...lessonForm}>
                        <form onSubmit={lessonForm.handleSubmit(onSubmitLesson)} className="space-y-4">
                          <FormField
                            control={lessonForm.control}
                            name="title"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Lesson Title</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g. Introduction to Derivatives" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={lessonForm.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                  <Textarea
                                    placeholder="Describe the lesson content"
                                    className="min-h-[80px]"
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={lessonForm.control}
                            name="content"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Lesson Content</FormLabel>
                                <FormControl>
                                  <Textarea
                                    placeholder="The main content of the lesson"
                                    className="min-h-[150px]"
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={lessonForm.control}
                              name="duration"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Duration (minutes)</FormLabel>
                                  <FormControl>
                                    <Input
                                      type="number"
                                      min={5}
                                      {...field}
                                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={lessonForm.control}
                              name="order"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Order in Course</FormLabel>
                                  <FormControl>
                                    <Input
                                      type="number"
                                      min={1}
                                      {...field}
                                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <FormField
                            control={lessonForm.control}
                            name="videoUrl"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Video URL (optional)</FormLabel>
                                <FormControl>
                                  <Input placeholder="https://example.com/video.mp4" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <input 
                            type="hidden" 
                            {...lessonForm.register("courseId")} 
                            value={currentCourse?.id} 
                          />
                          
                          <DialogFooter>
                            <Button 
                              type="submit" 
                              disabled={
                                lessonForm.formState.isSubmitting || 
                                createLessonMutation.isPending ||
                                updateLessonMutation.isPending
                              }
                            >
                              {isEditing ? "Update Lesson" : "Add Lesson"}
                            </Button>
                          </DialogFooter>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                </div>
                
                <DataTable
                  columns={lessonColumns}
                  data={lessons}
                  searchColumn="title"
                />
              </>
            )}
          </TabsContent>
        </Tabs>
        
        {/* Delete confirmation dialog */}
        <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>
                Are you sure you want to delete this {deletingType}?
              </AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This will permanently delete the {deletingType}
                {deletingType === 'course' && ' and all its associated lessons'}.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDelete}
                className="bg-red-600 hover:bg-red-700"
              >
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </SidebarLayout>
  );
}
