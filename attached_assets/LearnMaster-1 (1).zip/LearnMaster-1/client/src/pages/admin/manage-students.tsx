import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import SidebarLayout from "@/layouts/sidebar-layout";
import { useMobile } from "@/hooks/use-mobile";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { 
  ColumnDef, 
  ColumnFiltersState, 
  SortingState,
  VisibilityState,
} from "@tanstack/react-table";
import { 
  Search, 
  Mail, 
  UserPlus, 
  Eye, 
  Calendar, 
  BookOpen, 
  ClipboardCheck, 
  BarChart2
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { User, Course, Test, Enrollment, TestAttempt, insertUserSchema, InsertUser } from "@shared/schema";
import { Badge } from "@/components/ui/badge";

// User form schema with password confirmation
const userFormSchema = insertUserSchema.extend({
  confirmPassword: z.string().min(6, "Password must be at least 6 characters"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type UserFormValues = z.infer<typeof userFormSchema>;

export default function ManageStudents() {
  const isMobile = useMobile();
  const { toast } = useToast();
  const [isAddingStudent, setIsAddingStudent] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<User | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  
  // Table states
  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [columnVisibility, setColumnVisibility] = useState<VisibilityState>({});
  
  // Fetch users (students)
  const { data: users = [], isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ['/api/users'],
  });
  
  // Fetch enrollments
  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ['/api/enrollments'],
    enabled: !!currentStudent,
  });
  
  // Fetch test attempts
  const { data: testAttempts = [] } = useQuery<TestAttempt[]>({
    queryKey: ['/api/test-attempts'],
    enabled: !!currentStudent,
  });
  
  // Fetch courses
  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ['/api/courses'],
  });
  
  // Fetch tests
  const { data: tests = [] } = useQuery<Test[]>({
    queryKey: ['/api/tests'],
  });
  
  // New student form
  const form = useForm<UserFormValues>({
    resolver: zodResolver(userFormSchema),
    defaultValues: {
      name: "",
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
      role: "student",
    },
  });
  
  // Create student mutation
  const createStudentMutation = useMutation({
    mutationFn: async (data: InsertUser) => {
      const res = await apiRequest("POST", "/api/register", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Student created",
        description: "The student account has been created successfully.",
      });
      form.reset();
      setIsAddingStudent(false);
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to create student",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  const onSubmit = (data: UserFormValues) => {
    const { confirmPassword, ...userData } = data;
    createStudentMutation.mutate(userData);
  };
  
  // View student details
  const viewStudentDetails = (student: User) => {
    setCurrentStudent(student);
  };
  
  // Filter students (exclude admins unless explicitly requested)
  const students = users.filter(user => user.role === "student");
  
  // Filter students based on search query
  const filteredStudents = students.filter(student => 
    student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    student.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    student.username.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  // Get student enrollments and test attempts
  const studentEnrollments = currentStudent 
    ? enrollments.filter(e => e.userId === currentStudent.id)
    : [];
  
  const studentTests = currentStudent 
    ? testAttempts.filter(a => a.userId === currentStudent.id)
    : [];
  
  // Get metrics
  const completedCourses = studentEnrollments.filter(e => e.completedAt).length;
  const inProgressCourses = studentEnrollments.filter(e => !e.completedAt).length;
  const completedTests = studentTests.filter(a => a.status === "completed").length;
  
  // Calculate average test score
  const avgTestScore = studentTests.length > 0
    ? studentTests.reduce((sum, test) => sum + (test.percentage || 0), 0) / studentTests.length
    : 0;
  
  // Calculate total progress
  const totalProgress = studentEnrollments.length > 0
    ? studentEnrollments.reduce((sum, enrollment) => sum + (enrollment.progress || 0), 0) / studentEnrollments.length
    : 0;
  
  // Student columns
  const columns: ColumnDef<User>[] = [
    {
      accessorKey: "name",
      header: "Name",
      cell: ({ row }) => (
        <div className="flex items-center">
          <Avatar className="h-8 w-8 mr-2">
            <AvatarFallback>
              {row.original.name.split(" ").map(n => n[0]).join("").toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="font-medium">{row.getValue("name")}</div>
        </div>
      ),
    },
    {
      accessorKey: "email",
      header: "Email",
    },
    {
      accessorKey: "username",
      header: "Username",
    },
    {
      accessorKey: "createdAt",
      header: "Registered",
      cell: ({ row }) => (
        <div className="text-sm">
          {new Date(row.original.createdAt || "").toLocaleDateString()}
        </div>
      ),
    },
    {
      id: "actions",
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => viewStudentDetails(row.original)}
          >
            <Eye className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Mail className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ];
  
  return (
    <SidebarLayout>
      <div className={isMobile ? "mt-16 mb-16" : ""}>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Manage Students</h1>
            <p className="mt-1 text-sm text-gray-500">
              View and manage student accounts and track their progress
            </p>
          </div>
          <div className="mt-4 md:mt-0">
            <Dialog open={isAddingStudent} onOpenChange={setIsAddingStudent}>
              <DialogTrigger asChild>
                <Button className="flex items-center gap-2">
                  <UserPlus className="h-4 w-4" />
                  Add New Student
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>Add New Student</DialogTitle>
                  <DialogDescription>
                    Create a new student account
                  </DialogDescription>
                </DialogHeader>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John Smith" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="john@example.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <Input placeholder="johnsmith" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input type="password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="confirmPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Confirm Password</FormLabel>
                            <FormControl>
                              <Input type="password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <input type="hidden" {...form.register("role")} value="student" />
                    
                    <DialogFooter>
                      <Button
                        type="submit"
                        disabled={form.formState.isSubmitting || createStudentMutation.isPending}
                      >
                        {createStudentMutation.isPending ? "Creating..." : "Create Student"}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
        
        {/* Search box */}
        <div className="mb-6 relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search students by name, email, or username..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        
        {/* Main content */}
        <Tabs defaultValue="list" className="space-y-6">
          <TabsList>
            <TabsTrigger value="list">Student List</TabsTrigger>
            {currentStudent && <TabsTrigger value="details">Student Details</TabsTrigger>}
          </TabsList>
          
          <TabsContent value="list" className="space-y-4">
            <DataTable
              columns={columns}
              data={filteredStudents}
              searchColumn="name"
            />
          </TabsContent>
          
          <TabsContent value="details" className="space-y-6">
            {currentStudent && (
              <>
                <Card>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between">
                      <div className="flex items-center">
                        <Avatar className="h-12 w-12 mr-4">
                          <AvatarFallback className="text-lg">
                            {currentStudent.name.split(" ").map(n => n[0]).join("").toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <CardTitle>{currentStudent.name}</CardTitle>
                          <CardDescription>{currentStudent.email}</CardDescription>
                        </div>
                      </div>
                      <div>
                        <Button variant="outline" size="sm">
                          <Mail className="h-4 w-4 mr-2" />
                          Send Message
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                      <div className="bg-gray-50 p-4 rounded-md">
                        <div className="flex items-center">
                          <BookOpen className="h-5 w-5 text-primary-600 mr-2" />
                          <div>
                            <p className="text-sm text-gray-500">Enrolled Courses</p>
                            <p className="text-2xl font-bold">{studentEnrollments.length}</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-gray-50 p-4 rounded-md">
                        <div className="flex items-center">
                          <ClipboardCheck className="h-5 w-5 text-green-600 mr-2" />
                          <div>
                            <p className="text-sm text-gray-500">Tests Completed</p>
                            <p className="text-2xl font-bold">{completedTests}</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-gray-50 p-4 rounded-md">
                        <div className="flex items-center">
                          <BarChart2 className="h-5 w-5 text-amber-600 mr-2" />
                          <div>
                            <p className="text-sm text-gray-500">Avg. Test Score</p>
                            <p className="text-2xl font-bold">{avgTestScore.toFixed(0)}%</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-gray-50 p-4 rounded-md">
                        <div className="flex items-center">
                          <Calendar className="h-5 w-5 text-blue-600 mr-2" />
                          <div>
                            <p className="text-sm text-gray-500">Registered On</p>
                            <p className="text-lg font-bold">
                              {new Date(currentStudent.createdAt || "").toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-6">
                      <h3 className="text-lg font-semibold">Enrolled Courses</h3>
                      <div className="space-y-4">
                        {studentEnrollments.length > 0 ? (
                          studentEnrollments.map((enrollment) => {
                            const course = courses.find(c => c.id === enrollment.courseId);
                            return (
                              <div key={enrollment.id} className="border rounded-md p-4">
                                <div className="flex justify-between items-start">
                                  <div>
                                    <h4 className="font-medium">{course?.title || "Unknown Course"}</h4>
                                    <p className="text-sm text-gray-500">
                                      Enrolled on {new Date(enrollment.enrolledAt).toLocaleDateString()}
                                    </p>
                                  </div>
                                  <Badge>
                                    {enrollment.completedAt ? "Completed" : "In Progress"}
                                  </Badge>
                                </div>
                                <div className="mt-2">
                                  <div className="flex justify-between text-sm mb-1">
                                    <span>Progress</span>
                                    <span>{enrollment.progress || 0}%</span>
                                  </div>
                                  <div className="w-full bg-gray-200 rounded-full h-2">
                                    <div
                                      className="bg-primary-600 h-2 rounded-full" 
                                      style={{ width: `${enrollment.progress || 0}%` }}
                                    />
                                  </div>
                                </div>
                              </div>
                            );
                          })
                        ) : (
                          <p className="text-gray-500 text-center py-4">
                            This student is not enrolled in any courses.
                          </p>
                        )}
                      </div>
                    </div>
                    
                    <div className="space-y-6 mt-8">
                      <h3 className="text-lg font-semibold">Recent Test Attempts</h3>
                      <div className="space-y-4">
                        {studentTests.length > 0 ? (
                          studentTests
                            .slice(0, 5) // Show only the 5 most recent
                            .map((attempt) => {
                              const test = tests.find(t => t.id === attempt.testId);
                              return (
                                <div key={attempt.id} className="border rounded-md p-4">
                                  <div className="flex justify-between items-start">
                                    <div>
                                      <h4 className="font-medium">{test?.title || "Unknown Test"}</h4>
                                      <p className="text-sm text-gray-500">
                                        {attempt.status === "completed"
                                          ? `Completed on ${new Date(attempt.completedAt || "").toLocaleDateString()}`
                                          : attempt.status === "pending"
                                          ? `Started on ${new Date(attempt.startedAt).toLocaleDateString()}`
                                          : "Not started"}
                                      </p>
                                    </div>
                                    <Badge
                                      className={`${
                                        attempt.status === "completed"
                                          ? (attempt.percentage || 0) >= (test?.passingScore || 0)
                                            ? "bg-green-100 text-green-800"
                                            : "bg-red-100 text-red-800"
                                          : attempt.status === "pending"
                                          ? "bg-yellow-100 text-yellow-800"
                                          : "bg-gray-100 text-gray-800"
                                      }`}
                                    >
                                      {attempt.status === "completed"
                                        ? `${attempt.percentage?.toFixed(0)}%`
                                        : attempt.status.charAt(0).toUpperCase() + attempt.status.slice(1)}
                                    </Badge>
                                  </div>
                                  {attempt.status === "completed" && (
                                    <div className="mt-2">
                                      <div className="flex justify-between text-sm mb-1">
                                        <span>Score</span>
                                        <span>{attempt.score} / {attempt.maxScore} points</span>
                                      </div>
                                      <div className="w-full bg-gray-200 rounded-full h-2">
                                        <div
                                          className={`h-2 rounded-full ${
                                            (attempt.percentage || 0) >= (test?.passingScore || 0)
                                              ? "bg-green-600"
                                              : "bg-red-600"
                                          }`}
                                          style={{ width: `${attempt.percentage || 0}%` }}
                                        />
                                      </div>
                                    </div>
                                  )}
                                </div>
                              );
                            })
                        ) : (
                          <p className="text-gray-500 text-center py-4">
                            This student has not taken any tests yet.
                          </p>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </SidebarLayout>
  );
}
