import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import SidebarLayout from "@/layouts/sidebar-layout";
import { useMobile } from "@/hooks/use-mobile";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { 
  ColumnDef, 
  ColumnFiltersState, 
  SortingState,
  VisibilityState,
} from "@tanstack/react-table";
import { 
  Edit, 
  Plus, 
  Trash2, 
  Eye, 
  Calendar, 
  ClipboardList, 
  Clock, 
  Search,
  Check,
  X,
  BookOpen
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Course, Test, Question, insertTestSchema, insertQuestionSchema, InsertTest, InsertQuestion } from "@shared/schema";

// Test form schema
const testFormSchema = insertTestSchema;
type TestFormValues = z.infer<typeof testFormSchema>;

// Question form schema with added validation
const questionFormSchema = insertQuestionSchema.extend({
  options: z.array(z.string()).min(2, "At least 2 options are required"),
});
type QuestionFormValues = z.infer<typeof questionFormSchema>;

export default function ManageTests() {
  const isMobile = useMobile();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [isAddingTest, setIsAddingTest] = useState(false);
  const [isAddingQuestion, setIsAddingQuestion] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentTest, setCurrentTest] = useState<Test | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [deletingType, setDeletingType] = useState<'test' | 'question'>('test');
  
  // Table states
  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [columnVisibility, setColumnVisibility] = useState<VisibilityState>({});
  const [searchQuery, setSearchQuery] = useState("");
  
  // Fetch courses
  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ['/api/courses'],
  });
  
  // Fetch tests
  const { data: tests = [], isLoading: testsLoading } = useQuery<Test[]>({
    queryKey: ['/api/tests'],
  });
  
  // Fetch questions for currently selected test
  const { data: questions = [], isLoading: questionsLoading } = useQuery<Question[]>({
    queryKey: ['/api/tests', currentTest?.id, 'questions'],
    enabled: !!currentTest,
  });
  
  // Test form
  const testForm = useForm<TestFormValues>({
    resolver: zodResolver(testFormSchema),
    defaultValues: {
      title: "",
      description: "",
      duration: 60,
      passingScore: 60,
      totalQuestions: 0,
      courseId: undefined,
    },
  });
  
  // Question form with dynamic options
  const questionForm = useForm<QuestionFormValues>({
    resolver: zodResolver(questionFormSchema),
    defaultValues: {
      testId: currentTest?.id || 0,
      question: "",
      options: ["", ""],
      correctOption: 0,
      explanation: "",
      marks: 1,
      order: 1,
    },
  });
  
  // Watch options to display the correct option selector
  const watchOptions = questionForm.watch("options");
  
  // Create test mutation
  const createTestMutation = useMutation({
    mutationFn: async (data: TestFormValues) => {
      const res = await apiRequest("POST", "/api/admin/tests", data);
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Test created",
        description: "The test has been created successfully.",
      });
      testForm.reset();
      setIsAddingTest(false);
      setCurrentTest(data);
      queryClient.invalidateQueries({ queryKey: ['/api/tests'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to create test",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update test mutation
  const updateTestMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: TestFormValues }) => {
      const res = await apiRequest("PUT", `/api/admin/tests/${id}`, data);
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Test updated",
        description: "The test has been updated successfully.",
      });
      testForm.reset();
      setIsEditing(false);
      setIsAddingTest(false);
      setCurrentTest(data);
      queryClient.invalidateQueries({ queryKey: ['/api/tests'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update test",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Delete test mutation
  const deleteTestMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/tests/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Test deleted",
        description: "The test has been deleted successfully.",
      });
      setCurrentTest(null);
      queryClient.invalidateQueries({ queryKey: ['/api/tests'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to delete test",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Create question mutation
  const createQuestionMutation = useMutation({
    mutationFn: async (data: QuestionFormValues) => {
      const res = await apiRequest("POST", "/api/admin/questions", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Question created",
        description: "The question has been created successfully.",
      });
      questionForm.reset({
        testId: currentTest?.id || 0,
        question: "",
        options: ["", ""],
        correctOption: 0,
        explanation: "",
        marks: 1,
        order: questions.length + 1,
      });
      setIsAddingQuestion(false);
      if (currentTest) {
        // Update test's totalQuestions
        updateTestMutation.mutate({
          id: currentTest.id,
          data: {
            ...currentTest,
            totalQuestions: currentTest.totalQuestions + 1
          }
        });
        queryClient.invalidateQueries({ queryKey: ['/api/tests', currentTest.id, 'questions'] });
      }
    },
    onError: (error) => {
      toast({
        title: "Failed to create question",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update question mutation
  const updateQuestionMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: QuestionFormValues }) => {
      const res = await apiRequest("PUT", `/api/admin/questions/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Question updated",
        description: "The question has been updated successfully.",
      });
      questionForm.reset();
      setIsEditing(false);
      setIsAddingQuestion(false);
      if (currentTest) {
        queryClient.invalidateQueries({ queryKey: ['/api/tests', currentTest.id, 'questions'] });
      }
    },
    onError: (error) => {
      toast({
        title: "Failed to update question",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Delete question mutation
  const deleteQuestionMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/questions/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Question deleted",
        description: "The question has been deleted successfully.",
      });
      if (currentTest) {
        // Update test's totalQuestions
        updateTestMutation.mutate({
          id: currentTest.id,
          data: {
            ...currentTest,
            totalQuestions: currentTest.totalQuestions - 1
          }
        });
        queryClient.invalidateQueries({ queryKey: ['/api/tests', currentTest.id, 'questions'] });
      }
    },
    onError: (error) => {
      toast({
        title: "Failed to delete question",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle test form submission
  const onSubmitTest = (data: TestFormValues) => {
    if (isEditing && currentTest) {
      updateTestMutation.mutate({ id: currentTest.id, data });
    } else {
      createTestMutation.mutate(data);
    }
  };
  
  // Handle question form submission
  const onSubmitQuestion = (data: QuestionFormValues) => {
    if (isEditing && currentQuestion) {
      updateQuestionMutation.mutate({ id: currentQuestion.id, data });
    } else {
      createQuestionMutation.mutate(data);
    }
  };
  
  // Add option to question form
  const addOption = () => {
    const currentOptions = questionForm.getValues("options");
    questionForm.setValue("options", [...currentOptions, ""]);
  };
  
  // Remove option from question form
  const removeOption = (index: number) => {
    const currentOptions = questionForm.getValues("options");
    if (currentOptions.length <= 2) return; // Maintain at least 2 options
    
    // If removing the correct option, reset it to 0
    if (index === questionForm.getValues("correctOption")) {
      questionForm.setValue("correctOption", 0);
    }
    // If removing an option before the correct option, adjust the correct option index
    else if (index < questionForm.getValues("correctOption")) {
      questionForm.setValue("correctOption", questionForm.getValues("correctOption") - 1);
    }
    
    questionForm.setValue("options", currentOptions.filter((_, i) => i !== index));
  };
  
  // Setup test editing
  const editTest = (test: Test) => {
    setCurrentTest(test);
    testForm.reset({
      title: test.title,
      description: test.description,
      duration: test.duration,
      passingScore: test.passingScore,
      totalQuestions: test.totalQuestions,
      courseId: test.courseId,
    });
    setIsEditing(true);
    setIsAddingTest(true);
  };
  
  // Setup question editing
  const editQuestion = (question: Question) => {
    setCurrentQuestion(question);
    questionForm.reset({
      testId: question.testId,
      question: question.question,
      options: question.options as string[],
      correctOption: question.correctOption,
      explanation: question.explanation || "",
      marks: question.marks,
      order: question.order,
    });
    setIsEditing(true);
    setIsAddingQuestion(true);
  };
  
  // Setup question addition
  const addQuestion = () => {
    if (!currentTest) return;
    
    // Reset form with defaults
    questionForm.reset({
      testId: currentTest.id,
      question: "",
      options: ["", ""],
      correctOption: 0,
      explanation: "",
      marks: 1,
      order: questions.length + 1,
    });
    
    setCurrentQuestion(null);
    setIsEditing(false);
    setIsAddingQuestion(true);
  };
  
  // View test details
  const viewTestDetails = (test: Test) => {
    setCurrentTest(test);
  };
  
  // Handle deleting an item
  const confirmDelete = (id: number, type: 'test' | 'question') => {
    setDeletingId(id);
    setDeletingType(type);
    setDeleteConfirmOpen(true);
  };
  
  const handleDelete = () => {
    if (!deletingId) return;
    
    if (deletingType === 'test') {
      deleteTestMutation.mutate(deletingId);
    } else {
      deleteQuestionMutation.mutate(deletingId);
    }
    
    setDeleteConfirmOpen(false);
  };
  
  // Define test columns
  const testColumns: ColumnDef<Test>[] = [
    {
      accessorKey: "title",
      header: "Title",
      cell: ({ row }) => (
        <div className="font-medium">{row.getValue("title")}</div>
      ),
    },
    {
      accessorKey: "courseId",
      header: "Course",
      cell: ({ row }) => {
        const courseId = row.getValue("courseId");
        const course = courses.find(c => c.id === courseId);
        return course ? course.title : "No Course";
      },
    },
    {
      accessorKey: "duration",
      header: "Duration (min)",
      cell: ({ row }) => row.getValue("duration"),
    },
    {
      accessorKey: "totalQuestions",
      header: "Questions",
      cell: ({ row }) => row.getValue("totalQuestions"),
    },
    {
      accessorKey: "passingScore",
      header: "Passing Score",
      cell: ({ row }) => `${row.getValue("passingScore")}%`,
    },
    {
      id: "actions",
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => viewTestDetails(row.original)}
          >
            <Eye className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => editTest(row.original)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => confirmDelete(row.original.id, 'test')}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ];
  
  // Define question columns
  const questionColumns: ColumnDef<Question>[] = [
    {
      accessorKey: "order",
      header: "#",
      cell: ({ row }) => (
        <div className="font-medium">{row.getValue("order")}</div>
      ),
    },
    {
      accessorKey: "question",
      header: "Question",
      cell: ({ row }) => (
        <div className="max-w-[400px] truncate">{row.getValue("question")}</div>
      ),
    },
    {
      accessorKey: "marks",
      header: "Marks",
      cell: ({ row }) => row.getValue("marks"),
    },
    {
      accessorKey: "options",
      header: "Options",
      cell: ({ row }) => (row.original.options as string[]).length || 0,
    },
    {
      id: "actions",
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => editQuestion(row.original)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => confirmDelete(row.original.id, 'question')}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ];
  
  // Filter tests based on search query
  const filteredTests = tests.filter(test => 
    test.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    test.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <SidebarLayout>
      <div className={isMobile ? "mt-16 mb-16" : ""}>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Manage Tests</h1>
            <p className="mt-1 text-sm text-gray-500">
              Create and organize tests and questions for assessment
            </p>
          </div>
          <div className="mt-4 md:mt-0 flex gap-2">
            <Button 
              className="flex items-center gap-2"
              onClick={() => navigate("/admin/test-creator")}
            >
              <Plus className="h-4 w-4" />
              Create Test
            </Button>
          </div>
        </div>
        
        {/* Search box */}
        <div className="mb-6 relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search tests..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        
        {/* Main content area */}
        <Tabs defaultValue="list" className="space-y-6">
          <TabsList>
            <TabsTrigger value="list">Test List</TabsTrigger>
            {currentTest && <TabsTrigger value="details">Test Details</TabsTrigger>}
          </TabsList>
          
          {/* Test List */}
          <TabsContent value="list" className="space-y-4">
            <DataTable
              columns={testColumns}
              data={filteredTests}
              searchColumn="title"
            />
          </TabsContent>
          
          {/* Test Details */}
          <TabsContent value="details" className="space-y-6">
            {currentTest && (
              <>
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{currentTest.title}</CardTitle>
                        <CardDescription>
                          Created on {new Date(currentTest.createdAt || "").toLocaleDateString()}
                        </CardDescription>
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => editTest(currentTest)}
                        >
                          <Edit className="h-4 w-4 mr-2" />
                          Edit Test
                        </Button>
                        <Button 
                          variant="destructive" 
                          size="sm" 
                          onClick={() => confirmDelete(currentTest.id, 'test')}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-4 gap-4">
                      <div className="flex items-center p-4 bg-gray-50 rounded-md">
                        <Clock className="h-5 w-5 text-primary-600 mr-2" />
                        <div>
                          <div className="text-sm font-medium">Duration</div>
                          <div className="text-2xl font-bold">{currentTest.duration} min</div>
                        </div>
                      </div>
                      
                      <div className="flex items-center p-4 bg-gray-50 rounded-md">
                        <ClipboardList className="h-5 w-5 text-primary-600 mr-2" />
                        <div>
                          <div className="text-sm font-medium">Questions</div>
                          <div className="text-2xl font-bold">{currentTest.totalQuestions}</div>
                        </div>
                      </div>
                      
                      <div className="flex items-center p-4 bg-gray-50 rounded-md">
                        <Check className="h-5 w-5 text-green-600 mr-2" />
                        <div>
                          <div className="text-sm font-medium">Passing Score</div>
                          <div className="text-2xl font-bold">{currentTest.passingScore}%</div>
                        </div>
                      </div>
                      
                      <div className="flex items-center p-4 bg-gray-50 rounded-md">
                        <BookOpen className="h-5 w-5 text-primary-600 mr-2" />
                        <div>
                          <div className="text-sm font-medium">Course</div>
                          <div className="text-lg font-bold truncate">
                            {currentTest.courseId 
                              ? courses.find(c => c.id === currentTest.courseId)?.title || "Unknown Course"
                              : "No Course"
                            }
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium mb-2">Description</h3>
                      <p className="text-gray-600">{currentTest.description}</p>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Questions section */}
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold">Questions</h2>
                  <Dialog open={isAddingQuestion} onOpenChange={setIsAddingQuestion}>
                    <DialogTrigger asChild>
                      <Button onClick={addQuestion}>
                        <Plus className="h-4 w-4 mr-2" />
                        Add Question
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[700px]">
                      <DialogHeader>
                        <DialogTitle>{isEditing ? "Edit Question" : "Add New Question"}</DialogTitle>
                        <DialogDescription>
                          {isEditing 
                            ? "Update the question details using the form below." 
                            : "Add a new question to this test."}
                        </DialogDescription>
                      </DialogHeader>
                      
                      <Form {...questionForm}>
                        <form onSubmit={questionForm.handleSubmit(onSubmitQuestion)} className="space-y-4">
                          <FormField
                            control={questionForm.control}
                            name="question"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Question Text</FormLabel>
                                <FormControl>
                                  <Textarea
                                    placeholder="Enter your question here. You can use HTML and LaTeX for formatting."
                                    className="min-h-[100px]"
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="space-y-3">
                            <div className="flex justify-between items-center">
                              <FormLabel>Answer Options</FormLabel>
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={addOption}
                              >
                                <Plus className="h-3 w-3 mr-1" />
                                Add Option
                              </Button>
                            </div>
                            
                            {watchOptions.map((_, index) => (
                              <div key={index} className="flex gap-2 items-start">
                                <FormField
                                  control={questionForm.control}
                                  name={`options.${index}`}
                                  render={({ field }) => (
                                    <FormItem className="flex-1">
                                      <div className="flex items-center gap-2">
                                        <FormControl>
                                          <Input
                                            placeholder={`Option ${index + 1}`}
                                            {...field}
                                          />
                                        </FormControl>
                                        {index > 1 && (
                                          <Button
                                            type="button"
                                            variant="ghost"
                                            size="sm"
                                            onClick={() => removeOption(index)}
                                          >
                                            <X className="h-4 w-4" />
                                          </Button>
                                        )}
                                      </div>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                
                                <FormField
                                  control={questionForm.control}
                                  name="correctOption"
                                  render={({ field }) => (
                                    <FormItem>
                                      <div className="flex items-center h-10">
                                        <input
                                          type="radio"
                                          id={`correctOption-${index}`}
                                          className="h-4 w-4 border-gray-300 text-primary-600 focus:ring-primary-500"
                                          checked={field.value === index}
                                          onChange={() => field.onChange(index)}
                                        />
                                        <label
                                          htmlFor={`correctOption-${index}`}
                                          className="ml-2 text-sm text-gray-600"
                                        >
                                          Correct
                                        </label>
                                      </div>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                              </div>
                            ))}
                          </div>
                          
                          <FormField
                            control={questionForm.control}
                            name="explanation"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Explanation (Optional)</FormLabel>
                                <FormControl>
                                  <Textarea
                                    placeholder="Explain why the correct answer is right"
                                    className="min-h-[80px]"
                                    value={field.value || ""}
                                    onChange={field.onChange}
                                    onBlur={field.onBlur}
                                    name={field.name}
                                    ref={field.ref}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={questionForm.control}
                              name="marks"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Marks</FormLabel>
                                  <FormControl>
                                    <Input
                                      type="number"
                                      min={1}
                                      {...field}
                                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={questionForm.control}
                              name="order"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Question Order</FormLabel>
                                  <FormControl>
                                    <Input
                                      type="number"
                                      min={1}
                                      {...field}
                                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <input 
                            type="hidden" 
                            {...questionForm.register("testId")} 
                            value={currentTest?.id} 
                          />
                          
                          <DialogFooter>
                            <Button 
                              type="submit" 
                              disabled={
                                questionForm.formState.isSubmitting || 
                                createQuestionMutation.isPending ||
                                updateQuestionMutation.isPending
                              }
                            >
                              {isEditing ? "Update Question" : "Add Question"}
                            </Button>
                          </DialogFooter>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                </div>
                
                <DataTable
                  columns={questionColumns}
                  data={questions}
                  searchColumn="question"
                />
              </>
            )}
          </TabsContent>
        </Tabs>
        
        {/* Delete confirmation dialog */}
        <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>
                Are you sure you want to delete this {deletingType}?
              </AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This will permanently delete the {deletingType}
                {deletingType === 'test' && ' and all its associated questions'}.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDelete}
                className="bg-red-600 hover:bg-red-700"
              >
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </SidebarLayout>
  );
}
