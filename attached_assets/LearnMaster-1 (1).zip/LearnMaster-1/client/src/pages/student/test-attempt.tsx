import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import SidebarLayout from "@/layouts/sidebar-layout";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMobile } from "@/hooks/use-mobile";
import { useToast } from "@/hooks/use-toast";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { 
  CheckCircle, 
  AlertCircle, 
  Clock, 
  ArrowLeft, 
  ArrowRight,
  Check,
  X,
  AlertTriangle
} from "lucide-react";
import { Test, Question, TestAttempt as TestAttemptType } from "@shared/schema";

// MathJax needs to be available globally for math rendering
declare global {
  interface Window {
    MathJax: any;
  }
}

export default function StudentTestAttempt() {
  const [, navigate] = useLocation();
  const [, params] = useRoute<{ id: string }>("/student/test/:id");
  const attemptId = parseInt(params?.id || "0");
  const isMobile = useMobile();
  const { toast } = useToast();
  
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConfirmSubmit, setShowConfirmSubmit] = useState(false);
  
  // Fetch test attempt
  const { data: testAttempt, isLoading: attemptLoading } = useQuery<TestAttemptType>({
    queryKey: [`/api/test-attempts/${attemptId}`],
    enabled: !!attemptId,
    onSuccess: (data) => {
      // Initialize answers from existing attempt
      if (data.answers) {
        setSelectedAnswers(data.answers);
      }
      
      // Set timer if test is pending
      if (data.status === 'pending') {
        const test = tests.find(t => t.id === data.testId);
        if (test) {
          // Calculate time left based on start time
          const startTime = new Date(data.startedAt).getTime();
          const currentTime = new Date().getTime();
          const elapsedSeconds = Math.floor((currentTime - startTime) / 1000);
          const durationSeconds = test.duration * 60;
          const remainingSeconds = Math.max(0, durationSeconds - elapsedSeconds);
          setTimeLeft(remainingSeconds);
        }
      }
    }
  });
  
  // Fetch all tests (to get test details)
  const { data: tests = [], isLoading: testsLoading } = useQuery<Test[]>({
    queryKey: ['/api/tests'],
  });
  
  // Get the test for this attempt
  const test = tests.find(t => t.id === testAttempt?.testId);
  
  // Fetch questions for this test
  const { data: questions = [], isLoading: questionsLoading } = useQuery<Question[]>({
    queryKey: [`/api/tests/${testAttempt?.testId}/questions`],
    enabled: !!testAttempt?.testId,
  });
  
  // Get current question
  const currentQuestion = questions[currentQuestionIndex];
  
  // Submit test mutation
  const submitTestMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest(
        "PUT", 
        `/api/test-attempts/${attemptId}/submit`, 
        { answers: selectedAnswers }
      );
      return await res.json();
    },
    onSuccess: () => {
      setIsSubmitting(false);
      queryClient.invalidateQueries({ queryKey: [`/api/test-attempts/${attemptId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/test-attempts'] });
      toast({
        title: "Test submitted successfully",
        description: "Your test has been graded and the results are ready.",
      });
    },
    onError: (error) => {
      setIsSubmitting(false);
      toast({
        title: "Failed to submit test",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Timer effect
  useEffect(() => {
    if (timeLeft === null || timeLeft <= 0 || testAttempt?.status !== 'pending') return;
    
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev === null || prev <= 1) {
          clearInterval(timer);
          // Auto-submit when time expires
          handleSubmitTest();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, [timeLeft, testAttempt?.status]);
  
  // MathJax rendering effect
  useEffect(() => {
    if (window.MathJax && currentQuestion) {
      setTimeout(() => {
        window.MathJax.typeset();
      }, 100);
    }
  }, [currentQuestion, currentQuestionIndex]);
  
  if (!attemptId || (!attemptLoading && !testAttempt)) {
    return (
      <SidebarLayout>
        <div className="text-center my-12">
          <AlertCircle className="h-12 w-12 mx-auto text-red-500" />
          <h2 className="mt-4 text-2xl font-bold">Test Not Found</h2>
          <p className="mt-2 text-gray-600">The test you're looking for doesn't exist or you don't have access to it.</p>
          <Button className="mt-6" onClick={() => navigate('/student/tests')}>
            Back to Tests
          </Button>
        </div>
      </SidebarLayout>
    );
  }
  
  if (attemptLoading || testsLoading || questionsLoading || !test) {
    return (
      <SidebarLayout>
        <div className="text-center my-12">
          <div className="animate-spin h-12 w-12 border-4 border-primary-600 border-t-transparent rounded-full mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading test...</p>
        </div>
      </SidebarLayout>
    );
  }
  
  // Format time
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };
  
  // Handle answer selection
  const handleAnswerSelect = (questionId: number, optionIndex: number) => {
    if (testAttempt.status !== 'pending') return;
    
    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: optionIndex
    }));
  };
  
  // Navigate to next/previous question
  const goToNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };
  
  const goToPrevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };
  
  // Handle test submission
  const handleSubmitTest = () => {
    setIsSubmitting(true);
    submitTestMutation.mutate();
  };
  
  // Calculate progress
  const answeredQuestions = Object.keys(selectedAnswers).length;
  const progressPercentage = (answeredQuestions / questions.length) * 100;
  
  // Check if test is completed
  const isCompleted = testAttempt.status === 'completed';
  
  // Get score info for completed test
  const scorePercentage = testAttempt.percentage || 0;
  const isPassed = scorePercentage >= (test.passingScore || 0);
  
  return (
    <SidebarLayout>
      <div className={isMobile ? "mt-16 mb-16" : ""}>
        {/* Test Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{test.title}</h1>
            <p className="text-gray-600">{test.description}</p>
          </div>
          
          {!isCompleted && (
            <div className="mt-4 md:mt-0 flex items-center">
              <div className="flex items-center bg-amber-100 text-amber-800 rounded-md px-3 py-1.5">
                <Clock className="h-5 w-5 mr-2" />
                <span className="font-medium">
                  {timeLeft !== null ? formatTime(timeLeft) : `${test.duration} minutes`}
                </span>
              </div>
            </div>
          )}
        </div>
        
        {/* Test Results (if completed) */}
        {isCompleted ? (
          <div className="mb-6">
            <Card>
              <CardHeader className={isPassed ? "bg-green-50" : "bg-red-50"}>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-xl">Test Results</CardTitle>
                  <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full ${isPassed ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}>
                    {isPassed ? (
                      <CheckCircle className="h-5 w-5" />
                    ) : (
                      <AlertCircle className="h-5 w-5" />
                    )}
                    <span className="font-bold">
                      {isPassed ? "PASSED" : "FAILED"}
                    </span>
                  </div>
                </div>
                <CardDescription>
                  Completed on {new Date(testAttempt.completedAt || "").toLocaleDateString()}
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-gray-50 p-4 rounded-md">
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Score</h3>
                    <p className="text-3xl font-bold">
                      {scorePercentage.toFixed(0)}%
                    </p>
                    <p className="text-sm text-gray-600 mt-1">
                      {testAttempt.score} / {testAttempt.maxScore} points
                    </p>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-md">
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Passing Score</h3>
                    <p className="text-3xl font-bold">{test.passingScore}%</p>
                    <p className="text-sm text-gray-600 mt-1">
                      Required to pass
                    </p>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-md">
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Questions</h3>
                    <p className="text-3xl font-bold">{questions.length}</p>
                    <p className="text-sm text-gray-600 mt-1">
                      Total questions
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : null}
        
        {/* Test Interface */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Questions Panel */}
          <div className="md:col-span-2">
            {currentQuestion ? (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Question {currentQuestionIndex + 1} of {questions.length}</span>
                    {isCompleted && (
                      <div className="flex items-center gap-1">
                        <Badge 
                          variant={selectedAnswers[currentQuestion.id] === currentQuestion.correctOption ? "default" : "destructive"}
                        >
                          {selectedAnswers[currentQuestion.id] === currentQuestion.correctOption ? (
                            <>
                              <Check className="h-3.5 w-3.5 mr-1" />
                              Correct
                            </>
                          ) : (
                            <>
                              <X className="h-3.5 w-3.5 mr-1" />
                              Incorrect
                            </>
                          )}
                        </Badge>
                      </div>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div 
                    className="prose max-w-none mb-6"
                    dangerouslySetInnerHTML={{ __html: currentQuestion.question }}
                  />
                  
                  <RadioGroup
                    value={selectedAnswers[currentQuestion.id]?.toString()}
                    onValueChange={(value) => handleAnswerSelect(currentQuestion.id, parseInt(value))}
                    disabled={isCompleted}
                    className="space-y-4"
                  >
                    {(currentQuestion.options as string[]).map((option, index) => (
                      <div 
                        key={index} 
                        className={`flex items-start space-x-3 p-3 rounded-md ${
                          isCompleted ? (
                            index === currentQuestion.correctOption 
                              ? "bg-green-50 border border-green-200" 
                              : selectedAnswers[currentQuestion.id] === index 
                                ? "bg-red-50 border border-red-200" 
                                : ""
                          ) : ""
                        }`}
                      >
                        <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                        <div className="flex-1">
                          <Label
                            htmlFor={`option-${index}`}
                            className="text-base font-normal cursor-pointer"
                          >
                            <div dangerouslySetInnerHTML={{ __html: option }} />
                          </Label>
                        </div>
                        {isCompleted && (
                          <div className="ml-2">
                            {index === currentQuestion.correctOption ? (
                              <Check className="h-5 w-5 text-green-600" />
                            ) : selectedAnswers[currentQuestion.id] === index ? (
                              <X className="h-5 w-5 text-red-600" />
                            ) : null}
                          </div>
                        )}
                      </div>
                    ))}
                  </RadioGroup>
                  
                  {isCompleted && currentQuestion.explanation && (
                    <div className="mt-6 bg-blue-50 p-4 rounded-md">
                      <h4 className="font-medium text-blue-800 mb-1">Explanation</h4>
                      <div 
                        className="text-blue-700 text-sm"
                        dangerouslySetInnerHTML={{ __html: currentQuestion.explanation }}
                      />
                    </div>
                  )}
                </CardContent>
                <CardFooter className="flex justify-between p-4 border-t">
                  <Button 
                    variant="outline" 
                    onClick={goToPrevQuestion}
                    disabled={currentQuestionIndex === 0}
                  >
                    <ArrowLeft className="mr-2 h-4 w-4" /> Previous
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={goToNextQuestion}
                    disabled={currentQuestionIndex === questions.length - 1}
                  >
                    Next <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            ) : (
              <div className="text-center p-12 bg-gray-50 rounded-md">
                <p>No questions available for this test.</p>
              </div>
            )}
          </div>
          
          {/* Questions List & Submit Panel */}
          <div>
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Progress</CardTitle>
                <CardDescription>
                  {answeredQuestions} of {questions.length} questions answered
                </CardDescription>
                <Progress value={progressPercentage} className="mt-2" />
              </CardHeader>
              <CardContent className="p-4">
                <div className="grid grid-cols-5 gap-2">
                  {questions.map((q, index) => (
                    <Button
                      key={q.id}
                      variant="outline"
                      size="sm"
                      className={`h-10 w-10 p-0 ${
                        currentQuestionIndex === index ? "border-primary-600 border-2" : ""
                      } ${
                        selectedAnswers[q.id] !== undefined 
                          ? isCompleted 
                            ? selectedAnswers[q.id] === q.correctOption
                              ? "bg-green-100 hover:bg-green-200"
                              : "bg-red-100 hover:bg-red-200"
                            : "bg-blue-100 hover:bg-blue-200" 
                          : ""
                      }`}
                      onClick={() => setCurrentQuestionIndex(index)}
                    >
                      {index + 1}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {!isCompleted && (
              <Card>
                <CardHeader>
                  <CardTitle>Ready to Submit?</CardTitle>
                  <CardDescription>
                    Make sure you've answered all questions before submitting.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <AlertDialog open={showConfirmSubmit} onOpenChange={setShowConfirmSubmit}>
                    <AlertDialogTrigger asChild>
                      <Button 
                        className="w-full"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          <>
                            <div className="animate-spin mr-2 h-4 w-4 border-2 border-b-transparent rounded-full" />
                            Submitting...
                          </>
                        ) : (
                          "Submit Test"
                        )}
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Are you sure you want to submit?</AlertDialogTitle>
                        <AlertDialogDescription>
                          {answeredQuestions < questions.length ? (
                            <div className="flex items-start">
                              <AlertTriangle className="h-5 w-5 text-amber-500 mr-2 mt-0.5" />
                              <span>
                                You've only answered {answeredQuestions} out of {questions.length} questions.
                                Unanswered questions will be marked as incorrect.
                              </span>
                            </div>
                          ) : (
                            "You've answered all the questions. Once submitted, you can't change your answers."
                          )}
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleSubmitTest}>
                          Submit
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </CardContent>
              </Card>
            )}
            
            {isCompleted && (
              <Card>
                <CardHeader>
                  <CardTitle>Test Complete</CardTitle>
                  <CardDescription>
                    Review your answers and learn from explanations.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    className="w-full"
                    onClick={() => navigate('/student/tests')}
                  >
                    Back to Tests
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </SidebarLayout>
  );
}
