import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import SidebarLayout from "@/layouts/sidebar-layout";
import { useMobile } from "@/hooks/use-mobile";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Calendar, Clock, AlertCircle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { 
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format } from "date-fns";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Session, InsertSession } from "@shared/schema";

const sessionSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  sessionDate: z.date({
    required_error: "Please select a date and time",
  }),
  duration: z.number().min(15, "Session must be at least 15 minutes").max(120, "Session cannot exceed 2 hours"),
});

type SessionFormValues = z.infer<typeof sessionSchema>;

export default function StudentDoubts() {
  const isMobile = useMobile();
  const { user } = useAuth();
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  // Fetch sessions
  const { data: sessions = [], isLoading } = useQuery<Session[]>({
    queryKey: ["/api/sessions"],
  });

  // Create a new session
  const createSessionMutation = useMutation({
    mutationFn: async (data: InsertSession) => {
      const res = await apiRequest("POST", "/api/sessions", data);
      return await res.json();
    },
    onSuccess: () => {
      setIsDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      toast({
        title: "Session scheduled",
        description: "Your doubt resolution session has been scheduled successfully.",
      });
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Failed to schedule session",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Session form
  const form = useForm<SessionFormValues>({
    resolver: zodResolver(sessionSchema),
    defaultValues: {
      title: "",
      description: "",
      duration: 30,
    },
  });

  // Form submission handler
  const onSubmit = (data: SessionFormValues) => {
    createSessionMutation.mutate({
      ...data,
      userId: user?.id as number,
      instructorId: 1, // Default to admin instructor for now
      status: "scheduled",
      meetingUrl: "", // Will be populated by the instructor later
    });
  };

  // Sort sessions by date (upcoming first, then past)
  const sortedSessions = [...sessions].sort((a, b) => {
    const dateA = new Date(a.sessionDate);
    const dateB = new Date(b.sessionDate);
    const now = new Date();
    
    // Check if sessions are upcoming or past
    const aIsUpcoming = dateA > now;
    const bIsUpcoming = dateB > now;
    
    // If one is upcoming and one is past, prioritize upcoming
    if (aIsUpcoming && !bIsUpcoming) return -1;
    if (!aIsUpcoming && bIsUpcoming) return 1;
    
    // If both are upcoming or both are past, sort by date
    return dateA.getTime() - dateB.getTime();
  });

  // Format date and time
  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    return {
      date: format(date, "MMMM d, yyyy"),
      time: format(date, "h:mm a"),
      isPast: date < new Date(),
    };
  };

  return (
    <SidebarLayout>
      <div className={isMobile ? "mt-16 mb-16" : ""}>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Doubt Resolution Sessions</h1>
            <p className="mt-1 text-sm text-gray-500">
              Schedule one-on-one sessions with instructors to resolve your doubts
            </p>
          </div>
          <div className="mt-4 md:mt-0">
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Schedule New Session
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Schedule a Doubt Resolution Session</DialogTitle>
                  <DialogDescription>
                    Book a one-on-one session with an instructor to get your doubts resolved.
                  </DialogDescription>
                </DialogHeader>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Session Title</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="E.g., Help with Calculus Integration" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe your doubts in detail" 
                              className="min-h-[100px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="sessionDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Date & Time</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant="outline"
                                    className={`w-full justify-start text-left font-normal ${
                                      !field.value && "text-muted-foreground"
                                    }`}
                                  >
                                    {field.value ? (
                                      format(field.value, "PPP, h:mm a")
                                    ) : (
                                      <span>Select date and time</span>
                                    )}
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <CalendarComponent
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  initialFocus
                                  disabled={(date) => date < new Date()}
                                />
                                <div className="p-3 border-t border-border">
                                  <div className="grid grid-cols-3 gap-2">
                                    {["9:00 AM", "10:00 AM", "11:00 AM", "1:00 PM", "2:00 PM", "3:00 PM"].map((time) => (
                                      <Button
                                        key={time}
                                        variant="outline"
                                        size="sm"
                                        onClick={() => {
                                          if (!field.value) return;
                                          
                                          const [hour, minutePart] = time.split(':');
                                          const [minute, period] = minutePart.split(' ');
                                          
                                          let hours = parseInt(hour);
                                          if (period === 'PM' && hours !== 12) hours += 12;
                                          if (period === 'AM' && hours === 12) hours = 0;
                                          
                                          const newDate = new Date(field.value);
                                          newDate.setHours(hours, parseInt(minute), 0);
                                          
                                          field.onChange(newDate);
                                        }}
                                      >
                                        {time}
                                      </Button>
                                    ))}
                                  </div>
                                </div>
                              </PopoverContent>
                            </Popover>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="duration"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Duration (minutes)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min={15}
                                max={120}
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <DialogFooter>
                      <Button 
                        type="submit" 
                        disabled={createSessionMutation.isPending}
                      >
                        {createSessionMutation.isPending ? "Scheduling..." : "Schedule Session"}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="space-y-6">
          {isLoading ? (
            <div className="text-center py-12">
              <div className="animate-spin h-8 w-8 border-4 border-primary-600 border-t-transparent rounded-full mx-auto"></div>
              <p className="mt-4 text-gray-600">Loading sessions...</p>
            </div>
          ) : sortedSessions.length === 0 ? (
            <div className="text-center py-12 bg-gray-50 rounded-lg">
              <AlertCircle className="h-12 w-12 mx-auto text-gray-400" />
              <h3 className="mt-4 text-lg font-medium text-gray-900">No sessions scheduled</h3>
              <p className="mt-1 text-sm text-gray-500">
                Schedule a session to get your doubts resolved by an instructor.
              </p>
              <Button 
                onClick={() => setIsDialogOpen(true)} 
                className="mt-6"
              >
                Schedule New Session
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sortedSessions.map((session) => {
                const { date, time, isPast } = formatDateTime(session.sessionDate);
                
                return (
                  <Card 
                    key={session.id} 
                    className={isPast ? "opacity-70" : ""}
                  >
                    <CardHeader className={session.status === "completed" 
                      ? "bg-gray-50" 
                      : session.status === "cancelled"
                      ? "bg-red-50"
                      : "bg-blue-50"
                    }>
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{session.title}</CardTitle>
                        <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                          session.status === "scheduled" 
                            ? "bg-blue-100 text-blue-800" 
                            : session.status === "completed"
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }`}>
                          {session.status.charAt(0).toUpperCase() + session.status.slice(1)}
                        </div>
                      </div>
                      <CardDescription>{session.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <div className="space-y-3">
                        <div className="flex items-center">
                          <Calendar className="h-5 w-5 text-gray-500 mr-2" />
                          <span className="text-sm">{date}</span>
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-5 w-5 text-gray-500 mr-2" />
                          <span className="text-sm">{time} ({session.duration} minutes)</span>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="flex justify-between pt-2">
                      {session.status === "scheduled" && !isPast ? (
                        <>
                          {session.meetingUrl ? (
                            <a 
                              href={session.meetingUrl} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="w-full"
                            >
                              <Button className="w-full" variant="default">
                                Join Session
                              </Button>
                            </a>
                          ) : (
                            <Button className="w-full" variant="default" disabled>
                              Awaiting Link
                            </Button>
                          )}
                          <Button variant="outline" className="ml-2">
                            Reschedule
                          </Button>
                        </>
                      ) : session.status === "scheduled" && isPast ? (
                        <Button className="w-full" variant="outline" disabled>
                          Session Time Passed
                        </Button>
                      ) : session.status === "completed" ? (
                        <Button className="w-full" variant="outline">
                          Schedule Follow-up
                        </Button>
                      ) : (
                        <Button className="w-full" variant="outline">
                          Reschedule
                        </Button>
                      )}
                    </CardFooter>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </SidebarLayout>
  );
}
