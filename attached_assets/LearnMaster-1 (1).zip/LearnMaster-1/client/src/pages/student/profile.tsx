import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import SidebarLayout from "@/layouts/sidebar-layout";
import { useMobile } from "@/hooks/use-mobile";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Course, Enrollment, Test, TestAttempt } from "@shared/schema";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export default function StudentProfile() {
  const isMobile = useMobile();
  const { user } = useAuth();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  
  // Get user initials
  const userInitials = user?.fullName
    ? user.fullName.split(" ").map(n => n[0]).join("").toUpperCase()
    : user?.username?.substring(0, 2).toUpperCase() || "";
  
  // Fetch enrollments
  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ["/api/enrollments"],
  });
  
  // Fetch test attempts
  const { data: testAttempts = [] } = useQuery<TestAttempt[]>({
    queryKey: ["/api/test-attempts"],
  });
  
  // Fetch courses
  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });
  
  // Fetch tests
  const { data: tests = [] } = useQuery<Test[]>({
    queryKey: ["/api/tests"],
  });
  
  // Calculate statistics
  const completedEnrollments = enrollments.filter(e => e.completedAt);
  const inProgressEnrollments = enrollments.filter(e => !e.completedAt);
  const completedTests = testAttempts.filter(a => a.status === "completed");
  const averageScore = completedTests.length
    ? completedTests.reduce((sum, a) => sum + (a.percentage || 0), 0) / completedTests.length
    : 0;
  
  // Prepare chart data
  const courseProgressData = enrollments.map(enrollment => {
    const course = courses.find(c => c.id === enrollment.courseId);
    return {
      name: course?.title || `Course ${enrollment.courseId}`,
      progress: enrollment.progress || 0,
    };
  }).sort((a, b) => b.progress - a.progress);
  
  // Test scores by subject
  const testScoresBySubject: Record<string, {total: number, count: number}> = {};
  completedTests.forEach(attempt => {
    const test = tests.find(t => t.id === attempt.testId);
    if (test) {
      const course = courses.find(c => c.id === test.courseId);
      const subject = course?.title || "Unknown";
      
      if (!testScoresBySubject[subject]) {
        testScoresBySubject[subject] = { total: 0, count: 0 };
      }
      
      testScoresBySubject[subject].total += attempt.percentage || 0;
      testScoresBySubject[subject].count += 1;
    }
  });
  
  const testScoresChartData = Object.entries(testScoresBySubject).map(([subject, { total, count }]) => ({
    name: subject,
    score: Math.round(total / count),
  })).sort((a, b) => b.score - a.score);
  
  // Overall stats
  const pieData = [
    { name: "Completed", value: completedEnrollments.length, color: "#10b981" },
    { name: "In Progress", value: inProgressEnrollments.length, color: "#3b82f6" },
  ];
  
  // Handle password change
  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "New password and confirm password must match",
        variant: "destructive",
      });
      return;
    }
    
    // TODO: Implement actual password change API call
    toast({
      title: "Password updated",
      description: "Your password has been updated successfully",
    });
    
    setPasswordForm({
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    });
  };
  
  return (
    <SidebarLayout>
      <div className={isMobile ? "mt-16 mb-16" : ""}>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">My Profile</h1>
            <p className="mt-1 text-sm text-gray-500">
              View and manage your account settings and progress
            </p>
          </div>
        </div>
        
        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList>
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="progress">Progress & Analytics</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
          </TabsList>
          
          {/* Profile Tab */}
          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
                <CardDescription>Update your personal information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col md:flex-row gap-6">
                  <div className="flex flex-col items-center">
                    <Avatar className="h-24 w-24">
                      <AvatarFallback className="text-2xl bg-primary-100 text-primary-600">
                        {userInitials}
                      </AvatarFallback>
                    </Avatar>
                    <Button variant="outline" size="sm" className="mt-4">
                      Change Photo
                    </Button>
                  </div>
                  
                  <div className="flex-1 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="fullName">Full Name</Label>
                        <Input
                          id="fullName"
                          value={user?.fullName || ""}
                          readOnly={!isEditing}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="username">Username</Label>
                        <Input
                          id="username"
                          value={user?.username || ""}
                          readOnly
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      <Input
                        id="email"
                        type="email"
                        value={user?.email || ""}
                        readOnly={!isEditing}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="role">Account Type</Label>
                      <Input
                        id="role"
                        value={user?.role === "admin" ? "Administrator" : "Student"}
                        readOnly
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                {isEditing ? (
                  <div className="flex gap-2">
                    <Button 
                      onClick={() => setIsEditing(false)}
                    >
                      Save Changes
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => setIsEditing(false)}
                    >
                      Cancel
                    </Button>
                  </div>
                ) : (
                  <Button 
                    variant="outline" 
                    onClick={() => setIsEditing(true)}
                  >
                    Edit Profile
                  </Button>
                )}
              </CardFooter>
            </Card>
          </TabsContent>
          
          {/* Progress Tab */}
          <TabsContent value="progress">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Enrolled Courses</CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex items-center justify-center h-40">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={pieData}
                          cx="50%"
                          cy="50%"
                          innerRadius={40}
                          outerRadius={80}
                          fill="#8884d8"
                          paddingAngle={5}
                          dataKey="value"
                          label={({ name, percent }) => 
                            `${name}: ${(percent * 100).toFixed(0)}%`
                          }
                        >
                          {pieData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex justify-between text-sm text-gray-500 mt-2">
                    <div>Total: {enrollments.length}</div>
                    <div>Completed: {completedEnrollments.length}</div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Test Performance</CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="text-center py-4">
                    <div className="text-5xl font-bold text-primary-600">
                      {averageScore.toFixed(0)}%
                    </div>
                    <p className="text-gray-500 mt-2">Average Score</p>
                  </div>
                  <div className="space-y-2 mt-4">
                    <div className="flex justify-between text-sm">
                      <span>Tests Completed</span>
                      <span className="font-medium">{completedTests.length}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Tests Pending</span>
                      <span className="font-medium">
                        {testAttempts.filter(a => a.status === "pending").length}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Learning Activity</CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="h-40 flex items-center justify-center">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={[
                          { day: "Mon", hours: 2.5 },
                          { day: "Tue", hours: 3.8 },
                          { day: "Wed", hours: 1.2 },
                          { day: "Thu", hours: 4.0 },
                          { day: "Fri", hours: 2.0 },
                          { day: "Sat", hours: 0.5 },
                          { day: "Sun", hours: 0.2 },
                        ]}
                        margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} />
                        <XAxis dataKey="day" />
                        <YAxis />
                        <Tooltip formatter={(value) => [`${value} hrs`, "Study Time"]} />
                        <Bar dataKey="hours" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="text-center text-sm text-gray-500 mt-2">
                    Weekly Study Hours: 14.2
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Course Progress</CardTitle>
                  <CardDescription>
                    Progress in your enrolled courses
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {courseProgressData.length > 0 ? (
                      courseProgressData.map((course, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex justify-between">
                            <span className="font-medium text-sm">{course.name}</span>
                            <span className="text-sm">{course.progress}%</span>
                          </div>
                          <Progress value={course.progress} />
                        </div>
                      ))
                    ) : (
                      <p className="text-gray-500 text-center py-6">
                        You are not enrolled in any courses yet.
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Test Scores by Subject</CardTitle>
                  <CardDescription>
                    Average scores across different subjects
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {testScoresChartData.length > 0 ? (
                      testScoresChartData.map((subject, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex justify-between">
                            <span className="font-medium text-sm">{subject.name}</span>
                            <span className="text-sm">{subject.score}%</span>
                          </div>
                          <Progress 
                            value={subject.score} 
                            indicatorColor={
                              subject.score >= 80 
                                ? "bg-green-600" 
                                : subject.score >= 60 
                                ? "bg-amber-600" 
                                : "bg-red-600"
                            }
                          />
                        </div>
                      ))
                    ) : (
                      <p className="text-gray-500 text-center py-6">
                        You haven't completed any tests yet.
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Security Tab */}
          <TabsContent value="security">
            <Card>
              <CardHeader>
                <CardTitle>Change Password</CardTitle>
                <CardDescription>Update your password to keep your account secure</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handlePasswordChange} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="current-password">Current Password</Label>
                    <Input
                      id="current-password"
                      type="password"
                      value={passwordForm.currentPassword}
                      onChange={(e) => setPasswordForm({
                        ...passwordForm,
                        currentPassword: e.target.value,
                      })}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="new-password">New Password</Label>
                    <Input
                      id="new-password"
                      type="password"
                      value={passwordForm.newPassword}
                      onChange={(e) => setPasswordForm({
                        ...passwordForm,
                        newPassword: e.target.value,
                      })}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">Confirm New Password</Label>
                    <Input
                      id="confirm-password"
                      type="password"
                      value={passwordForm.confirmPassword}
                      onChange={(e) => setPasswordForm({
                        ...passwordForm,
                        confirmPassword: e.target.value,
                      })}
                      required
                    />
                  </div>
                  
                  <Button type="submit">Update Password</Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </SidebarLayout>
  );
}
