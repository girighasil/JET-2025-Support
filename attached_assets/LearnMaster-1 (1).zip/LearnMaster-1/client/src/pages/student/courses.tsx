import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import SidebarLayout from "@/layouts/sidebar-layout";
import { useMobile } from "@/hooks/use-mobile";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { 
  Tabs, TabsContent, TabsList, TabsTrigger 
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Play, BookOpen, Video, FileText, Clock } from "lucide-react";
import { Course, Enrollment, Lesson } from "@shared/schema";

export default function StudentCourses() {
  const isMobile = useMobile();
  const [selectedCourseId, setSelectedCourseId] = useState<number | null>(null);
  
  // Fetch courses
  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ['/api/courses'],
  });
  
  // Fetch enrollments
  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ['/api/enrollments'],
  });
  
  // Fetch lessons for the selected course
  const { data: lessons = [] } = useQuery<Lesson[]>({
    queryKey: ['/api/courses', selectedCourseId, 'lessons'],
    enabled: !!selectedCourseId,
  });

  // Get courses with enrollment status and progress
  const coursesWithEnrollment = courses.map(course => {
    const enrollment = enrollments.find(e => e.courseId === course.id);
    return {
      ...course,
      enrolled: !!enrollment,
      progress: enrollment?.progress || 0,
      enrollmentId: enrollment?.id
    };
  });

  // Filter for enrolled courses
  const enrolledCourses = coursesWithEnrollment.filter(course => course.enrolled);

  // Filter for available courses (not enrolled)
  const availableCourses = coursesWithEnrollment.filter(course => !course.enrolled);

  // Handle course selection
  const handleCourseSelect = (courseId: number) => {
    setSelectedCourseId(courseId);
  };

  // Format duration
  const formatDuration = (minutes?: number) => {
    if (!minutes) return "N/A";
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return remainingMinutes > 0 ? `${hours}h ${remainingMinutes}m` : `${hours}h`;
  };

  return (
    <SidebarLayout>
      <div className={isMobile ? "mt-16 mb-16" : ""}>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">My Courses</h1>
            <p className="mt-1 text-sm text-gray-500">
              Access your enrolled courses and track your progress
            </p>
          </div>
        </div>

        <Tabs defaultValue="enrolled" className="space-y-6">
          <TabsList>
            <TabsTrigger value="enrolled">Enrolled Courses</TabsTrigger>
            <TabsTrigger value="available">Available Courses</TabsTrigger>
            {selectedCourseId && <TabsTrigger value="lessons">Course Content</TabsTrigger>}
          </TabsList>

          <TabsContent value="enrolled" className="space-y-6">
            {enrolledCourses.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {enrolledCourses.map((course) => (
                  <Card key={course.id} className="overflow-hidden hover:shadow-md transition-shadow">
                    <div className="h-40 bg-primary-100 relative">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <BookOpen className="text-primary-500 h-16 w-16 opacity-50" />
                      </div>
                      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent text-white p-4">
                        <h3 className="font-medium text-lg">{course.title}</h3>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="text-sm font-medium">Progress</div>
                        <div className="text-sm text-primary-600">{course.progress}%</div>
                      </div>
                      <Progress value={course.progress} className="h-2 mb-4" />
                      
                      <div className="flex items-center text-sm text-gray-500 mb-4">
                        <Clock className="h-4 w-4 mr-1" />
                        <span>{course.duration} weeks</span>
                      </div>
                      
                      <div className="flex justify-between">
                        <Button 
                          onClick={() => handleCourseSelect(course.id)}
                          className="flex items-center gap-1"
                        >
                          <Play className="h-4 w-4" />
                          Continue Learning
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-10 bg-gray-50 rounded-lg">
                <BookOpen className="h-12 w-12 mx-auto text-gray-400" />
                <h3 className="mt-4 text-lg font-medium text-gray-900">No enrolled courses</h3>
                <p className="mt-1 text-sm text-gray-500">Explore our available courses and start learning today.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="available" className="space-y-6">
            {availableCourses.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {availableCourses.map((course) => (
                  <Card key={course.id} className="overflow-hidden hover:shadow-md transition-shadow">
                    <div className="h-40 bg-gray-100 relative">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <BookOpen className="text-gray-400 h-16 w-16 opacity-50" />
                      </div>
                      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent text-white p-4">
                        <h3 className="font-medium text-lg">{course.title}</h3>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <p className="text-sm text-gray-500 line-clamp-2 mb-4">
                        {course.description}
                      </p>
                      
                      <div className="flex items-center text-sm text-gray-500 mb-4">
                        <Clock className="h-4 w-4 mr-1" />
                        <span>{course.duration} weeks</span>
                      </div>
                      
                      <div className="flex justify-between">
                        <Button 
                          onClick={() => handleCourseSelect(course.id)}
                          variant="outline"
                          className="mr-2"
                        >
                          View Details
                        </Button>
                        <Button>Enroll Now</Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-10 bg-gray-50 rounded-lg">
                <BookOpen className="h-12 w-12 mx-auto text-gray-400" />
                <h3 className="mt-4 text-lg font-medium text-gray-900">No courses available</h3>
                <p className="mt-1 text-sm text-gray-500">Check back later for new course offerings.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="lessons" className="space-y-6">
            {selectedCourseId && (
              <>
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold">
                    {courses.find(c => c.id === selectedCourseId)?.title} - Lessons
                  </h2>
                  <Button variant="outline" onClick={() => setSelectedCourseId(null)}>
                    Back to Courses
                  </Button>
                </div>

                {lessons.length > 0 ? (
                  <div className="space-y-4">
                    {lessons.map((lesson, index) => (
                      <Card key={lesson.id}>
                        <CardContent className="p-4">
                          <div className="flex items-start">
                            <div className="flex-shrink-0 h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center mr-4">
                              <span className="font-medium text-primary-700">{index + 1}</span>
                            </div>
                            <div className="flex-1">
                              <h3 className="text-lg font-medium">{lesson.title}</h3>
                              <p className="text-sm text-gray-500 mt-1">{lesson.description}</p>
                              
                              <div className="flex flex-wrap gap-3 mt-3">
                                {lesson.videoUrl && (
                                  <div className="flex items-center text-sm text-gray-600">
                                    <Video className="h-4 w-4 mr-1" />
                                    <span>Video Lesson</span>
                                  </div>
                                )}
                                <div className="flex items-center text-sm text-gray-600">
                                  <FileText className="h-4 w-4 mr-1" />
                                  <span>Study Materials</span>
                                </div>
                                <div className="flex items-center text-sm text-gray-600">
                                  <Clock className="h-4 w-4 mr-1" />
                                  <span>{formatDuration(lesson.duration)}</span>
                                </div>
                              </div>
                            </div>
                            <div className="ml-4">
                              <Button variant="outline" className="flex items-center gap-1">
                                <Play className="h-4 w-4" />
                                Start
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-10 bg-gray-50 rounded-lg">
                    <FileText className="h-12 w-12 mx-auto text-gray-400" />
                    <h3 className="mt-4 text-lg font-medium text-gray-900">No lessons available</h3>
                    <p className="mt-1 text-sm text-gray-500">Content for this course is currently being prepared.</p>
                  </div>
                )}
              </>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </SidebarLayout>
  );
}
