import { useState } from "react";
import { Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import SidebarLayout from "@/layouts/sidebar-layout";
import { useMobile } from "@/hooks/use-mobile";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  AlertCircle,
  CheckCircle,
  Clock,
  ClipboardCheck,
  Filter,
  Search,
  HourglassIcon,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Test, TestAttempt, Course, Enrollment } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";

export default function StudentTests() {
  const isMobile = useMobile();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [courseFilter, setCourseFilter] = useState("all");
  const { user } = useAuth();
  const { toast } = useToast();
  
  // Fetch tests
  const { data: tests = [], isLoading: testsLoading } = useQuery<Test[]>({
    queryKey: ["/api/tests"],
  });

  // Fetch test attempts
  const { data: attempts = [], isLoading: attemptsLoading } = useQuery<TestAttempt[]>({
    queryKey: ["/api/test-attempts"],
  });

  // Fetch courses
  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });
  
  // Fetch enrollments
  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ["/api/enrollments"],
  });
  
  // Enrollment mutation
  const enrollMutation = useMutation({
    mutationFn: async (testId: number) => {
      const res = await apiRequest("POST", "/api/enrollments", {
        userId: user?.id,
        testId,
        enrollmentType: "test",
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/enrollments"] });
      toast({
        title: "Enrollment request submitted",
        description: "Your enrollment request has been submitted and is pending approval.",
        variant: "default",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Enrollment failed",
        description: error.message || "An error occurred while trying to enroll in the test.",
        variant: "destructive",
      });
    },
  });

  // Map tests to attempts and enrollments
  const testsWithAttempts = tests.map(test => {
    const userAttempts = attempts.filter(a => a.testId === test.id);
    const latestAttempt = userAttempts.length > 0
      ? userAttempts.reduce((latest, current) => 
          new Date(current.startedAt) > new Date(latest.startedAt) ? current : latest
        )
      : null;
    
    const enrollment = enrollments.find(e => e.testId === test.id);
    const course = courses.find(c => c.id === test.courseId);
    
    return {
      ...test,
      latestAttempt,
      course,
      status: latestAttempt?.status || "unattempted",
      enrollment,
      enrollmentStatus: enrollment?.status || "none"
    };
  });

  // Filter tests
  const filteredTests = testsWithAttempts.filter(test => {
    // Filter by search query
    const matchesSearch = test.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      test.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Filter by status
    const matchesStatus = statusFilter === "all" || 
      (statusFilter === "completed" && test.status === "completed") ||
      (statusFilter === "pending" && test.status === "pending") ||
      (statusFilter === "unattempted" && test.status === "unattempted");
    
    // Filter by course
    const matchesCourse = courseFilter === "all" || test.courseId?.toString() === courseFilter;
    
    return matchesSearch && matchesStatus && matchesCourse;
  });

  // Separate tests by status
  const pendingTests = filteredTests.filter(test => test.status === "pending");
  const completedTests = filteredTests.filter(test => test.status === "completed");
  const unattemptedTests = filteredTests.filter(test => test.status === "unattempted");

  // Format date
  const formatDate = (dateString?: string) => {
    if (!dateString) return "Not started";
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  // Get badge color based on score
  const getScoreBadgeColor = (percentage?: number) => {
    if (!percentage) return "bg-gray-100 text-gray-800";
    if (percentage >= 80) return "bg-green-100 text-green-800";
    if (percentage >= 60) return "bg-yellow-100 text-yellow-800";
    return "bg-red-100 text-red-800";
  };

  return (
    <SidebarLayout>
      <div className={isMobile ? "mt-16 mb-16" : ""}>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Test Series</h1>
            <p className="mt-1 text-sm text-gray-500">
              Practice with tests and track your performance
            </p>
          </div>
        </div>

        {/* Search and filters */}
        <div className="mb-6 flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Input
              placeholder="Search tests..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          </div>
          <div className="flex gap-2">
            <div className="w-40">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Tests</SelectItem>
                  <SelectItem value="unattempted">Unattempted</SelectItem>
                  <SelectItem value="pending">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="w-40">
              <Select value={courseFilter} onValueChange={setCourseFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Course" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Courses</SelectItem>
                  {courses.map(course => (
                    <SelectItem key={course.id} value={course.id.toString()}>
                      {course.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <Tabs defaultValue="all" className="space-y-6">
          <TabsList>
            <TabsTrigger value="all">All Tests ({filteredTests.length})</TabsTrigger>
            <TabsTrigger value="pending">In Progress ({pendingTests.length})</TabsTrigger>
            <TabsTrigger value="completed">Completed ({completedTests.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-6">
            {filteredTests.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredTests.map((test) => (
                  <TestCard 
                    key={test.id} 
                    test={test} 
                    formatDate={formatDate} 
                    getScoreBadgeColor={getScoreBadgeColor} 
                  />
                ))}
              </div>
            ) : (
              <EmptyState
                icon={<ClipboardCheck className="h-12 w-12 text-gray-400" />}
                title="No tests found"
                message="Try adjusting your filters or search query."
              />
            )}
          </TabsContent>

          <TabsContent value="pending" className="space-y-6">
            {pendingTests.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {pendingTests.map((test) => (
                  <TestCard 
                    key={test.id} 
                    test={test} 
                    formatDate={formatDate} 
                    getScoreBadgeColor={getScoreBadgeColor} 
                  />
                ))}
              </div>
            ) : (
              <EmptyState
                icon={<Clock className="h-12 w-12 text-gray-400" />}
                title="No tests in progress"
                message="All your started tests have been completed."
              />
            )}
          </TabsContent>

          <TabsContent value="completed" className="space-y-6">
            {completedTests.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {completedTests.map((test) => (
                  <TestCard 
                    key={test.id} 
                    test={test} 
                    formatDate={formatDate} 
                    getScoreBadgeColor={getScoreBadgeColor} 
                  />
                ))}
              </div>
            ) : (
              <EmptyState
                icon={<CheckCircle className="h-12 w-12 text-gray-400" />}
                title="No completed tests"
                message="You haven't completed any tests yet."
              />
            )}
          </TabsContent>
        </Tabs>
      </div>
    </SidebarLayout>
  );
}

interface TestCardProps {
  test: Test & { 
    latestAttempt: TestAttempt | null, 
    course: Course | undefined, 
    status: string,
    enrollment: Enrollment | undefined,
    enrollmentStatus: string
  };
  formatDate: (date?: string) => string;
  getScoreBadgeColor: (percentage?: number) => string;
}

function TestCard({ test, formatDate, getScoreBadgeColor }: TestCardProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  
  // Enrollment mutation
  const enrollMutation = useMutation({
    mutationFn: async (testId: number) => {
      const res = await apiRequest("POST", "/api/enrollments", {
        userId: user?.id,
        testId,
        enrollmentType: "test",
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/enrollments"] });
      toast({
        title: "Enrollment request submitted",
        description: "Your enrollment request has been submitted and is pending approval.",
        variant: "default",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Enrollment failed",
        description: error.message || "An error occurred while trying to enroll in the test.",
        variant: "destructive",
      });
    },
  });
  
  const handleEnrollClick = () => {
    enrollMutation.mutate(test.id);
  };
  
  // Get enrollment status badge
  const getEnrollmentBadge = () => {
    switch (test.enrollmentStatus) {
      case "pending":
        return (
          <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
            Enrollment Pending
          </Badge>
        );
      case "rejected":
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">
            Enrollment Rejected
          </Badge>
        );
      case "none":
        return null;
      default:
        return null;
    }
  };
  
  // Check if user can take the test
  const canTakeTest = test.enrollmentStatus === "approved" || 
                      user?.role === "admin" || 
                      user?.role === "teacher";
  
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <div className="border-b border-gray-200 p-4">
        <div className="flex justify-between">
          <h3 className="text-lg font-medium text-gray-900">{test.title}</h3>
          {test.status === "unattempted" ? (
            <Badge variant="outline">Not Started</Badge>
          ) : test.status === "pending" ? (
            <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
              In Progress
            </Badge>
          ) : (
            <Badge 
              variant="outline" 
              className={getScoreBadgeColor(test.latestAttempt?.percentage)}
            >
              {test.latestAttempt?.percentage?.toFixed(0)}%
            </Badge>
          )}
        </div>
        <div className="flex justify-between items-center mt-1">
          <p className="text-sm text-gray-500">{test.course?.title || "General Test"}</p>
          {getEnrollmentBadge()}
        </div>
      </div>
      <CardContent className="p-4">
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Questions:</span>
            <span className="font-medium">{test.totalQuestions}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Duration:</span>
            <span className="font-medium">{test.duration} minutes</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Passing Score:</span>
            <span className="font-medium">{test.passingScore}%</span>
          </div>
          {test.latestAttempt && (
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Last Attempt:</span>
              <span className="font-medium">{formatDate(test.latestAttempt.startedAt)}</span>
            </div>
          )}
          
          {test.latestAttempt?.status === "completed" && (
            <div className="mt-3">
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-500">Score:</span>
                <span className="font-medium">
                  {test.latestAttempt.score}/{test.latestAttempt.maxScore} ({test.latestAttempt.percentage?.toFixed(0)}%)
                </span>
              </div>
              <Progress 
                value={test.latestAttempt?.percentage || 0} 
                indicatorColor={
                  (test.latestAttempt?.percentage || 0) >= test.passingScore 
                    ? "bg-green-600" 
                    : "bg-red-600"
                }
              />
            </div>
          )}
          
          <div className="pt-3">
            {test.enrollmentStatus === "none" ? (
              <Button 
                className="w-full" 
                onClick={handleEnrollClick}
                disabled={enrollMutation.isPending}
              >
                {enrollMutation.isPending ? (
                  <div className="flex items-center">
                    <HourglassIcon className="mr-2 h-4 w-4 animate-spin" />
                    Requesting...
                  </div>
                ) : (
                  "Request Enrollment"
                )}
              </Button>
            ) : test.enrollmentStatus === "pending" ? (
              <Button disabled className="w-full bg-blue-100 text-blue-800 hover:bg-blue-100">
                Awaiting Approval
              </Button>
            ) : test.enrollmentStatus === "rejected" ? (
              <Button 
                variant="outline" 
                className="w-full border-red-200 text-red-800"
                onClick={handleEnrollClick}
                disabled={enrollMutation.isPending}
              >
                {enrollMutation.isPending ? "Requesting..." : "Request Again"}
              </Button>
            ) : canTakeTest && (test.status === "unattempted" || test.status === "pending") ? (
              <Link href={`/student/test/${test.latestAttempt?.id || test.id}`}>
                <Button className="w-full">
                  {test.status === "pending" ? "Continue Test" : "Start Test"}
                </Button>
              </Link>
            ) : test.status === "completed" ? (
              <div className="flex space-x-2">
                <Link href={`/student/test/${test.latestAttempt?.id}`}>
                  <Button variant="secondary" className="flex-1">
                    View Report
                  </Button>
                </Link>
                <Button className="flex-1">
                  Retake Test
                </Button>
              </div>
            ) : (
              <Button disabled className="w-full">
                Not Available
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

interface EmptyStateProps {
  icon: React.ReactNode;
  title: string;
  message: string;
}

function EmptyState({ icon, title, message }: EmptyStateProps) {
  return (
    <div className="text-center py-12 bg-gray-50 rounded-lg border border-gray-200">
      <div className="flex justify-center">{icon}</div>
      <h3 className="mt-4 text-lg font-medium text-gray-900">{title}</h3>
      <p className="mt-1 text-sm text-gray-500">{message}</p>
    </div>
  );
}
