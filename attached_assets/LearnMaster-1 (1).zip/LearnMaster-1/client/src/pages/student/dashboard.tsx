import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import SidebarLayout from "@/layouts/sidebar-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Home, BookOpen, ClipboardCheck, Clock, Calendar, Play,
  ChevronRight, Video
} from "lucide-react";
import { useMobile } from "@/hooks/use-mobile";
import { Course, Enrollment, Test, TestAttempt, Session } from "@shared/schema";

export default function StudentDashboard() {
  const { user } = useAuth();
  const isMobile = useMobile();
  const firstName = user?.fullName?.split(' ')[0] || user?.username || 'Student';

  // Fetch enrollments
  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ['/api/enrollments'],
  });

  // Fetch test attempts
  const { data: testAttempts = [] } = useQuery<TestAttempt[]>({
    queryKey: ['/api/test-attempts'],
  });

  // Fetch sessions
  const { data: sessions = [] } = useQuery<Session[]>({
    queryKey: ['/api/sessions'],
  });

  // Fetch courses
  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ['/api/courses'],
  });

  // Fetch tests
  const { data: tests = [] } = useQuery<Test[]>({
    queryKey: ['/api/tests'],
  });

  // Calculate total progress across all courses
  const calculateOverallProgress = () => {
    if (enrollments.length === 0) return 0;
    const totalProgress = enrollments.reduce((sum, enrollment) => sum + (enrollment.progress || 0), 0);
    return Math.round(totalProgress / enrollments.length);
  };

  // Calculate test performance average
  const calculateTestPerformance = () => {
    const completedAttempts = testAttempts.filter(attempt => attempt.status === 'completed');
    if (completedAttempts.length === 0) return 0;
    const totalScore = completedAttempts.reduce((sum, attempt) => sum + (attempt.percentage || 0), 0);
    return Math.round(totalScore / completedAttempts.length);
  };

  // Get in-progress enrollments
  const inProgressCourses = enrollments
    .filter(enrollment => (enrollment.progress || 0) < 100)
    .map(enrollment => {
      const course = courses.find(c => c.id === enrollment.courseId);
      return { enrollment, course };
    })
    .filter(item => item.course) // Only include if course exists
    .slice(0, 3); // Limit to 3

  // Get upcoming tests
  const pendingTests = testAttempts
    .filter(attempt => attempt.status === 'pending')
    .map(attempt => {
      const test = tests.find(t => t.id === attempt.testId);
      return { attempt, test };
    })
    .filter(item => item.test) // Only include if test exists
    .slice(0, 1); // Limit to 1

  // Get upcoming sessions
  const upcomingSessions = sessions
    .filter(session => 
      session.status === 'scheduled' && 
      session.sessionDate && 
      new Date(session.sessionDate) > new Date()
    )
    .sort((a, b) => {
      if (!a.sessionDate) return 1;
      if (!b.sessionDate) return -1;
      return new Date(a.sessionDate).getTime() - new Date(b.sessionDate).getTime();
    })
    .slice(0, 1); // Get closest upcoming session

  // Get recent test attempts
  const recentTestAttempts = [...testAttempts]
    .sort((a, b) => {
      if (!a.startedAt) return 1;
      if (!b.startedAt) return -1;
      return new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime();
    })
    .slice(0, 3);

  // Format date
  const formatDate = (dateString: string | Date | null) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <SidebarLayout>
      <div className={isMobile ? "mt-16 mb-16" : ""}>
        <div className="lg:flex lg:items-center lg:justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Welcome back, {firstName}!</h1>
            <p className="mt-1 text-sm text-gray-500">
              Continue your learning journey and track your progress.
            </p>
          </div>
          <div className="mt-4 lg:mt-0">
            <Link href="/student/doubts">
              <Button className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Schedule Doubt Session
              </Button>
            </Link>
          </div>
        </div>
        
        {/* Progress Summary */}
        <div className="mt-6">
          <h2 className="text-lg font-medium text-gray-900">Your Progress</h2>
          <div className="mt-2 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {/* Course Progress Card */}
            <Card>
              <CardContent className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0 bg-primary-100 rounded-md p-3">
                    <BookOpen className="text-primary-600 text-xl" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Course Completion</dt>
                      <dd>
                        <div className="text-lg font-medium text-gray-900">{calculateOverallProgress()}%</div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </CardContent>
              <div className="bg-gray-50 px-5 py-3">
                <div className="text-sm">
                  <Link href="/student/courses" className="font-medium text-primary-600 hover:text-primary-500">
                    View all courses
                  </Link>
                </div>
              </div>
            </Card>
            
            {/* Test Performance Card */}
            <Card>
              <CardContent className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0 bg-green-100 rounded-md p-3">
                    <ClipboardCheck className="text-green-600 text-xl" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Test Performance</dt>
                      <dd>
                        <div className="text-lg font-medium text-gray-900">{calculateTestPerformance()}%</div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </CardContent>
              <div className="bg-gray-50 px-5 py-3">
                <div className="text-sm">
                  <Link href="/student/tests" className="font-medium text-primary-600 hover:text-primary-500">
                    View test reports
                  </Link>
                </div>
              </div>
            </Card>
            
            {/* Study Time Card - This would need actual tracking data */}
            <Card>
              <CardContent className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0 bg-amber-100 rounded-md p-3">
                    <Clock className="text-amber-500 text-xl" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Study Time (This Week)</dt>
                      <dd>
                        <div className="text-lg font-medium text-gray-900">
                          {/* This would need actual tracking */}
                          {(Math.random() * 20).toFixed(1)} hours
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </CardContent>
              <div className="bg-gray-50 px-5 py-3">
                <div className="text-sm">
                  <span className="font-medium text-primary-600 hover:text-primary-500">
                    View detailed analytics
                  </span>
                </div>
              </div>
            </Card>
          </div>
        </div>
        
        {/* Continue Learning */}
        <div className="mt-8">
          <h2 className="text-lg font-medium text-gray-900">Continue Learning</h2>
          <div className="mt-2 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {/* Recent Course Cards */}
            {inProgressCourses.map(({ course, enrollment }) => (
              <Card key={enrollment.id} className="hover:shadow-md transition-shadow">
                <div className="h-36 bg-primary-100 relative">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Play className="text-primary-500 text-4xl" />
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent text-white p-3">
                    <h3 className="font-medium">{course?.title}</h3>
                  </div>
                </div>
                <div className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-gray-500">
                      <span>Enrolled: {formatDate(enrollment.enrolledAt)}</span>
                    </div>
                    <div className="text-sm text-green-600 font-medium">
                      <span>{enrollment.progress || 0}% complete</span>
                    </div>
                  </div>
                  <div className="mt-3">
                    <Progress 
                      value={enrollment.progress || 0} 
                      className="h-1.5" 
                      indicatorColor="bg-green-600" 
                    />
                  </div>
                  <div className="mt-4">
                    <Link href={`/student/courses`} className="text-primary-600 hover:text-primary-500 text-sm font-medium">
                      Continue learning
                    </Link>
                  </div>
                </div>
              </Card>
            ))}
            
            {/* Pending Test Card */}
            {pendingTests.map(({ test, attempt }) => (
              <Card key={attempt.id} className="hover:shadow-md transition-shadow">
                <div className="p-4 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900">{test?.title}</h3>
                  <p className="text-sm text-gray-500 mt-1">{test?.description}</p>
                </div>
                <div className="p-4">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-8 w-8 bg-amber-100 rounded-full flex items-center justify-center">
                      <Clock className="text-amber-500 h-4 w-4" />
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-900">Duration: {test?.duration} minutes</p>
                      <p className="text-xs text-gray-500">Questions: {test?.totalQuestions}</p>
                    </div>
                  </div>
                  <div className="mt-4">
                    <Link href={`/student/test/${attempt.id}`}>
                      <Button variant="default" className="w-full" style={{ backgroundColor: "#f59e0b", borderColor: "#f59e0b" }}>
                        Start Test
                      </Button>
                    </Link>
                  </div>
                </div>
              </Card>
            ))}
            
            {/* Upcoming Session Card */}
            {upcomingSessions.map(session => {
              const sessionDate = new Date(session.sessionDate);
              const timeString = sessionDate.toLocaleTimeString('en-US', {
                hour: 'numeric',
                minute: '2-digit',
                hour12: true
              });
              const dateString = sessionDate.toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric'
              });
              
              return (
                <Card key={session.id} className="hover:shadow-md transition-shadow">
                  <div className="p-4 border-b border-gray-200 bg-blue-50">
                    <div className="flex justify-between">
                      <h3 className="text-lg font-medium text-gray-900">Upcoming Session</h3>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        <Video className="w-3 h-3 mr-1" /> Live
                      </span>
                    </div>
                  </div>
                  <div className="p-4">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <Calendar className="text-blue-500" />
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-900">{session.title}</p>
                        <p className="text-xs text-gray-500">{dateString}, {timeString} ({session.duration} min)</p>
                      </div>
                    </div>
                    <div className="mt-4 flex space-x-3">
                      <Button className="flex-1 bg-blue-600 hover:bg-blue-700">
                        Join Session
                      </Button>
                      <Button variant="outline" className="flex-1">
                        Reschedule
                      </Button>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
        
        {/* Recent Tests */}
        <div className="mt-8">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-medium text-gray-900">Recent Tests</h2>
            <Link href="/student/tests" className="text-sm font-medium text-primary-600 hover:text-primary-500">
              View all tests
            </Link>
          </div>
          <div className="mt-2 overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
            <table className="min-w-full divide-y divide-gray-300">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6">Test Name</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Date</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Score</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Status</th>
                  <th scope="col" className="relative py-3.5 pl-3 pr-4 sm:pr-6">
                    <span className="sr-only">Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 bg-white">
                {recentTestAttempts.map(attempt => {
                  const test = tests.find(t => t.id === attempt.testId);
                  
                  return (
                    <tr key={attempt.id}>
                      <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">
                        {test?.title || 'Unknown Test'}
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                        {formatDate(attempt.startedAt)}
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                        {attempt.status === 'completed' ? `${Math.round(attempt.percentage || 0)}/100` : '-'}
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                        {attempt.status === 'completed' ? (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            Completed
                          </span>
                        ) : attempt.status === 'pending' ? (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                            Pending
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                            Missed
                          </span>
                        )}
                      </td>
                      <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
                        {attempt.status === 'completed' ? (
                          <Link href={`/student/test/${attempt.id}`} className="text-primary-600 hover:text-primary-900">
                            View Report
                          </Link>
                        ) : attempt.status === 'pending' ? (
                          <Link href={`/student/test/${attempt.id}`} className="text-primary-600 hover:text-primary-900">
                            Take Test
                          </Link>
                        ) : (
                          <span className="text-gray-400">Expired</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
                
                {recentTestAttempts.length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-4 text-center text-sm text-gray-500">
                      No recent test attempts.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </SidebarLayout>
  );
}
