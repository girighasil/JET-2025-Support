import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Safely parses a string to an integer, returning 0 if the input is invalid
 * @param value The string value to parse
 * @param fallback Optional fallback value if parsing fails (default: 0)
 * @returns The parsed integer or fallback value
 */
export function safeParseInt(value: string | undefined | null, fallback = 0): number {
  if (value === undefined || value === null || value === '') return fallback;
  const parsed = parseInt(value);
  return isNaN(parsed) ? fallback : parsed;
}

/**
 * Safely parses a string to a float, returning 0 if the input is invalid
 * @param value The string value to parse
 * @param fallback Optional fallback value if parsing fails (default: 0)
 * @returns The parsed float or fallback value
 */
export function safeParseFloat(value: string | undefined | null, fallback = 0): number {
  if (value === undefined || value === null || value === '') return fallback;
  const parsed = parseFloat(value);
  return isNaN(parsed) ? fallback : parsed;
}
