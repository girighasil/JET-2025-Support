import { AdminLayout } from "@/components/admin/AdminLayout";
import { ManageDoubtSessionsPage } from "@/components/shared/ManageDoubtSessionsPage";
import { useRolePermissions } from "@/hooks/use-role-permissions";
import { useEffect } from "react";
import { useLocation } from "wouter";

function AdminDoubtSessionsPage() {
  const [, navigate] = useLocation();
  const { isAdmin } = useRolePermissions();
  
  // Redirect if not an admin
  useEffect(() => {
    if (!isAdmin) {
      navigate("/login");
    }
  }, [isAdmin, navigate]);

  if (!isAdmin) {
    return null;
  }

  return (
    <ManageDoubtSessionsPage containerComponent={AdminLayout} />
  );
}

export default AdminDoubtSessionsPage;