import { AdminLayout } from "@/components/admin/AdminLayout";
import { ManageTestSeriesPage } from "@/components/shared/ManageTestSeriesPage";

export default function AdminTestSeries() {
  return <ManageTestSeriesPage containerComponent={AdminLayout} />;
}