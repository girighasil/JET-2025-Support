import { useParams } from "wouter";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { TestSeriesForm } from "@/components/shared/TestSeriesForm";

export default function AdminTestSeriesForm() {
  const params = useParams();
  const testSeriesId = params.id ? parseInt(params.id) : undefined;
  
  return (
    <TestSeriesForm
      containerComponent={AdminLayout}
      testSeriesId={testSeriesId}
    />
  );
}