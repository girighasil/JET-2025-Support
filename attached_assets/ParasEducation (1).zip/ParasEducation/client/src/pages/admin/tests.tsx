import { AdminLayout } from "@/components/admin/AdminLayout";
import { ManageTestsPage } from "@/components/shared/ManageTestsPage";

export default function AdminTests() {
  return <ManageTestsPage containerComponent={AdminLayout} />;
}