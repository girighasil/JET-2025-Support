import { AdminLayout } from "@/components/admin/AdminLayout";
import { ManageCoursesPage } from "@/components/shared/ManageCoursesPage";

export default function AdminCourses() {
  return <ManageCoursesPage containerComponent={AdminLayout} />;
}