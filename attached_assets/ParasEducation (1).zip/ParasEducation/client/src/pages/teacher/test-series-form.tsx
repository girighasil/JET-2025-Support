import { useParams } from "wouter";
import { TeacherLayout } from "@/components/teacher/TeacherLayout";
import { TestSeriesForm } from "@/components/shared/TestSeriesForm";
import { useRolePermissions } from "@/hooks/use-role-permissions";
import { useEffect } from "react";
import { useLocation } from "wouter";

export default function TeacherTestSeriesForm() {
  const params = useParams();
  const testSeriesId = params.id ? parseInt(params.id) : undefined;
  const [, navigate] = useLocation();
  const { isTeacher } = useRolePermissions();
  
  // Redirect if not a teacher
  useEffect(() => {
    if (!isTeacher) {
      navigate("/login");
    }
  }, [isTeacher, navigate]);

  if (!isTeacher) {
    return null;
  }
  
  return (
    <TestSeriesForm
      containerComponent={TeacherLayout}
      testSeriesId={testSeriesId}
    />
  );
}