import { TeacherLayout } from "@/components/teacher/TeacherLayout";
import { ManageDoubtSessionsPage } from "@/components/shared/ManageDoubtSessionsPage";
import { useRolePermissions } from "@/hooks/use-role-permissions";
import { useEffect } from "react";
import { useLocation } from "wouter";

function TeacherDoubtSessionsPage() {
  const [, navigate] = useLocation();
  const { isTeacher } = useRolePermissions();
  
  // Redirect if not a teacher
  useEffect(() => {
    if (!isTeacher) {
      navigate("/login");
    }
  }, [isTeacher, navigate]);

  if (!isTeacher) {
    return null;
  }

  return (
    <ManageDoubtSessionsPage containerComponent={TeacherLayout} />
  );
}

export default TeacherDoubtSessionsPage;