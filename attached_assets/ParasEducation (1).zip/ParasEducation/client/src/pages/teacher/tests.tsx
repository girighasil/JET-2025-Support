import { TeacherLayout } from "@/components/teacher/TeacherLayout";
import { ManageTestsPage } from "@/components/shared/ManageTestsPage";
import { useRolePermissions } from "@/hooks/use-role-permissions";
import { useEffect } from "react";
import { useLocation } from "wouter";

function TeacherTestsPage() {
  const [, navigate] = useLocation();
  const { isTeacher } = useRolePermissions();
  
  // Redirect if not a teacher
  useEffect(() => {
    if (!isTeacher) {
      navigate("/login");
    }
  }, [isTeacher, navigate]);

  if (!isTeacher) {
    return null;
  }

  return (
    <ManageTestsPage containerComponent={TeacherLayout} />
  );
}

export default TeacherTestsPage;