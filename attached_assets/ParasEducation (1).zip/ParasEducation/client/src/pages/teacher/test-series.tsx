import { TeacherLayout } from "@/components/teacher/TeacherLayout";
import { ManageTestSeriesPage } from "@/components/shared/ManageTestSeriesPage";

export default function TeacherTestSeries() {
  return <ManageTestSeriesPage containerComponent={TeacherLayout} />;
}