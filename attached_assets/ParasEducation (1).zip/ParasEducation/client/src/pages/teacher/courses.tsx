import { TeacherLayout } from "@/components/teacher/TeacherLayout";
import { ManageCoursesPage } from "@/components/shared/ManageCoursesPage";

export default function TeacherCourses() {
  return <ManageCoursesPage containerComponent={TeacherLayout} />;
}