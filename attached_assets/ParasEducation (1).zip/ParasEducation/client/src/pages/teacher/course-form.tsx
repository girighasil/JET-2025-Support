import { useState, useEffect } from "react";
import { TeacherLayout } from "@/components/teacher/TeacherLayout";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getQueryFn, apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Course } from "@/types";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Save, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { MultiSelect } from "@/components/ui/multi-select";

const courseSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  duration: z.string().min(1, "Duration is required"),
  modules: z.number().min(1, "At least 1 module is required"),
  price: z.number().min(0, "Price cannot be negative"),
  discountPrice: z.number().nullable().optional(),
  imageUrl: z.string().url("Please enter a valid URL for the image"),
  categories: z.array(z.string()).min(1, "At least one category is required"),
  popular: z.boolean().default(false),
  isLive: z.boolean().default(false),
});

type CourseFormValues = z.infer<typeof courseSchema>;

interface CourseFormProps {
  courseId?: number;
}

export default function CourseForm({ courseId }: CourseFormProps) {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [availableCategories, setAvailableCategories] = useState<string[]>([
    "JEE Main/Advanced", 
    "NEET", 
    "Banking", 
    "SSC", 
    "Mathematics", 
    "Physics", 
    "Chemistry", 
    "Biology",
    "Quantitative Aptitude",
    "IIT-JEE",
    "Calculus",
    "General"
  ]);

  const isEditing = !!courseId;
  const title = isEditing ? "Edit Course" : "Create Course";

  const form = useForm<CourseFormValues>({
    resolver: zodResolver(courseSchema),
    defaultValues: {
      title: "",
      description: "",
      duration: "",
      modules: 1,
      price: 0,
      discountPrice: null,
      imageUrl: "",
      categories: [],
      popular: false,
      isLive: false,
    },
  });

  const { data: course, isLoading: isCourseLoading } = useQuery<Course>({
    queryKey: [`/api/teacher/courses/${courseId}`],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: isEditing,
  });

  useEffect(() => {
    if (course) {
      form.reset({
        title: course.title,
        description: course.description,
        duration: course.duration,
        modules: course.modules,
        price: course.price,
        discountPrice: course.discountPrice,
        imageUrl: course.imageUrl,
        categories: course.categories,
        popular: course.popular,
        isLive: course.isLive,
      });
    }
  }, [course, form]);

  const createMutation = useMutation({
    mutationFn: (data: CourseFormValues) => {
      return apiRequest("POST", "/api/teacher/courses", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teacher/my-courses"] });
      toast({
        title: "Course created",
        description: "Your course has been created successfully. It is saved as a draft and will be reviewed by an admin before publishing.",
      });
      navigate("/teacher/courses");
    },
    onError: (error) => {
      console.error("Failed to create course:", error);
      toast({
        title: "Failed to create course",
        description: "An error occurred while creating the course. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data: CourseFormValues) => {
      return apiRequest("PUT", `/api/teacher/courses/${courseId}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teacher/my-courses"] });
      queryClient.invalidateQueries({ queryKey: [`/api/teacher/courses/${courseId}`] });
      toast({
        title: "Course updated",
        description: "Your course has been updated successfully.",
      });
      navigate("/teacher/courses");
    },
    onError: (error) => {
      console.error("Failed to update course:", error);
      toast({
        title: "Failed to update course",
        description: "An error occurred while updating the course. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CourseFormValues) => {
    if (isEditing) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  if (isEditing && isCourseLoading) {
    return (
      <TeacherLayout title={title}>
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </TeacherLayout>
    );
  }

  return (
    <TeacherLayout title={title}>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Course Information</CardTitle>
              <CardDescription>
                Enter the details for your course. Fields marked with * are required.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Course Title *</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Advanced Mathematics for JEE" {...field} />
                    </FormControl>
                    <FormDescription>
                      A clear and descriptive title for your course.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description *</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Provide a detailed description of your course..."
                        rows={5}
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Describe what the student will learn, key topics covered, etc.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="duration"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Duration *</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., 3 months" {...field} />
                      </FormControl>
                      <FormDescription>
                        How long will it take to complete this course?
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="modules"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Number of Modules *</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min="1"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormDescription>
                        How many modules or sections does the course contain?
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Price (₹) *</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min="0"
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value))}
                        />
                      </FormControl>
                      <FormDescription>
                        Regular price of the course in INR.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="discountPrice"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Discount Price (₹)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min="0"
                          placeholder="Leave empty for no discount"
                          value={field.value === null ? "" : field.value}
                          onChange={(e) => {
                            const value = e.target.value;
                            field.onChange(value === "" ? null : parseFloat(value));
                          }}
                        />
                      </FormControl>
                      <FormDescription>
                        Optional: special or discounted price.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="imageUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Course Image URL *</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="https://example.com/image.jpg"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      URL to an image that represents your course.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="categories"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Categories *</FormLabel>
                    <FormControl>
                      <MultiSelect
                        placeholder="Select categories"
                        selected={field.value}
                        options={availableCategories.map(cat => ({ label: cat, value: cat }))}
                        onChange={(values) => field.onChange(values)}
                      />
                    </FormControl>
                    <FormDescription>
                      Select categories that best describe your course.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="popular"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 p-4 border rounded-md">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Mark as Popular</FormLabel>
                        <FormDescription>
                          Popular courses are highlighted on the homepage.
                        </FormDescription>
                      </div>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="isLive"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 p-4 border rounded-md">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Mark as Live</FormLabel>
                        <FormDescription>
                          Live courses are available for enrollment.
                        </FormDescription>
                      </div>
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate("/teacher/courses")}
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                <X className="h-4 w-4 mr-2" />
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {(createMutation.isPending || updateMutation.isPending) ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Save className="h-4 w-4 mr-2" />
                )}
                {isEditing ? "Update Course" : "Create Course"}
              </Button>
            </CardFooter>
          </Card>
        </form>
      </Form>
    </TeacherLayout>
  );
}