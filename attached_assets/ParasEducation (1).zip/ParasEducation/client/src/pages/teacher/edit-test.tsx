import { TeacherLayout } from "@/components/teacher/TeacherLayout";
import TestCreator from "@/components/teacher/TestCreator";
import { useRolePermissions } from "@/hooks/use-role-permissions";
import { useEffect } from "react";
import { useLocation, useParams } from "wouter";

export default function TeacherEditTestPage() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { isTeacher } = useRolePermissions();
  
  // Redirect if not a teacher
  useEffect(() => {
    if (!isTeacher) {
      navigate("/login");
    }
  }, [isTeacher, navigate]);
  
  if (!isTeacher) {
    return null;
  }

  return (
    <TeacherLayout title="Edit Test">
      <TestCreator />
    </TeacherLayout>
  );
}