import { TeacherLayout } from "@/components/teacher/TeacherLayout";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, CheckCircle, AlertCircle } from "lucide-react";
import { Course, TestSeries } from "@/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function TeacherDashboard() {
  const { data: myCourses, isLoading: coursesLoading } = useQuery<Course[]>({
    queryKey: ["/api/teacher/my-courses"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  const { data: myTestSeries, isLoading: testSeriesLoading } = useQuery<TestSeries[]>({
    queryKey: ["/api/teacher/my-test-series"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  const isLoading = coursesLoading || testSeriesLoading;

  if (isLoading) {
    return (
      <TeacherLayout title="Dashboard">
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </TeacherLayout>
    );
  }

  return (
    <TeacherLayout title="Teacher Dashboard">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">My Courses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{myCourses?.length || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">My Test Series</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{myTestSeries?.length || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Published Courses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {myCourses?.filter(course => course.isPublished).length || 0}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Published Test Series</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {myTestSeries?.filter(series => series.isPublished).length || 0}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">My Recent Courses</h2>
          <Link href="/teacher/courses">
            <Button variant="ghost">View All</Button>
          </Link>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {myCourses && myCourses.length > 0 ? (
            myCourses
              .slice(0, 3)
              .map((course) => (
                <Card key={course.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{course.title}</CardTitle>
                      <Badge variant={course.isPublished ? "success" : "secondary"}>
                        {course.isPublished ? "Published" : "Draft"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                      {course.description}
                    </p>
                    <div className="flex justify-between text-sm mt-4">
                      <span>₹{course.discountPrice || course.price}</span>
                      <span>{course.duration}</span>
                    </div>
                    <div className="mt-4">
                      <Link href={`/teacher/courses/${course.id}`}>
                        <Button variant="outline" size="sm" className="w-full">
                          Edit Course
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))
          ) : (
            <div className="col-span-3 py-8 text-center text-muted-foreground">
              No courses available. <Link href="/teacher/courses/create"><span className="text-primary hover:underline">Create your first course</span></Link>
            </div>
          )}
        </div>
      </div>

      <div className="mt-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">My Recent Test Series</h2>
          <Link href="/teacher/test-series">
            <Button variant="ghost">View All</Button>
          </Link>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {myTestSeries && myTestSeries.length > 0 ? (
            myTestSeries
              .slice(0, 3)
              .map((series) => (
                <Card key={series.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{series.title}</CardTitle>
                      <Badge variant={series.isPublished ? "success" : "secondary"}>
                        {series.isPublished ? "Published" : "Draft"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                      {series.description}
                    </p>
                    <div className="flex justify-between text-sm mt-4">
                      <span>₹{series.price}</span>
                      <span>Tests: {series.testCount}</span>
                    </div>
                    <div className="mt-4">
                      <Link href={`/teacher/test-series/${series.id}`}>
                        <Button variant="outline" size="sm" className="w-full">
                          Edit Test Series
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))
          ) : (
            <div className="col-span-3 py-8 text-center text-muted-foreground">
              No test series available. <Link href="/teacher/test-series/create"><span className="text-primary hover:underline">Create your first test series</span></Link>
            </div>
          )}
        </div>
      </div>

      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Link href="/teacher/courses/create">
            <Button variant="outline" className="w-full h-full min-h-[100px] flex flex-col gap-2">
              <CheckCircle className="h-8 w-8" />
              <span>Create New Course</span>
            </Button>
          </Link>
          <Link href="/teacher/test-series/create">
            <Button variant="outline" className="w-full h-full min-h-[100px] flex flex-col gap-2">
              <AlertCircle className="h-8 w-8" />
              <span>Create New Test Series</span>
            </Button>
          </Link>
          <Link href="/teacher/profile">
            <Button variant="outline" className="w-full h-full min-h-[100px] flex flex-col gap-2">
              <AlertCircle className="h-8 w-8" />
              <span>Update Profile</span>
            </Button>
          </Link>
          <Link href="/teacher/help">
            <Button variant="outline" className="w-full h-full min-h-[100px] flex flex-col gap-2">
              <AlertCircle className="h-8 w-8" />
              <span>Get Help</span>
            </Button>
          </Link>
        </div>
      </div>
    </TeacherLayout>
  );
}