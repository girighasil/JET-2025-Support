import { z } from "zod";

// Basic user types
export interface User {
  id: number;
  username: string;
  fullName: string;
  email: string;
  role: "admin" | "teacher" | "user";
  createdAt: string;
}

// Course types
export interface Course {
  id: number;
  title: string;
  description: string;
  duration: string;
  modules: number;
  price: number;
  discountPrice?: number;
  imageUrl: string;
  categories: string[];
  popular: boolean;
  isLive: boolean;
  creatorId?: number;
  createdByName?: string; // Name of the teacher who created it
  isPublished: boolean;
  createdAt: string;
}

export const courseSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  duration: z.string().min(1, "Duration is required"),
  modules: z.coerce.number().min(1, "At least 1 module is required"),
  price: z.coerce.number().min(0, "Price must be 0 or greater"),
  discountPrice: z.coerce.number().min(0, "Discount price must be 0 or greater").optional(),
  imageUrl: z.string().url("Must be a valid URL"),
  categories: z.array(z.string()),
  popular: z.boolean().default(false),
  isLive: z.boolean().default(true),
  isPublished: z.boolean().default(false),
});

export type CourseFormValues = z.infer<typeof courseSchema>;

// Test Series types
export interface TestSeries {
  id: number;
  title: string;
  description: string;
  category: string;
  testCount: number;
  price: number;
  features: string[];
  creatorId?: number;
  createdByName?: string; // Name of teacher who created it
  isPublished: boolean;
  createdAt: string;
}

export const testSeriesSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  category: z.string().min(1, "Category is required"),
  testCount: z.coerce.number().min(1, "At least 1 test is required"),
  price: z.coerce.number().min(0, "Price must be 0 or greater"),
  features: z.array(z.string()).min(1, "At least one feature is required"),
  isPublished: z.boolean().default(false),
});

export type TestSeriesFormValues = z.infer<typeof testSeriesSchema>;

// Test types
export interface Test {
  id: number;
  title: string;
  description: string;
  testSeriesId?: number;
  duration: number; // in minutes
  totalMarks: number;
  passingMarks: number;
  negativeMarking: number;
  instructions?: string;
  fileUrl?: string;
  isActive: boolean;
  createdAt: string;
}

// Question types
export interface Question {
  id: number;
  testId: number;
  questionText: string;
  marks: number;
  questionType: "mcq" | "multi-select" | "truefalse" | "fillblank" | "subjective";
  imageUrl?: string;
  options?: Option[];
  explanation?: Explanation;
  createdAt: string;
}

export interface Option {
  id: number;
  questionId: number;
  optionText: string;
  isCorrect: boolean;
  createdAt: string;
}

export interface Explanation {
  id: number;
  questionId: number;
  explanationText: string;
  imageUrl?: string;
  createdAt: string;
}

// Testimonial types
export interface Testimonial {
  id: number;
  name: string;
  testimonial: string;
  rating: number;
  examName?: string;
  rank?: string;
  imageUrl?: string;
  createdAt: string;
}

// FAQ types
export interface FAQ {
  id: number;
  question: string;
  answer: string;
  order: number;
  createdAt: string;
}

// Contact types
export interface Contact {
  id: number;
  name: string;
  email?: string;
  phone: string;
  subject: string;
  message: string;
  createdAt: string;
}

// Doubt Session types
export interface DoubtSession {
  id: number;
  subject: string;
  topic: string;
  scheduledDate: string;
  duration: number;
  description: string;
  userId?: number;
  teacherName?: string;
  imageUrl?: string;
  name: string;
  email: string;
  phone?: string;
  isApproved: boolean;
  status: "pending" | "approved" | "rejected" | "completed";
  createdAt: string;
}

export interface SiteConfig {
  key: string;
  value: unknown;
  updatedAt: string;
}

export interface TestAttempt {
  id: number;
  userId: number;
  testId: number;
  startTime: string;
  endTime?: string;
  score?: number;
  totalMarks: number;
  isCompleted: boolean;
  timeTaken?: number;
  correctAnswers?: number;
  incorrectAnswers?: number;
  unanswered?: number;
  percentage?: number;
  createdAt: string;
}

export interface UserAnswer {
  id: number;
  testAttemptId: number;
  questionId: number;
  answer: string;
  isCorrect?: boolean;
  marksObtained?: number;
  createdAt: string;
}