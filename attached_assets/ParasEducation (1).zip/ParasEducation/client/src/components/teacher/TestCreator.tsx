import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest, getQueryFn } from "@/lib/queryClient";
import {
  Loader2,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
  Form,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useRoleBasedApiPrefix } from "@/hooks/use-role-based-api-prefix";

// Form schemas for different question types
const questionOption = z.object({
  id: z.number().optional(),
  optionText: z.string().min(1, "Option text is required"),
  isCorrect: z.boolean().default(false),
});

const mcqQuestionSchema = z.object({
  id: z.number().optional(),
  questionType: z.literal("mcq"),
  questionText: z.string().min(1, "Question text is required"),
  options: z.array(questionOption).min(2, "At least 2 options are required"),
  explanation: z.string().optional(),
  marks: z.number().min(1, "Marks must be at least 1"),
});

const trueFalseQuestionSchema = z.object({
  id: z.number().optional(),
  questionType: z.literal("truefalse"),
  questionText: z.string().min(1, "Question text is required"),
  correctAnswer: z.boolean(),
  explanation: z.string().optional(),
  marks: z.number().min(1, "Marks must be at least 1"),
});

const fillBlankQuestionSchema = z.object({
  id: z.number().optional(),
  questionType: z.literal("fillblank"),
  questionText: z.string().min(1, "Question text is required"),
  correctAnswer: z.string().min(1, "Correct answer is required"),
  explanation: z.string().optional(),
  marks: z.number().min(1, "Marks must be at least 1"),
});

const subjectiveQuestionSchema = z.object({
  id: z.number().optional(),
  questionType: z.literal("subjective"),
  questionText: z.string().min(1, "Question text is required"),
  modelAnswer: z.string().min(1, "Model answer is required"),
  explanation: z.string().optional(),
  marks: z.number().min(1, "Marks must be at least 1"),
});

const questionSchema = z.discriminatedUnion("questionType", [
  mcqQuestionSchema,
  trueFalseQuestionSchema,
  fillBlankQuestionSchema,
  subjectiveQuestionSchema,
]);

// Test form schema
const testFormSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(1, "Description is required"),
  testSeriesId: z.number({ required_error: "Test series is required" }),
  duration: z.number().min(5, "Duration must be at least 5 minutes"),
  totalMarks: z.number().min(1, "Total marks must be at least 1"),
  passingMarks: z.number().min(1, "Passing marks must be at least 1"),
  negativeMarking: z.number().min(0, "Negative marking cannot be negative"),
  instructions: z.string().optional(),
  isActive: z.boolean().default(true),
});

type TestFormValues = z.infer<typeof testFormSchema>;
type QuestionType = "mcq" | "truefalse" | "fillblank" | "subjective";

// Define test data and question types
interface TestData {
  id: number;
  title: string;
  description: string;
  testSeriesId: number;
  duration: number;
  totalMarks: number;
  passingMarks: number;
  negativeMarking: number;
  instructions?: string;
  isActive: boolean;
}

interface TestSeries {
  id: number;
  title: string;
  description: string;
}

export default function TestCreator() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const apiPrefix = useRoleBasedApiPrefix();
  
  const [activeTab, setActiveTab] = useState<string>("details");
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionType, setCurrentQuestionType] = useState<QuestionType>("mcq");
  const [isEditingQuestion, setIsEditingQuestion] = useState(false);
  const [editingQuestionIndex, setEditingQuestionIndex] = useState<number | null>(null);
  const [isPreviewDialogOpen, setIsPreviewDialogOpen] = useState(false);
  const [previewQuestion, setPreviewQuestion] = useState<Question | null>(null);

  const isEditing = Boolean(id);
  const testId = id ? parseInt(id) : undefined;

  // MCQ question form
  const mcqForm = useForm<z.infer<typeof mcqQuestionSchema>>({
    resolver: zodResolver(mcqQuestionSchema),
    defaultValues: {
      questionType: "mcq" as const,
      questionText: "",
      options: [
        { optionText: "", isCorrect: false },
        { optionText: "", isCorrect: false },
        { optionText: "", isCorrect: false },
        { optionText: "", isCorrect: false },
      ],
      explanation: "",
      marks: 1,
    },
  });

  const {
    fields: mcqOptionsFields,
    append: mcqAppendOption,
    remove: mcqRemoveOption,
  } = useFieldArray({
    control: mcqForm.control,
    name: "options",
  });

  // True/False question form
  const trueFalseForm = useForm<z.infer<typeof trueFalseQuestionSchema>>({
    resolver: zodResolver(trueFalseQuestionSchema),
    defaultValues: {
      questionType: "truefalse" as const,
      questionText: "",
      correctAnswer: true,
      explanation: "",
      marks: 1,
    },
  });

  // Fill in the blank question form
  const fillBlankForm = useForm<z.infer<typeof fillBlankQuestionSchema>>({
    resolver: zodResolver(fillBlankQuestionSchema),
    defaultValues: {
      questionType: "fillblank" as const,
      questionText: "",
      correctAnswer: "",
      explanation: "",
      marks: 1,
    },
  });

  // Subjective question form
  const subjectiveForm = useForm<z.infer<typeof subjectiveQuestionSchema>>({
    resolver: zodResolver(subjectiveQuestionSchema),
    defaultValues: {
      questionType: "subjective" as const,
      questionText: "",
      modelAnswer: "",
      explanation: "",
      marks: 1,
    },
  });

  // Test form
  const testForm = useForm<TestFormValues>({
    resolver: zodResolver(testFormSchema),
    defaultValues: {
      title: "",
      description: "",
      testSeriesId: 0,
      duration: 60,
      totalMarks: 100,
      passingMarks: 40,
      negativeMarking: 0.25,
      instructions: "",
      isActive: true,
    },
  });

  // Fetch test series for dropdown
  const { data: testSeries, isLoading: loadingTestSeries } = useQuery<TestSeries[]>({
    queryKey: [`${apiPrefix}/my-test-series`],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Fetch test data if editing
  const { data: testData, isLoading: loadingTest } = useQuery<TestData>({
    queryKey: [`${apiPrefix}/tests`, testId],
    enabled: isEditing,
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Update form when test data is loaded
  useEffect(() => {
    if (testData) {
      testForm.reset({
        title: testData.title,
        description: testData.description,
        testSeriesId: testData.testSeriesId,
        duration: testData.duration,
        totalMarks: testData.totalMarks,
        passingMarks: testData.passingMarks,
        negativeMarking: testData.negativeMarking,
        instructions: testData.instructions || "",
        isActive: testData.isActive,
      });
    }
  }, [testData, testForm]);

  // Define Question interface
  interface Question {
    id?: number;
    questionType: QuestionType;
    questionText: string;
    marks: number;
    explanation?: string;
    testId?: number;
    options?: Array<{id?: number; optionText: string; isCorrect: boolean}>;
    correctAnswer?: boolean | string;
    modelAnswer?: string;
  }

  // Fetch questions if editing
  const { data: questionData, isLoading: loadingQuestions } = useQuery<Question[]>({
    queryKey: [`${apiPrefix}/tests`, testId, "questions"],
    enabled: isEditing,
    queryFn: getQueryFn({ on401: "throw" }),
  });
  
  // Update questions when question data is loaded
  useEffect(() => {
    if (questionData && Array.isArray(questionData)) {
      setQuestions(questionData);
    }
  }, [questionData]);

  // Create test mutation
  const createTestMutation = useMutation({
    mutationFn: async (data: TestFormValues & { questions: Question[] }) => {
      const testResponse = await apiRequest("POST", `${apiPrefix}/tests`, {
        title: data.title,
        description: data.description,
        testSeriesId: data.testSeriesId,
        duration: data.duration,
        totalMarks: data.totalMarks,
        passingMarks: data.passingMarks,
        negativeMarking: data.negativeMarking,
        instructions: data.instructions,
        isActive: data.isActive,
      });
      
      const test = await testResponse.json();

      // Add questions if they exist
      if (data.questions.length > 0) {
        for (const question of data.questions) {
          await apiRequest("POST", `${apiPrefix}/questions`, {
            ...question,
            testId: test.id,
          });
        }
      }

      return test;
    },
    onSuccess: () => {
      toast({
        title: "Test created",
        description: "Test has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`${apiPrefix}/tests`] });
      navigate("/teacher/tests");
    },
    onError: (error: any) => {
      toast({
        title: "Failed to create test",
        description: error.message || "An error occurred while creating the test.",
        variant: "destructive",
      });
    },
  });

  // Update test mutation
  const updateTestMutation = useMutation({
    mutationFn: async (data: TestFormValues & { questions: Question[] }) => {
      await apiRequest("PUT", `${apiPrefix}/tests/${id}`, {
        title: data.title,
        description: data.description,
        testSeriesId: data.testSeriesId,
        duration: data.duration,
        totalMarks: data.totalMarks,
        passingMarks: data.passingMarks,
        negativeMarking: data.negativeMarking,
        instructions: data.instructions,
        isActive: data.isActive,
      });

      // Process questions
      for (const question of data.questions) {
        if (question.id) {
          // Update existing question
          await apiRequest("PUT", `${apiPrefix}/questions/${question.id}`, {
            ...question,
            testId,
          });
        } else {
          // Create new question
          await apiRequest("POST", `${apiPrefix}/questions`, {
            ...question,
            testId,
          });
        }
      }

      return true;
    },
    onSuccess: () => {
      toast({
        title: "Test updated",
        description: "Test has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`${apiPrefix}/tests`, testId] });
      queryClient.invalidateQueries({ queryKey: [`${apiPrefix}/tests`, testId, "questions"] });
      navigate("/teacher/tests");
    },
    onError: (error: any) => {
      toast({
        title: "Failed to update test",
        description: error.message || "An error occurred while updating the test.",
        variant: "destructive",
      });
    },
  });

  // Handle test form submission
  const onSubmitTest = (data: TestFormValues) => {
    if (questions.length === 0) {
      toast({
        title: "No questions added",
        description: "Please add at least one question to the test.",
        variant: "destructive",
      });
      return;
    }

    const totalCalculatedMarks = questions.reduce(
      (total, q) => total + (q.marks || 1),
      0
    );
    
    // Validate passing marks
    if (data.passingMarks > totalCalculatedMarks) {
      toast({
        title: "Invalid passing marks",
        description: "Passing marks cannot be greater than total marks.",
        variant: "destructive",
      });
      return;
    }

    const finalData = {
      ...data,
      totalMarks: totalCalculatedMarks,
      questions,
    };

    if (isEditing) {
      updateTestMutation.mutate(finalData);
    } else {
      createTestMutation.mutate(finalData);
    }
  };

  // Handle MCQ form submission
  const onSubmitMcqQuestion = (data: z.infer<typeof mcqQuestionSchema>) => {
    // Ensure there's at least one correct answer
    const hasCorrectOption = data.options.some((option) => option.isCorrect);

    if (!hasCorrectOption) {
      toast({
        title: "Invalid question",
        description: "Please mark at least one option as correct.",
        variant: "destructive",
      });
      return;
    }

    if (isEditingQuestion && editingQuestionIndex !== null) {
      // Update existing question
      const updatedQuestions = [...questions];
      updatedQuestions[editingQuestionIndex] = data;
      setQuestions(updatedQuestions);
      setIsEditingQuestion(false);
      setEditingQuestionIndex(null);
    } else {
      // Add new question
      setQuestions([...questions, data]);
    }

    // Reset the form
    mcqForm.reset({
      questionType: "mcq",
      questionText: "",
      options: [
        { optionText: "", isCorrect: false },
        { optionText: "", isCorrect: false },
        { optionText: "", isCorrect: false },
        { optionText: "", isCorrect: false },
      ],
      explanation: "",
      marks: 1,
    });

    toast({
      title: isEditingQuestion ? "Question updated" : "Question added",
      description: isEditingQuestion
        ? "The question has been updated successfully."
        : "The question has been added to the test.",
    });
  };

  // Handle True/False form submission
  const onSubmitTrueFalseQuestion = (data: z.infer<typeof trueFalseQuestionSchema>) => {
    if (isEditingQuestion && editingQuestionIndex !== null) {
      // Update existing question
      const updatedQuestions = [...questions];
      updatedQuestions[editingQuestionIndex] = data;
      setQuestions(updatedQuestions);
      setIsEditingQuestion(false);
      setEditingQuestionIndex(null);
    } else {
      // Add new question
      setQuestions([...questions, data]);
    }

    // Reset the form
    trueFalseForm.reset({
      questionType: "truefalse",
      questionText: "",
      correctAnswer: true,
      explanation: "",
      marks: 1,
    });

    toast({
      title: isEditingQuestion ? "Question updated" : "Question added",
      description: isEditingQuestion
        ? "The question has been updated successfully."
        : "The question has been added to the test.",
    });
  };

  // Handle Fill in the Blank form submission
  const onSubmitFillBlankQuestion = (data: z.infer<typeof fillBlankQuestionSchema>) => {
    if (isEditingQuestion && editingQuestionIndex !== null) {
      // Update existing question
      const updatedQuestions = [...questions];
      updatedQuestions[editingQuestionIndex] = data;
      setQuestions(updatedQuestions);
      setIsEditingQuestion(false);
      setEditingQuestionIndex(null);
    } else {
      // Add new question
      setQuestions([...questions, data]);
    }

    // Reset the form
    fillBlankForm.reset({
      questionType: "fillblank",
      questionText: "",
      correctAnswer: "",
      explanation: "",
      marks: 1,
    });

    toast({
      title: isEditingQuestion ? "Question updated" : "Question added",
      description: isEditingQuestion
        ? "The question has been updated successfully."
        : "The question has been added to the test.",
    });
  };

  // Handle Subjective form submission
  const onSubmitSubjectiveQuestion = (data: z.infer<typeof subjectiveQuestionSchema>) => {
    if (isEditingQuestion && editingQuestionIndex !== null) {
      // Update existing question
      const updatedQuestions = [...questions];
      updatedQuestions[editingQuestionIndex] = data;
      setQuestions(updatedQuestions);
      setIsEditingQuestion(false);
      setEditingQuestionIndex(null);
    } else {
      // Add new question
      setQuestions([...questions, data]);
    }

    // Reset the form
    subjectiveForm.reset({
      questionType: "subjective",
      questionText: "",
      modelAnswer: "",
      explanation: "",
      marks: 1,
    });

    toast({
      title: isEditingQuestion ? "Question updated" : "Question added",
      description: isEditingQuestion
        ? "The question has been updated successfully."
        : "The question has been added to the test.",
    });
  };

  // Edit question
  const handleEditQuestion = (index: number) => {
    const question = questions[index];
    setIsEditingQuestion(true);
    setEditingQuestionIndex(index);
    setCurrentQuestionType(question.questionType);

    // Populate the appropriate form based on question type
    switch (question.questionType) {
      case "mcq":
        // Type assertion to ensure proper type compatibility
        mcqForm.reset({
          questionType: "mcq",
          questionText: question.questionText,
          options: question.options || [],
          marks: question.marks,
          explanation: question.explanation
        });
        break;
      case "truefalse":
        // Type assertion to ensure proper type compatibility
        trueFalseForm.reset({
          questionType: "truefalse",
          questionText: question.questionText,
          correctAnswer: question.correctAnswer as boolean,
          marks: question.marks,
          explanation: question.explanation
        });
        break;
      case "fillblank":
        // Type assertion to ensure proper type compatibility
        fillBlankForm.reset({
          questionType: "fillblank",
          questionText: question.questionText,
          correctAnswer: question.correctAnswer as string,
          marks: question.marks,
          explanation: question.explanation
        });
        break;
      case "subjective":
        // Type assertion to ensure proper type compatibility
        subjectiveForm.reset({
          questionType: "subjective",
          questionText: question.questionText,
          modelAnswer: question.modelAnswer || "",
          marks: question.marks,
          explanation: question.explanation
        });
        break;
    }
  };

  // Delete question
  const handleDeleteQuestion = (index: number) => {
    const updatedQuestions = [...questions];
    updatedQuestions.splice(index, 1);
    setQuestions(updatedQuestions);
    toast({
      title: "Question deleted",
      description: "The question has been removed from the test.",
    });
  };

  // Preview question
  const handlePreviewQuestion = (index: number) => {
    setPreviewQuestion(questions[index]);
    setIsPreviewDialogOpen(true);
  };

  if (loadingTest || loadingQuestions) {
    return (
      <div className="flex justify-center items-center h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">{isEditing ? "Edit Test" : "Create New Test"}</h2>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="details">Test Details</TabsTrigger>
          <TabsTrigger value="questions">Questions ({questions.length})</TabsTrigger>
          <TabsTrigger value="preview">Preview</TabsTrigger>
        </TabsList>

        {/* Test Details Tab */}
        <TabsContent value="details" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Test Information</CardTitle>
              <CardDescription>
                Enter the basic details of your test.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...testForm}>
                <form className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={testForm.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Test Title</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter test title" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={testForm.control}
                      name="testSeriesId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Test Series</FormLabel>
                          <Select
                            value={field.value ? field.value.toString() : undefined}
                            onValueChange={(value) => field.onChange(parseInt(value))}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a test series" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {Array.isArray(testSeries) && testSeries.map((series: any) => (
                                <SelectItem key={series.id} value={series.id.toString()}>
                                  {series.title}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={testForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Enter test description"
                            className="min-h-24"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={testForm.control}
                      name="duration"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Duration (minutes)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min={5}
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={testForm.control}
                      name="passingMarks"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Passing Marks</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min={1}
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={testForm.control}
                      name="negativeMarking"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Negative Marking Factor</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.01"
                              min={0}
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormDescription>
                            e.g., 0.25 means 1/4th of the marks will be deducted for wrong answers
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={testForm.control}
                    name="instructions"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Instructions (Optional)</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Enter instructions for students taking the test"
                            className="min-h-24"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={testForm.control}
                    name="isActive"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Active</FormLabel>
                          <FormDescription>
                            If unchecked, the test will be saved as a draft and not visible to students
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                </form>
              </Form>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => navigate("/teacher/tests")}>
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  if (testForm.formState.isValid) {
                    setActiveTab("questions");
                  } else {
                    testForm.handleSubmit(() => setActiveTab("questions"))();
                  }
                }}
              >
                Continue to Questions
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Questions Tab */}
        <TabsContent value="questions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Add Questions</CardTitle>
              <CardDescription>
                Create questions for your test. You must add at least one question.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <Label>Question Type</Label>
                <Select
                  value={currentQuestionType}
                  onValueChange={(value) => setCurrentQuestionType(value as QuestionType)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mcq">Multiple Choice</SelectItem>
                    <SelectItem value="truefalse">True/False</SelectItem>
                    <SelectItem value="fillblank">Fill in the Blank</SelectItem>
                    <SelectItem value="subjective">Subjective</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Question Forms */}
              <div className="mt-6 space-y-4">
                {currentQuestionType === "mcq" && (
                  <Form {...mcqForm}>
                    <form
                      onSubmit={mcqForm.handleSubmit(onSubmitMcqQuestion)}
                      className="space-y-4"
                    >
                      <FormField
                        control={mcqForm.control}
                        name="questionText"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Question</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Enter your question"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div>
                        <Label className="mb-2 block">Options</Label>
                        <div className="space-y-2">
                          {mcqOptionsFields.map((field, index) => (
                            <div key={field.id} className="flex items-center gap-2">
                              <FormField
                                control={mcqForm.control}
                                name={`options.${index}.isCorrect`}
                                render={({ field }) => (
                                  <FormItem className="flex items-center space-x-2 space-y-0">
                                    <FormControl>
                                      <Checkbox
                                        checked={field.value}
                                        onCheckedChange={field.onChange}
                                      />
                                    </FormControl>
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={mcqForm.control}
                                name={`options.${index}.optionText`}
                                render={({ field }) => (
                                  <FormItem className="flex-1">
                                    <FormControl>
                                      <Input
                                        placeholder={`Option ${index + 1}`}
                                        {...field}
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              {mcqOptionsFields.length > 2 && (
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => mcqRemoveOption(index)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              )}
                            </div>
                          ))}
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          className="mt-2"
                          onClick={() => mcqAppendOption({ optionText: "", isCorrect: false })}
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Add Option
                        </Button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={mcqForm.control}
                          name="marks"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Marks</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  min={1}
                                  {...field}
                                  onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={mcqForm.control}
                        name="explanation"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Explanation (Optional)</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Enter explanation for the correct answer"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="flex justify-end">
                        <Button type="submit">
                          {isEditingQuestion ? "Update Question" : "Add Question"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                )}

                {currentQuestionType === "truefalse" && (
                  <Form {...trueFalseForm}>
                    <form
                      onSubmit={trueFalseForm.handleSubmit(onSubmitTrueFalseQuestion)}
                      className="space-y-4"
                    >
                      <FormField
                        control={trueFalseForm.control}
                        name="questionText"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Question</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Enter your question"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={trueFalseForm.control}
                        name="correctAnswer"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Correct Answer</FormLabel>
                            <FormControl>
                              <RadioGroup
                                onValueChange={(value) => field.onChange(value === "true")}
                                value={field.value ? "true" : "false"}
                                className="flex space-x-4"
                              >
                                <div className="flex items-center space-x-2">
                                  <RadioGroupItem value="true" id="true" />
                                  <Label htmlFor="true">True</Label>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <RadioGroupItem value="false" id="false" />
                                  <Label htmlFor="false">False</Label>
                                </div>
                              </RadioGroup>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={trueFalseForm.control}
                          name="marks"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Marks</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  min={1}
                                  {...field}
                                  onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={trueFalseForm.control}
                        name="explanation"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Explanation (Optional)</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Enter explanation for the correct answer"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="flex justify-end">
                        <Button type="submit">
                          {isEditingQuestion ? "Update Question" : "Add Question"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                )}

                {currentQuestionType === "fillblank" && (
                  <Form {...fillBlankForm}>
                    <form
                      onSubmit={fillBlankForm.handleSubmit(onSubmitFillBlankQuestion)}
                      className="space-y-4"
                    >
                      <FormField
                        control={fillBlankForm.control}
                        name="questionText"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Question</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Use underscores or [blank] to indicate where the blank should be, e.g. 'The capital of France is ____'"
                                {...field}
                              />
                            </FormControl>
                            <FormDescription>
                              Use underscores or [blank] to indicate where the blank should be, e.g. "The capital of France is ____"
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={fillBlankForm.control}
                        name="correctAnswer"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Correct Answer</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Enter the correct answer"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={fillBlankForm.control}
                          name="marks"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Marks</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  min={1}
                                  {...field}
                                  onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={fillBlankForm.control}
                        name="explanation"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Explanation (Optional)</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Enter explanation for the correct answer"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="flex justify-end">
                        <Button type="submit">
                          {isEditingQuestion ? "Update Question" : "Add Question"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                )}

                {currentQuestionType === "subjective" && (
                  <Form {...subjectiveForm}>
                    <form
                      onSubmit={subjectiveForm.handleSubmit(onSubmitSubjectiveQuestion)}
                      className="space-y-4"
                    >
                      <FormField
                        control={subjectiveForm.control}
                        name="questionText"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Question</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Enter your question"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={subjectiveForm.control}
                        name="modelAnswer"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Model Answer</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Enter the model answer"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={subjectiveForm.control}
                          name="marks"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Marks</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  min={1}
                                  {...field}
                                  onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={subjectiveForm.control}
                        name="explanation"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Explanation (Optional)</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Enter explanation or additional notes"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="flex justify-end">
                        <Button type="submit">
                          {isEditingQuestion ? "Update Question" : "Add Question"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                )}
              </div>

              {/* List of Added Questions */}
              <div className="mt-8">
                <h3 className="text-lg font-medium mb-2">Added Questions ({questions.length})</h3>
                {questions.length === 0 ? (
                  <div className="border rounded-md p-4 text-center text-muted-foreground">
                    No questions added yet. Use the form above to add questions.
                  </div>
                ) : (
                  <div className="space-y-4">
                    {questions.map((question, index) => (
                      <Card key={index}>
                        <CardHeader className="py-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline">
                                {question.questionType === "mcq"
                                  ? "Multiple Choice"
                                  : question.questionType === "truefalse"
                                  ? "True/False"
                                  : question.questionType === "fillblank"
                                  ? "Fill in the Blank"
                                  : "Subjective"}
                              </Badge>
                              <Badge>{question.marks} marks</Badge>
                            </div>
                            <div className="flex gap-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleEditQuestion(index)}
                              >
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="24"
                                  height="24"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  className="h-4 w-4"
                                >
                                  <path d="M12 20h9"></path>
                                  <path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"></path>
                                </svg>
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDeleteQuestion(index)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="py-2">
                          <p className="whitespace-pre-wrap">{question.questionText}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setActiveTab("details")}>
                Back to Details
              </Button>
              <Button
                onClick={() => {
                  if (questions.length > 0) {
                    setActiveTab("preview");
                  } else {
                    toast({
                      title: "No questions added",
                      description: "Please add at least one question before proceeding to preview.",
                      variant: "destructive",
                    });
                  }
                }}
              >
                Continue to Preview
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Preview Tab */}
        <TabsContent value="preview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Preview and Save</CardTitle>
              <CardDescription>
                Review your test details and questions before saving.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Test Details</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2">
                    <div>
                      <span className="font-medium">Title:</span>{" "}
                      {testForm.getValues("title")}
                    </div>
                    <div>
                      <span className="font-medium">Duration:</span>{" "}
                      {testForm.getValues("duration")} minutes
                    </div>
                    <div>
                      <span className="font-medium">Passing Marks:</span>{" "}
                      {testForm.getValues("passingMarks")}
                    </div>
                    <div>
                      <span className="font-medium">Total Questions:</span>{" "}
                      {questions.length}
                    </div>
                    <div>
                      <span className="font-medium">Total Marks:</span>{" "}
                      {questions.reduce((total, q) => total + (q.marks || 1), 0)}
                    </div>
                    <div>
                      <span className="font-medium">Negative Marking:</span>{" "}
                      {testForm.getValues("negativeMarking")}
                    </div>
                  </div>

                  {testForm.getValues("description") && (
                    <div className="mt-2">
                      <span className="font-medium">Description:</span>
                      <p className="mt-1 whitespace-pre-wrap">
                        {testForm.getValues("description")}
                      </p>
                    </div>
                  )}

                  {testForm.getValues("instructions") && (
                    <div className="mt-2">
                      <span className="font-medium">Instructions:</span>
                      <p className="mt-1 whitespace-pre-wrap">
                        {testForm.getValues("instructions")}
                      </p>
                    </div>
                  )}
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Questions ({questions.length})</h3>
                  <div className="space-y-4">
                    {questions.map((question, index) => (
                      <Card key={index}>
                        <CardHeader className="py-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline">Question {index + 1}</Badge>
                              <Badge>
                                {question.questionType === "mcq"
                                  ? "Multiple Choice"
                                  : question.questionType === "truefalse"
                                  ? "True/False"
                                  : question.questionType === "fillblank"
                                  ? "Fill in the Blank"
                                  : "Subjective"}
                              </Badge>
                              <Badge>{question.marks} marks</Badge>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="py-2">
                          <div className="space-y-2">
                            <p className="font-medium">Q. {question.questionText}</p>

                            {question.questionType === "mcq" && (
                              <div className="ml-4 space-y-1">
                                {question.options && question.options.map((option: any, optIndex: number) => (
                                  <div key={optIndex} className="flex items-start gap-2">
                                    <div
                                      className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-sm border ${
                                        option.isCorrect
                                          ? "bg-primary border-primary text-primary-foreground"
                                          : "border-primary"
                                      }`}
                                    >
                                      {option.isCorrect && <CheckCircle2 className="h-3 w-3" />}
                                    </div>
                                    <span>{option.optionText}</span>
                                  </div>
                                ))}
                              </div>
                            )}

                            {question.questionType === "truefalse" && (
                              <div className="ml-4 space-y-1">
                                <div className="flex items-start gap-2">
                                  <div
                                    className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border ${
                                      question.correctAnswer
                                        ? "bg-primary border-primary text-primary-foreground"
                                        : "border-primary"
                                    }`}
                                  >
                                    {question.correctAnswer && <CheckCircle2 className="h-3 w-3" />}
                                  </div>
                                  <span>True</span>
                                </div>
                                <div className="flex items-start gap-2">
                                  <div
                                    className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border ${
                                      !question.correctAnswer
                                        ? "bg-primary border-primary text-primary-foreground"
                                        : "border-primary"
                                    }`}
                                  >
                                    {!question.correctAnswer && <CheckCircle2 className="h-3 w-3" />}
                                  </div>
                                  <span>False</span>
                                </div>
                              </div>
                            )}

                            {question.questionType === "fillblank" && (
                              <div className="ml-4">
                                <p className="font-medium">
                                  Correct Answer: {question.correctAnswer}
                                </p>
                              </div>
                            )}

                            {question.questionType === "subjective" && (
                              <div className="ml-4">
                                <p className="font-medium">Model Answer:</p>
                                <p className="whitespace-pre-wrap">{question.modelAnswer}</p>
                              </div>
                            )}

                            {question.explanation && (
                              <div className="mt-2">
                                <p className="font-medium">Explanation:</p>
                                <p className="whitespace-pre-wrap">{question.explanation}</p>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setActiveTab("questions")}>
                Back to Questions
              </Button>
              <Button
                onClick={testForm.handleSubmit(onSubmitTest)}
                disabled={createTestMutation.isPending || updateTestMutation.isPending}
              >
                {createTestMutation.isPending || updateTestMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    {isEditing ? "Update Test" : "Save Test"}
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}