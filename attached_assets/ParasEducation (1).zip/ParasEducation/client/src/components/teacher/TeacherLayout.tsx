import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import {
  BookOpen,
  FileText,
  Home,
  LogOut,
  Settings,
  User,
  PlusCircle,
  HelpCircle,
  FileQuestion,
  Layers,
  BellRing,
  Clock,
  MessageCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface TeacherLayoutProps {
  children: ReactNode;
  title: string;
}

export function TeacherLayout({ children, title }: TeacherLayoutProps) {
  const [currentPath] = useLocation();
  const { user, logoutMutation } = useAuth();

  const isLinkActive = (path: string) => {
    if (path === "/teacher" && currentPath === "/teacher") {
      return true;
    }
    return currentPath !== "/teacher" && currentPath.startsWith(path);
  };

  const sidebarLinks = [
    { path: "/teacher", label: "Dashboard", icon: Home },
    { path: "/teacher/courses", label: "Courses", icon: BookOpen },
    { path: "/teacher/test-series", label: "Test Series", icon: FileText },
    { path: "/teacher/tests", label: "Tests", icon: FileQuestion },
    { path: "/teacher/lessons", label: "Lessons", icon: Layers },
    { path: "/teacher/doubt-sessions", label: "Doubt Sessions", icon: MessageCircle },
    { path: "/teacher/profile", label: "Profile", icon: User },
    { path: "/teacher/help", label: "Help & Support", icon: HelpCircle },
  ];

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 w-64 border-r border-border hidden md:flex flex-col">
        <div className="p-4 border-b border-border flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer">
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold">
                E
              </div>
              <span className="font-bold text-lg">EduTech</span>
            </div>
          </Link>
        </div>

        <nav className="flex-1 overflow-y-auto py-4 px-3">
          <ul className="space-y-1.5">
            {sidebarLinks.map((link) => (
              <li key={link.path}>
                <Link href={link.path}>
                  <div
                    className={cn(
                      "flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors hover:bg-muted",
                      isLinkActive(link.path) &&
                        "bg-secondary text-secondary-foreground font-medium"
                    )}
                  >
                    <link.icon className="h-4 w-4" />
                    {link.label}
                  </div>
                </Link>
              </li>
            ))}
          </ul>

          <div className="mt-6">
            <div className="px-3 py-2">
              <h3 className="text-xs font-medium text-muted-foreground">Quick Actions</h3>
            </div>
            <ul className="space-y-1.5">
              <li>
                <Link href="/teacher/courses/create">
                  <div className="flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors hover:bg-muted">
                    <PlusCircle className="h-4 w-4" />
                    Create Course
                  </div>
                </Link>
              </li>
              <li>
                <Link href="/teacher/test-series/create">
                  <div className="flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors hover:bg-muted">
                    <PlusCircle className="h-4 w-4" />
                    Create Test Series
                  </div>
                </Link>
              </li>
            </ul>
          </div>
        </nav>

        <div className="p-4 border-t border-border">
          <Button
            variant="outline"
            className="w-full justify-start text-left font-normal"
            onClick={handleLogout}
          >
            <LogOut className="mr-2 h-4 w-4" />
            Log Out
          </Button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 md:ml-64">
        {/* Header */}
        <header className="h-16 border-b border-border flex items-center justify-between px-4 sticky top-0 z-30 bg-background">
          <h1 className="text-xl font-semibold hidden md:block">{title}</h1>

          {/* Mobile menu button */}
          <button className="md:hidden p-2 rounded-md hover:bg-muted">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          </button>

          <div className="flex items-center gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon" className="rounded-full relative">
                  <BellRing className="h-4 w-4" />
                  <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full h-4 w-4 flex items-center justify-center">
                    3
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80">
                <DropdownMenuLabel>Notifications</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <div className="max-h-80 overflow-y-auto">
                  <div className="px-4 py-2 hover:bg-muted cursor-pointer">
                    <div className="flex items-start gap-3">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                        <Clock className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">New course approval</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Your course "Advanced Mathematics" has been approved and is now live.
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">2 hours ago</p>
                      </div>
                    </div>
                  </div>
                  <div className="px-4 py-2 hover:bg-muted cursor-pointer">
                    <div className="flex items-start gap-3">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                        <MessageCircle className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">New doubt session</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          A student has requested a doubt clearing session.
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">1 day ago</p>
                      </div>
                    </div>
                  </div>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="relative h-8 w-8 rounded-full flex items-center gap-2"
                >
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="" alt={user?.fullName} />
                    <AvatarFallback>
                      {user?.fullName
                        ? `${user.fullName.split(" ")[0][0]}${
                            user.fullName.split(" ")[1]?.[0] || ""
                          }`
                        : user?.username?.[0] || "U"}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user?.fullName}</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {user?.email}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/teacher/profile">
                    <div className="cursor-pointer flex items-center gap-2">
                      <User className="mr-2 h-4 w-4" />
                      <span>Profile</span>
                    </div>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/teacher/settings">
                    <div className="cursor-pointer flex items-center gap-2">
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </div>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="cursor-pointer">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Page content */}
        <main className="p-6">{children}</main>
      </div>
    </div>
  );
}