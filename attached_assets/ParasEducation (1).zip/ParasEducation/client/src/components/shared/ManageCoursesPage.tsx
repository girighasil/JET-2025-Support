import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getQueryFn, apiRequest } from "@/lib/queryClient";
import { Loader2, Plus, Pencil, Trash2, AlertTriangle, Eye, CheckCircle2 } from "lucide-react";
import { Course } from "@/types";
import { useLocation } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { useRolePermissions, useRoleBasedApiPrefix } from "@/hooks/use-role-permissions";

interface ManageCoursesPageProps {
  containerComponent: React.ComponentType<{ title: string; children: React.ReactNode }>;
}

export function ManageCoursesPage({ containerComponent: Container }: ManageCoursesPageProps) {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [courseToDelete, setCourseToDelete] = useState<Course | null>(null);
  
  // Get role-based permissions
  const { 
    canPublish, 
    canSetPricing, 
    canManageAllContent 
  } = useRolePermissions();
  
  // Get the appropriate API prefix based on user role
  const apiPrefix = useRoleBasedApiPrefix();
  
  // Courses endpoint is different for admin (all courses) vs teacher (my courses)
  const coursesEndpoint = canManageAllContent 
    ? `${apiPrefix}/courses` 
    : `${apiPrefix}/my-courses`;

  const { data: courses, isLoading } = useQuery<Course[]>({
    queryKey: [coursesEndpoint],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("DELETE", `${apiPrefix}/courses/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [coursesEndpoint] });
      toast({
        title: "Course deleted",
        description: "The course has been deleted successfully.",
      });
      setCourseToDelete(null);
    },
    onError: (error) => {
      console.error("Failed to delete course:", error);
      toast({
        title: "Failed to delete course",
        description: "An error occurred while deleting the course. Please try again.",
        variant: "destructive",
      });
    },
  });

  const publishMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("PUT", `${apiPrefix}/courses/${id}/publish`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [coursesEndpoint] });
      toast({
        title: "Course published",
        description: "The course has been published and is now available to students.",
      });
    },
    onError: (error) => {
      console.error("Failed to publish course:", error);
      toast({
        title: "Failed to publish course",
        description: "An error occurred while publishing the course. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDelete = (course: Course) => {
    setCourseToDelete(course);
  };

  const confirmDelete = () => {
    if (courseToDelete) {
      deleteMutation.mutate(courseToDelete.id);
    }
  };

  const handlePublish = (id: number) => {
    publishMutation.mutate(id);
  };

  if (isLoading) {
    return (
      <Container title="Manage Courses">
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Container>
    );
  }

  return (
    <Container title="Manage Courses">
      <div className="flex justify-between items-center mb-6">
        <div>
          <p className="text-muted-foreground mb-2">
            {canManageAllContent 
              ? "Manage all courses. Create, edit, publish, or delete courses as needed."
              : "Manage your courses. Create, edit, or delete courses as needed."}
          </p>
        </div>
        <Button onClick={() => navigate(`${canManageAllContent ? "/admin" : "/teacher"}/courses/create`)}>
          <Plus className="mr-2 h-4 w-4" /> Create Course
        </Button>
      </div>

      {courses && courses.length > 0 ? (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Course Name</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Duration</TableHead>
                {canManageAllContent && <TableHead>Created By</TableHead>}
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {courses.map((course) => (
                <TableRow key={course.id}>
                  <TableCell className="font-medium">{course.title}</TableCell>
                  <TableCell>
                    <Badge variant={course.isPublished ? "success" : "secondary"}>
                      {course.isPublished ? "Published" : "Draft"}
                    </Badge>
                  </TableCell>
                  <TableCell>₹{course.discountPrice || course.price}</TableCell>
                  <TableCell>{course.duration}</TableCell>
                  {canManageAllContent && <TableCell>{course.createdByName || "Unknown"}</TableCell>}
                  <TableCell className="text-right space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => navigate(`${canManageAllContent ? "/admin" : "/teacher"}/courses/edit/${course.id}`)}
                    >
                      <Pencil className="h-4 w-4" />
                      <span className="sr-only">Edit</span>
                    </Button>
                    
                    {/* View button for published courses */}
                    {course.isPublished && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => navigate(`/courses/${course.id}`)}
                      >
                        <Eye className="h-4 w-4" />
                        <span className="sr-only">View</span>
                      </Button>
                    )}
                    
                    {/* Publish button for admin only */}
                    {canPublish && !course.isPublished && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handlePublish(course.id)}
                        disabled={publishMutation.isPending}
                      >
                        <CheckCircle2 className="h-4 w-4 text-success" />
                        <span className="sr-only">Publish</span>
                      </Button>
                    )}
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(course)}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                      <span className="sr-only">Delete</span>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-12 border rounded-lg bg-muted/20">
          <div className="mb-4 p-3 rounded-full bg-primary/10">
            <AlertTriangle className="h-6 w-6 text-primary" />
          </div>
          <h3 className="text-xl font-medium mb-1">No courses found</h3>
          <p className="text-muted-foreground mb-4 text-center max-w-md">
            {canManageAllContent 
              ? "No courses have been created yet. Create your first course to get started."
              : "You haven't created any courses yet. Create your first course to get started."}
          </p>
          <Button onClick={() => navigate(`${canManageAllContent ? "/admin" : "/teacher"}/courses/create`)}>
            <Plus className="mr-2 h-4 w-4" /> Create Course
          </Button>
        </div>
      )}

      <AlertDialog open={!!courseToDelete} onOpenChange={(open) => !open && setCourseToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the course{" "}
              <strong>{courseToDelete?.title}</strong> and all associated data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Container>
  );
}