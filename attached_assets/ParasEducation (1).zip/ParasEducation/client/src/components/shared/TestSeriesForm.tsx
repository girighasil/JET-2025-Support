import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getQueryFn, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Loader2, Save, ArrowLeft, FileEdit, Image, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useRoleBasedApiPrefix } from "@/hooks/use-role-permissions";

const testSeriesSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  price: z.coerce.number().nonnegative("Price must be a non-negative number"),
  discountPrice: z.coerce.number().nonnegative("Discount price must be a non-negative number").optional(),
  duration: z.string().min(1, "Duration is required"),
  imageUrl: z.string().optional(),
  category: z.string().min(1, "Category is required"),
  level: z.string().min(1, "Level is required"),
  isPublished: z.boolean().optional()
});

type TestSeriesFormValues = z.infer<typeof testSeriesSchema>;

interface TestSeriesFormProps {
  containerComponent: React.ComponentType<{ title: string; children: React.ReactNode }>;
  testSeriesId?: number;
}

export function TestSeriesForm({ containerComponent: Container, testSeriesId }: TestSeriesFormProps) {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const apiPrefix = useRoleBasedApiPrefix();
  const isEditing = !!testSeriesId;
  
  const form = useForm<TestSeriesFormValues>({
    resolver: zodResolver(testSeriesSchema),
    defaultValues: {
      title: "",
      description: "",
      price: 0,
      discountPrice: 0,
      duration: "",
      imageUrl: "",
      category: "",
      level: "",
      isPublished: false
    }
  });

  // Fetch test series data if editing
  const { data: testSeries, isLoading: isLoadingTestSeries } = useQuery({
    queryKey: [isEditing ? `${apiPrefix}/test-series/${testSeriesId}` : null],
    queryFn: isEditing ? getQueryFn() : () => Promise.resolve(null),
    enabled: isEditing,
  });

  // Set form values when test series data is loaded
  useEffect(() => {
    if (testSeries) {
      form.reset({
        title: testSeries.title,
        description: testSeries.description,
        price: testSeries.price,
        discountPrice: testSeries.discountPrice || 0,
        duration: testSeries.duration,
        imageUrl: testSeries.imageUrl || "",
        category: testSeries.category || "",
        level: testSeries.level || "",
        isPublished: testSeries.isPublished || false
      });
      
      if (testSeries.imageUrl) {
        setImagePreview(testSeries.imageUrl);
      }
    }
  }, [testSeries, form]);

  // Handle image upload
  const uploadImageMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("image", file);
      
      const res = await apiRequest("POST", "/api/admin/upload-image", formData, true);
      return await res.json();
    },
    onSuccess: (data) => {
      return data.imageUrl;
    },
    onError: (error) => {
      console.error("Failed to upload image:", error);
      toast({
        title: "Image upload failed",
        description: "Failed to upload image. Please try again.",
        variant: "destructive",
      });
      return null;
    },
  });

  // Create test series mutation
  const createMutation = useMutation({
    mutationFn: async (data: TestSeriesFormValues) => {
      return apiRequest("POST", `${apiPrefix}/test-series`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`${apiPrefix}/test-series`] });
      toast({
        title: "Test Series created",
        description: "Test series has been created successfully.",
      });
      navigate(`${apiPrefix === '/api/admin' ? '/admin' : ''}/test-series`);
    },
    onError: (error) => {
      console.error("Failed to create test series:", error);
      toast({
        title: "Failed to create test series",
        description: "An error occurred while creating the test series. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update test series mutation
  const updateMutation = useMutation({
    mutationFn: async (data: TestSeriesFormValues) => {
      return apiRequest("PUT", `${apiPrefix}/test-series/${testSeriesId}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`${apiPrefix}/test-series`] });
      queryClient.invalidateQueries({ queryKey: [`${apiPrefix}/test-series/${testSeriesId}`] });
      toast({
        title: "Test Series updated",
        description: "Test series has been updated successfully.",
      });
      navigate(`${apiPrefix === '/api/admin' ? '/admin' : ''}/test-series`);
    },
    onError: (error) => {
      console.error("Failed to update test series:", error);
      toast({
        title: "Failed to update test series",
        description: "An error occurred while updating the test series. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setImage(selectedFile);
      
      // Create a preview URL
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setImagePreview(event.target.result as string);
        }
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const onSubmit = async (data: TestSeriesFormValues) => {
    try {
      // Upload image if selected
      if (image) {
        const uploadResult = await uploadImageMutation.mutateAsync(image);
        if (uploadResult && uploadResult.imageUrl) {
          data.imageUrl = uploadResult.imageUrl;
        }
      }
      
      // Create or update test series
      if (isEditing) {
        await updateMutation.mutateAsync(data);
      } else {
        await createMutation.mutateAsync(data);
      }
    } catch (error) {
      console.error("Form submission error:", error);
    }
  };

  if (isEditing && isLoadingTestSeries) {
    return (
      <Container title="Loading Test Series...">
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Container>
    );
  }

  return (
    <Container title={isEditing ? "Edit Test Series" : "Create Test Series"}>
      <div className="max-w-4xl mx-auto">
        <Button
          variant="ghost"
          onClick={() => navigate(`${apiPrefix === '/api/admin' ? '/admin' : ''}/test-series`)}
          className="mb-4"
        >
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Test Series
        </Button>
        
        <Card>
          <CardHeader>
            <CardTitle>{isEditing ? "Edit Test Series" : "Create New Test Series"}</CardTitle>
            <CardDescription>
              {isEditing
                ? "Update the details of your test series."
                : "Fill in the details to create a new test series."}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter test series title" {...field} />
                      </FormControl>
                      <FormDescription>
                        A descriptive title for your test series.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Enter a detailed description"
                          className="min-h-32"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        Provide a detailed description of what the test series covers.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid gap-4 md:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="price"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Price (₹)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min="0"
                            step="0.01"
                            placeholder="0.00"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          Regular price of the test series (in rupees).
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="discountPrice"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Discount Price (₹)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min="0"
                            step="0.01"
                            placeholder="0.00"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          Discounted price, if applicable (in rupees).
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid gap-4 md:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="duration"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Duration</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., 3 months" {...field} />
                        </FormControl>
                        <FormDescription>
                          How long the test series lasts.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Category</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., JEE, NEET" {...field} />
                        </FormControl>
                        <FormDescription>
                          The category this test series belongs to.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="level"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Level</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Beginner, Intermediate, Advanced" {...field} />
                      </FormControl>
                      <FormDescription>
                        The difficulty level of this test series.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div>
                  <FormLabel htmlFor="image">Cover Image</FormLabel>
                  <div className="mt-2 flex items-center gap-x-3">
                    {imagePreview ? (
                      <div className="relative w-24 h-24 border rounded-md overflow-hidden">
                        <img
                          src={imagePreview}
                          alt="Test series cover"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ) : (
                      <div className="flex h-24 w-24 items-center justify-center rounded-md border border-dashed">
                        <Image className="h-8 w-8 text-muted-foreground" />
                      </div>
                    )}
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById("imageUpload")?.click()}
                    >
                      <Upload className="mr-2 h-4 w-4" />
                      {imagePreview ? "Change Image" : "Upload Image"}
                    </Button>
                    <input
                      id="imageUpload"
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleImageChange}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Recommended size: 800x450 pixels, JPEG or PNG format, max 2MB.
                  </p>
                </div>
                
                <div className="hidden">
                  <FormField
                    control={form.control}
                    name="imageUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input type="hidden" {...field} />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="pt-4 border-t">
                  <Button
                    type="submit"
                    disabled={createMutation.isPending || updateMutation.isPending || uploadImageMutation.isPending}
                    className="w-full sm:w-auto"
                  >
                    {(createMutation.isPending || updateMutation.isPending || uploadImageMutation.isPending) ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="mr-2 h-4 w-4" />
                        {isEditing ? "Save Changes" : "Create Test Series"}
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </Container>
  );
}