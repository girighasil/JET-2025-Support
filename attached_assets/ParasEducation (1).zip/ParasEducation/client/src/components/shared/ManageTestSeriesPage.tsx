import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getQueryFn, apiRequest } from "@/lib/queryClient";
import { Loader2, Plus, Pencil, Trash2, AlertTriangle, Eye, CheckCircle2, FileText } from "lucide-react";
import { TestSeries } from "@/types";
import { useLocation } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { useRolePermissions, useRoleBasedApiPrefix } from "@/hooks/use-role-permissions";

interface ManageTestSeriesPageProps {
  containerComponent: React.ComponentType<{ title: string; children: React.ReactNode }>;
}

export function ManageTestSeriesPage({ containerComponent: Container }: ManageTestSeriesPageProps) {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [seriesToDelete, setSeriesToDelete] = useState<TestSeries | null>(null);
  
  // Get role-based permissions
  const { 
    canPublish, 
    canSetPricing, 
    canManageAllContent 
  } = useRolePermissions();
  
  // Get the appropriate API prefix based on user role
  const apiPrefix = useRoleBasedApiPrefix();
  
  // Endpoint is different for admin (all test series) vs teacher (my test series)
  const seriesEndpoint = canManageAllContent 
    ? `${apiPrefix}/test-series` 
    : `${apiPrefix}/my-test-series`;

  const { data: testSeries, isLoading } = useQuery<TestSeries[]>({
    queryKey: [seriesEndpoint],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("DELETE", `${apiPrefix}/test-series/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [seriesEndpoint] });
      toast({
        title: "Test series deleted",
        description: "The test series has been deleted successfully.",
      });
      setSeriesToDelete(null);
    },
    onError: (error) => {
      console.error("Failed to delete test series:", error);
      toast({
        title: "Failed to delete test series",
        description: "An error occurred while deleting the test series. Please try again.",
        variant: "destructive",
      });
    },
  });

  const publishMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("PUT", `${apiPrefix}/test-series/${id}/publish`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [seriesEndpoint] });
      toast({
        title: "Test series published",
        description: "The test series has been published and is now available to students.",
      });
    },
    onError: (error) => {
      console.error("Failed to publish test series:", error);
      toast({
        title: "Failed to publish test series",
        description: "An error occurred while publishing the test series. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDelete = (series: TestSeries) => {
    setSeriesToDelete(series);
  };

  const confirmDelete = () => {
    if (seriesToDelete) {
      deleteMutation.mutate(seriesToDelete.id);
    }
  };

  const handlePublish = (id: number) => {
    publishMutation.mutate(id);
  };

  if (isLoading) {
    return (
      <Container title="Manage Test Series">
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Container>
    );
  }

  return (
    <Container title="Manage Test Series">
      <div className="flex justify-between items-center mb-6">
        <div>
          <p className="text-muted-foreground mb-2">
            {canManageAllContent 
              ? "Manage all test series. Create, edit, publish, or delete test series as needed."
              : "Manage your test series. Create, edit, or delete test series as needed."}
          </p>
        </div>
        <Button onClick={() => navigate(`${canManageAllContent ? "/admin" : "/teacher"}/test-series/create`)}>
          <Plus className="mr-2 h-4 w-4" /> Create Test Series
        </Button>
      </div>

      {testSeries && testSeries.length > 0 ? (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Test Series Name</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Tests</TableHead>
                <TableHead>Category</TableHead>
                {canManageAllContent && <TableHead>Created By</TableHead>}
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {testSeries.map((series) => (
                <TableRow key={series.id}>
                  <TableCell className="font-medium">{series.title}</TableCell>
                  <TableCell>
                    <Badge variant={series.isPublished ? "success" : "secondary"}>
                      {series.isPublished ? "Published" : "Draft"}
                    </Badge>
                  </TableCell>
                  <TableCell>₹{series.price}</TableCell>
                  <TableCell>{series.testCount}</TableCell>
                  <TableCell>{series.category}</TableCell>
                  {canManageAllContent && <TableCell>{series.createdByName || "Unknown"}</TableCell>}
                  <TableCell className="text-right space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => navigate(`${canManageAllContent ? "/admin" : "/teacher"}/test-series/edit/${series.id}`)}
                    >
                      <Pencil className="h-4 w-4" />
                      <span className="sr-only">Edit</span>
                    </Button>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => navigate(`${canManageAllContent ? "/admin" : "/teacher"}/test-series/${series.id}/tests`)}
                    >
                      <FileText className="h-4 w-4" />
                      <span className="sr-only">Manage Tests</span>
                    </Button>
                    
                    {/* View button for published test series */}
                    {series.isPublished && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => navigate(`/test-series/${series.id}`)}
                      >
                        <Eye className="h-4 w-4" />
                        <span className="sr-only">View</span>
                      </Button>
                    )}
                    
                    {/* Publish button for admin only */}
                    {canPublish && !series.isPublished && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handlePublish(series.id)}
                        disabled={publishMutation.isPending}
                      >
                        <CheckCircle2 className="h-4 w-4 text-success" />
                        <span className="sr-only">Publish</span>
                      </Button>
                    )}
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(series)}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                      <span className="sr-only">Delete</span>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-12 border rounded-lg bg-muted/20">
          <div className="mb-4 p-3 rounded-full bg-primary/10">
            <AlertTriangle className="h-6 w-6 text-primary" />
          </div>
          <h3 className="text-xl font-medium mb-1">No test series found</h3>
          <p className="text-muted-foreground mb-4 text-center max-w-md">
            {canManageAllContent 
              ? "No test series have been created yet. Create your first test series to get started."
              : "You haven't created any test series yet. Create your first test series to get started."}
          </p>
          <Button onClick={() => navigate(`${canManageAllContent ? "/admin" : "/teacher"}/test-series/create`)}>
            <Plus className="mr-2 h-4 w-4" /> Create Test Series
          </Button>
        </div>
      )}

      <AlertDialog open={!!seriesToDelete} onOpenChange={(open) => !open && setSeriesToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the test series{" "}
              <strong>{seriesToDelete?.title}</strong> and all associated data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Container>
  );
}