import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getQueryFn, apiRequest } from "@/lib/queryClient";
import { Loader2, Plus, Pencil, Trash2, AlertTriangle, Eye, CheckCircle2 } from "lucide-react";
import { Test } from "@/types";
import { useLocation } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { useRolePermissions, useRoleBasedApiPrefix } from "@/hooks/use-role-permissions";

interface ManageTestsPageProps {
  containerComponent: React.ComponentType<{ title: string; children: React.ReactNode }>;
}

export function ManageTestsPage({ containerComponent: Container }: ManageTestsPageProps) {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [testToDelete, setTestToDelete] = useState<Test | null>(null);
  
  // Get role-based permissions
  const { 
    canPublish, 
    canManageAllContent,
    isAdmin,
    isTeacher
  } = useRolePermissions();
  
  // Get the appropriate API prefix based on user role
  const apiPrefix = useRoleBasedApiPrefix();
  
  // Tests endpoint is different for admin (all tests) vs teacher (my tests)
  const testsEndpoint = canManageAllContent 
    ? `${apiPrefix}/tests` 
    : `${apiPrefix}/my-tests`;

  const { data: tests, isLoading } = useQuery<Test[]>({
    queryKey: [testsEndpoint],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("DELETE", `${apiPrefix}/tests/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [testsEndpoint] });
      toast({
        title: "Test deleted",
        description: "The test has been deleted successfully.",
      });
      setTestToDelete(null);
    },
    onError: (error) => {
      console.error("Failed to delete test:", error);
      toast({
        title: "Failed to delete test",
        description: "An error occurred while deleting the test. Please try again.",
        variant: "destructive",
      });
    },
  });

  const publishMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("PUT", `${apiPrefix}/tests/${id}/publish`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [testsEndpoint] });
      toast({
        title: "Test published",
        description: "The test has been published and is now available to students.",
      });
    },
    onError: (error) => {
      console.error("Failed to publish test:", error);
      toast({
        title: "Failed to publish test",
        description: "An error occurred while publishing the test. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDelete = (test: Test) => {
    setTestToDelete(test);
  };

  const confirmDelete = () => {
    if (testToDelete) {
      deleteMutation.mutate(testToDelete.id);
    }
  };

  const handlePublish = (id: number) => {
    publishMutation.mutate(id);
  };

  const handleEdit = (testId: number) => {
    if (isAdmin) {
      navigate(`/admin/tests/${testId}/edit`);
    } else if (isTeacher) {
      navigate(`/teacher/tests/${testId}/edit`);
    }
  };

  const handleCreate = () => {
    if (isAdmin) {
      navigate('/admin/tests/create');
    } else if (isTeacher) {
      navigate('/teacher/tests/create');
    }
  };

  if (isLoading) {
    return (
      <Container title="Manage Tests">
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Container>
    );
  }

  return (
    <Container title="Manage Tests">
      <div className="flex justify-between items-center mb-6">
        <div>
          <p className="text-muted-foreground mb-2">
            {canManageAllContent 
              ? "Manage all tests. Create, edit, publish, or delete tests as needed."
              : "Manage your tests. Create and edit tests as needed."}
          </p>
        </div>
        <Button onClick={handleCreate}>
          <Plus className="mr-2 h-4 w-4" /> Create Test
        </Button>
      </div>

      {tests && tests.length > 0 ? (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Test Name</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Questions</TableHead>
                {canManageAllContent && <TableHead>Created By</TableHead>}
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tests.map((test) => (
                <TableRow key={test.id}>
                  <TableCell className="font-medium">{test.title}</TableCell>
                  <TableCell>
                    <Badge variant={test.isPublished ? "success" : "secondary"}>
                      {test.isPublished ? "Published" : "Draft"}
                    </Badge>
                  </TableCell>
                  <TableCell>{test.duration} minutes</TableCell>
                  <TableCell>{test.questionCount || 0}</TableCell>
                  {canManageAllContent && <TableCell>{test.createdByName || "Unknown"}</TableCell>}
                  <TableCell className="text-right space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(test.id)}
                    >
                      <Pencil className="h-4 w-4" />
                      <span className="sr-only">Edit</span>
                    </Button>
                    
                    {/* View button for published tests */}
                    {test.isPublished && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => navigate(`/test/${test.id}`)}
                      >
                        <Eye className="h-4 w-4" />
                        <span className="sr-only">View</span>
                      </Button>
                    )}
                    
                    {/* Publish button for admin only */}
                    {canPublish && !test.isPublished && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handlePublish(test.id)}
                        disabled={publishMutation.isPending}
                      >
                        <CheckCircle2 className="h-4 w-4 text-success" />
                        <span className="sr-only">Publish</span>
                      </Button>
                    )}
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(test)}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                      <span className="sr-only">Delete</span>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-12 border rounded-lg bg-muted/20">
          <div className="mb-4 p-3 rounded-full bg-primary/10">
            <AlertTriangle className="h-6 w-6 text-primary" />
          </div>
          <h3 className="text-xl font-medium mb-1">No tests found</h3>
          <p className="text-muted-foreground mb-4 text-center max-w-md">
            {canManageAllContent 
              ? "No tests have been created yet. Create your first test to get started."
              : "You haven't created any tests yet. Create your first test to get started."}
          </p>
          <Button onClick={handleCreate}>
            <Plus className="mr-2 h-4 w-4" /> Create Test
          </Button>
        </div>
      )}

      <AlertDialog open={!!testToDelete} onOpenChange={(open) => !open && setTestToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the test{" "}
              <strong>{testToDelete?.title}</strong> and all associated questions.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Container>
  );
}