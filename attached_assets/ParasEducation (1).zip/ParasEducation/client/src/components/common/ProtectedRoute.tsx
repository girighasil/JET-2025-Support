import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Route, RouteProps, useLocation } from "wouter";
import { ReactNode } from "react";

type ProtectedRouteProps = RouteProps & {
  adminOnly?: boolean;
  teacherOnly?: boolean;
  teacherOrAdminOnly?: boolean;
  children: ReactNode;
};

export function ProtectedRoute({ 
  path, 
  children, 
  adminOnly = false,
  teacherOnly = false,
  teacherOrAdminOnly = false
}: ProtectedRouteProps) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  if (isLoading) {
    return (
      <Route path={path}>
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Route>
    );
  }

  if (!user) {
    // Redirect to auth page
    setLocation("/auth");
    return null;
  }

  if (adminOnly && user.role !== "admin") {
    // Redirect non-admins trying to access admin pages to their respective dashboards
    if (user.role === "teacher") {
      setLocation("/teacher");
    } else {
      setLocation("/student-dashboard");
    }
    return null;
  }

  if (teacherOnly && user.role !== "teacher") {
    // Redirect non-teachers trying to access teacher pages
    if (user.role === "admin") {
      setLocation("/admin");
    } else {
      setLocation("/student-dashboard");
    }
    return null;
  }

  if (teacherOrAdminOnly && user.role !== "admin" && user.role !== "teacher") {
    // Redirect students trying to access teacher/admin pages
    setLocation("/student-dashboard");
    return null;
  }

  return <Route path={path}>{children}</Route>;
}