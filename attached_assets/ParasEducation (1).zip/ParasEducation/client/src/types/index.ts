import { User } from "./user";

export type Test = {
  id: number;
  title: string;
  description: string;
  duration: number;
  isPublished: boolean;
  createdById: number;
  createdByName?: string;
  testSeriesId?: number;
  questionCount?: number;
  category?: string;
  level?: string;
  passPercentage?: number;
};

export interface TestQuestion {
  id: number;
  testId: number;
  questionText: string;
  type: "mcq" | "truefalse" | "fillblank" | "subjective";
  options?: TestQuestionOption[];
  correctOption?: string;
  points: number;
  order: number;
}

export interface TestQuestionOption {
  id: number;
  questionId: number;
  text: string;
  isCorrect: boolean;
}

export interface TestSeries {
  id: number;
  title: string;
  description: string;
  price: number;
  discountPrice?: number;
  duration: string;
  imageUrl?: string;
  category?: string;
  level?: string;
  isPublished: boolean;
  createdById: number;
  createdByName?: string;
}

export interface Course {
  id: number;
  title: string;
  description: string;
  price: number;
  discountPrice?: number;
  duration: string;
  category?: string;
  level?: string;
  imageUrl?: string;
  isPublished: boolean;
  createdById: number;
  createdByName?: string;
}

export interface DoubtSession {
  id: number;
  title: string;
  description: string;
  date: string;
  time: string;
  teacher: User;
  status: "pending" | "approved" | "completed" | "cancelled";
  studentId?: number;
}

export interface TestAttempt {
  id: number;
  testId: number;
  userId: number;
  startTime: string;
  endTime?: string;
  status: "inprogress" | "completed" | "expired";
  score?: number;
  totalQuestions: number;
  correctAnswers?: number;
  userAnswers?: UserAnswer[];
}

export interface UserAnswer {
  questionId: number;
  selectedOptionId?: number;
  selectedAnswer?: string;
  isCorrect?: boolean;
  points?: number;
  fullPoints?: number;
}

export interface Testimonial {
  id: number;
  name: string;
  testimonial: string;
  rating: number;
  avatarUrl?: string;
  position?: string;
}

export interface FAQ {
  id: number;
  question: string;
  answer: string;
  category?: string;
  order: number;
}

export interface SiteConfig {
  key: string;
  value: string;
  description?: string;
}