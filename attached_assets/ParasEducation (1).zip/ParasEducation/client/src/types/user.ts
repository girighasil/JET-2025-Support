export type User = {
  id: number;
  username: string;
  email: string;
  fullName: string;
  role: 'admin' | 'teacher' | 'student';
  phone?: string;
  profileImage?: string;
};