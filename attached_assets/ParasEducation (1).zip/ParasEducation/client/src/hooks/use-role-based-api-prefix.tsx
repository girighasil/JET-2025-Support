import { useRolePermissions } from "./use-role-permissions";

/**
 * Hook to get the appropriate API prefix based on user role
 * This allows us to use the same components with different API endpoints
 * based on whether the user is an admin or teacher
 */
export function useRoleBasedApiPrefix(): string {
  const { isAdmin } = useRolePermissions();
  
  return isAdmin ? "/api/admin" : "/api/teacher";
}