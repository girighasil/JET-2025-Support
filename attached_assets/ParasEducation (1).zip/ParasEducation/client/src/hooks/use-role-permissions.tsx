import { useAuth } from "@/hooks/use-auth";
import { useMemo } from "react";

export function useRolePermissions() {
  const { user } = useAuth();
  
  const isAdmin = useMemo(() => {
    return user?.role === "admin";
  }, [user]);
  
  const isTeacher = useMemo(() => {
    return user?.role === "teacher";
  }, [user]);
  
  const isStudent = useMemo(() => {
    return user?.role === "student";
  }, [user]);
  
  const canCreateContent = useMemo(() => {
    return isAdmin || isTeacher;
  }, [isAdmin, isTeacher]);
  
  const canPublishContent = useMemo(() => {
    return isAdmin;
  }, [isAdmin]);
  
  const canPublish = useMemo(() => {
    return isAdmin;
  }, [isAdmin]);
  
  const canSetPricing = useMemo(() => {
    return isAdmin;
  }, [isAdmin]);
  
  const canApproveContent = useMemo(() => {
    return isAdmin;
  }, [isAdmin]);
  
  const canManageAllContent = useMemo(() => {
    return isAdmin;
  }, [isAdmin]);
  
  const canManageUsers = useMemo(() => {
    return isAdmin;
  }, [isAdmin]);
  
  const canViewAdminDashboard = useMemo(() => {
    return isAdmin;
  }, [isAdmin]);
  
  const canViewTeacherDashboard = useMemo(() => {
    return isTeacher || isAdmin;
  }, [isTeacher, isAdmin]);
  
  return {
    isAdmin,
    isTeacher,
    isStudent,
    canCreateContent,
    canPublishContent,
    canPublish,
    canSetPricing,
    canApproveContent,
    canManageAllContent,
    canManageUsers,
    canViewAdminDashboard,
    canViewTeacherDashboard
  };
}

export function useRoleBasedApiPrefix() {
  const { isAdmin } = useRolePermissions();
  return isAdmin ? "/api/admin" : "/api/teacher";
}